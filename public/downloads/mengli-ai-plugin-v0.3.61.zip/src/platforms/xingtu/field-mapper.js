export function getXingtuMetricCandidates(bundle, matchedNote = null) {
  const account = buildAccountMetrics(bundle);
  const note = buildNoteMetrics(matchedNote);

  return {
    "达人昵称": account.nickname,
    "达人账号ID": account.douyinId,
    "达人主页链接": account.homeUrl,
    "达人星图链接": account.xingtuUrl,
    "星图达人ID": account.authorId,
    "达人星图ID": account.authorId,
    "抖音号": account.douyinId,
    "内容类目": account.category,
    "粉丝量": account.fansCount,
    "粉丝量/w": account.fansCountWan,
    "报价": account.price,
    "图文报价": account.picturePrice,
    "视频报价": account.videoPrice,
    "预期CPM": account.expectedCpm,
    "预期CPE": account.expectedCpe,
    "性价比": account.costPerformance,
    "性价比指数": account.costPerformanceIndex,
    "效果预估": account.effectEstimate,
    "预估播放量": account.estimatePlay,
    "预估互动量": account.estimateInteraction,
    "预估点赞量": account.estimateLike,
    "预估评论量": account.estimateComment,
    "预估收藏量": account.estimateCollect,
    "种草价值": account.plantingValue,
    "种草指数": account.plantingIndex,
    "预估种草播放量": account.plantingPlay,
    "GPM": account.gpm,
    "千次播放成交金额": account.thousandPlayGmv,
    "组件点击率": account.componentClickRate,
    "购物车点击率": account.cartClickRate,
    "转化率": account.conversionRate,
    "商单视频平均看后搜次数": account.afterSearchAvgCount,
    "商单视频看后搜率": account.afterSearchRate,
    "商单视频小蓝词点击率": account.blueWordClickRate,
    "个人视频平均看后搜次数": account.personalAfterSearchAvgCount,
    "个人视频看后搜率": account.personalAfterSearchRate,
    "个人视频小蓝词点击率": account.personalBlueWordClickRate,
    "A3增长数": account.a3GrowthCount,
    "进店成本": account.shopEntryCost,
    "互动率": account.interactionRate,
    "完播率": account.finishRate,
    "播放量中位数": account.playMedian,
    "发布作品": account.publishWorks,
    "平均时长": account.avgDuration,
    "平均点赞": account.avgLike,
    "平均评论": account.avgComment,
    "平均转发": account.avgShare,
    "预期播放量": account.expectedPlay,
    "爆文率": account.viralRate,
    "作品标题": note.title,
    "作品链接": note.url,
    "发布链接": note.url,
    "播放量": note.playCount,
    "点赞": note.likeCount,
    "点赞量": note.likeCount,
    "评论": note.commentCount,
    "评论量": note.commentCount,
    "分享": note.shareCount,
    "分享量": note.shareCount,
    "收藏": note.collectCount,
    "总互动": note.interactionCount
  };
}

export function mapXingtuAccountFields(bundle, requestedFields = [], status = {}) {
  const metrics = buildAccountMetrics(bundle);
  const fields = requestedFields.length ? requestedFields : Object.keys(metrics);

  return fields.reduce((acc, field) => {
    const value = resolveAccountMetricValue(metrics, field, status);
    if (value !== undefined && value !== null && value !== "") {
      acc[field] = value;
    }
    return acc;
  }, {});
}

export function mapXingtuNoteFields(note, requestedFields = [], status = {}) {
  const metrics = buildNoteMetrics(note);
  const fields = requestedFields.length ? requestedFields : Object.keys(metrics);

  return fields.reduce((acc, field) => {
    const value = resolveNoteMetricValue(metrics, field, status);
    if (value !== undefined && value !== null && value !== "") {
      acc[field] = value;
    }
    return acc;
  }, {});
}

function buildAccountMetrics(bundle = {}) {
  bundle = bundle ?? {};
  const rawPageMetrics = bundle.pageMetrics ?? {};
  const pageMetrics = shouldTrustBusinessPageMetrics(bundle) ? rawPageMetrics : {};
  const contentPageMetrics = shouldTrustBusinessPageMetricsSection(bundle, "content") ? rawPageMetrics : {};
  const estimatePageMetrics = shouldTrustBusinessPageMetricsSection(bundle, "estimate") ? rawPageMetrics : {};
  const seedPageMetrics = shouldTrustBusinessPageMetricsSection(bundle, "seed") ? rawPageMetrics : {};
  const basePageMetrics = pickBasePageMetrics(rawPageMetrics);
  const requestedFilters = bundle.requestedFilters ?? {};
  const requestedPlantingDays = Number(requestedFilters.plantingRangeDays ||
    (String(requestedFilters.plantingDataRange || "").includes("90") ? 90 : 0));
  const needsStrictPlantingRange = Number.isFinite(requestedPlantingDays) && requestedPlantingDays !== 0 && requestedPlantingDays !== 30;
  const apiBusinessSources = [
    unwrap(bundle.spreadInfo),
    unwrap(bundle.commerceSeedBaseInfo),
    unwrap(bundle.marketingInfo),
    unwrap(bundle.commerceSpreadInfo),
    unwrap(bundle.baseInfo),
    bundle
  ];
  const seedApiSources = needsStrictPlantingRange
    ? [unwrap(bundle.commerceSeedBaseInfo)]
    : [
      unwrap(bundle.commerceSeedBaseInfo),
      unwrap(bundle.commerceSpreadInfo)
    ];
  const seedFallbackSources = needsStrictPlantingRange
    ? [unwrap(bundle.commerceSeedBaseInfo)]
    : [
      unwrap(bundle.commerceSeedBaseInfo),
      unwrap(bundle.commerceSpreadInfo),
      unwrap(bundle.marketingInfo),
      unwrap(bundle.baseInfo)
    ];
  const estimateSources = [
    estimatePageMetrics,
    unwrap(bundle.marketingInfo),
    unwrap(bundle.commerceSpreadInfo),
    unwrap(bundle.baseInfo),
    bundle
  ];
  const estimateKeys = estimateMetricKeys(requestedFilters.estimateVideoType);
  const selectedExpectedCpm = formatCost(firstDeepValue(estimateSources, estimateKeys.cpm), 1);
  const selectedExpectedCpe = formatCost(firstDeepValue(estimateSources, estimateKeys.cpe), 1);
  const selectedExpectedPlay = firstPositiveDeepValue(estimateSources, estimateKeys.play);
  const selectedViralRate = formatPercent(firstDeepValue(estimateSources, estimateKeys.viral), 1);
  const seedKeys = seedMetricKeys(requestedFilters);
  const sources = [
    basePageMetrics,
    pageMetrics,
    unwrap(bundle.baseInfo),
    unwrap(bundle.marketingInfo),
    unwrap(bundle.spreadInfo),
    unwrap(bundle.commerceSpreadInfo),
    unwrap(bundle.commerceSeedBaseInfo),
    unwrap(bundle.fansDistribution),
    unwrap(bundle.linkInfo),
    bundle
  ];
  const fansCount = firstDeepValue(sources, [
    "fansCount",
    "follower_count",
    "followers_count",
    "fans_count",
    "fans_num",
    "follower",
    "total_fans",
    "fans"
  ]);
  const category = firstDeepValue(sources, [
    "category_name",
    "content_category",
    "content_category_name",
    "tag_name",
    "industry_name",
    "first_category_name",
    "second_category_name"
  ]) ?? joinTagValues(sources);
  const picturePrice = normalizePrice(firstDeepValue(sources, [
    "picture_price",
    "image_price",
    "pic_price",
    "photo_price",
    "image_text_price",
    "item_pic_price"
  ]));
  const videoPrice = normalizePrice(firstDeepValue(sources, [
    "video_price",
    "video_quote",
    "item_video_price",
    "price",
    "quote_price"
  ]));
  const price = firstPresent(picturePrice, videoPrice, normalizePrice(firstDeepValue(sources, [
    "price",
    "quote_price",
    "origin_price",
    "settlement_price"
  ])));

  const authorId = bundle.authorId ?? firstDeepValue(sources, ["o_author_id", "author_id", "id", "uid"]);
  const douyinSecUid = firstDeepValue(sources, ["sec_uid", "secUid"]);

  return {
    authorId,
    nickname: firstDeepValue(sources, ["nick_name", "nickname", "author_name", "name", "display_name"]),
    douyinId: firstDeepValue(sources, ["unique_id", "short_id", "douyin_id", "display_id"]),
    homeUrl: firstPresent(
      firstDeepValue(sources, [
        "homeUrl",
        "douyin_home_url",
        "douyin_homepage_url",
        "douyin_url",
        "home_url",
        "homepage",
        "author_url",
        "share_url"
      ]),
      buildDouyinHomeUrl(douyinSecUid)
    ),
    xingtuUrl: buildXingtuUrl(authorId),
    category,
    mcnName: firstDeepValue(sources, ["mcn_name", "mcnName", "agency_name", "agencyName", "company_name", "organization_name"]),
    fansCount,
    fansCountWan: toNumber(fansCount) == null ? null : round(toNumber(fansCount) / 10000, 2),
    price,
    platformBasePrice: price,
    platformServicePrice: price == null ? null : round(toNumber(price) * 1.1, 2),
    videoPrice1To20: normalizePrice(firstDeepValue(sources, [
      "videoPrice1To20",
      "video_price_1_20",
      "video_1_20_price",
      "video_price_20s",
      "short_video_price",
      "video_price_short"
    ])),
    videoPrice21To60: normalizePrice(firstDeepValue(sources, [
      "videoPrice21To60",
      "video_price_21_60",
      "video_21_60_price",
      "video_price_60s",
      "medium_video_price",
      "video_price_medium"
    ])),
    videoPrice60Plus: normalizePrice(firstDeepValue(sources, [
      "videoPrice60Plus",
      "video_price_60_plus",
      "video_60_plus_price",
      "video_price_over_60s",
      "long_video_price",
      "video_price_long"
    ])),
    picturePrice,
    videoPrice,
    expectedCpm: firstPresent(estimatePageMetrics.expectedCpm, selectedExpectedCpm, formatCost(firstDeepValue(sources, [
      "expectedCpm",
      "expected_cpm",
      "expect_cpm",
      "estimate_cpm",
      "cpm",
      "avg_cpm"
    ]), 1)),
    expectedCpe: firstPresent(estimatePageMetrics.expectedCpe, selectedExpectedCpe, formatCost(firstDeepValue(sources, [
      "expectedCpe",
      "expected_cpe",
      "expect_cpe",
      "estimate_cpe",
      "cpe",
      "avg_cpe"
    ]), 1)),
    expectedPlay: firstPresent(estimatePageMetrics.expectedPlay, formatXingtuCount(selectedExpectedPlay), formatXingtuCount(firstPositiveDeepValue(sources, ["expectedPlay", "expected_play", "expect_play", "avg_play", "play_count"]))),
    expectedInteraction: firstDeepValue(sources, ["expected_interaction", "interaction_median", "avg_interaction", "interact_count"]),
    costPerformance: firstDeepValue(sources, ["costPerformance", "cost_performance", "price_performance", "value_score", "cp_score"]),
    costPerformanceIndex: firstDeepValue(sources, ["costPerformanceIndex", "cost_performance_index", "price_performance_index", "cp_index"]),
    effectEstimate: firstDeepValue(sources, ["effectEstimate", "effect_estimate", "effect_score", "estimate_effect", "expected_effect"]),
    estimatePlay: firstDeepValue(sources, ["estimatePlay", "estimate_play", "predict_play", "predict_vv", "expected_play"]),
    estimateInteraction: firstDeepValue(sources, ["estimateInteraction", "estimate_interaction", "predict_interaction", "expected_interaction"]),
    estimateLike: firstDeepValue(sources, ["estimateLike", "estimate_like", "predict_like", "expected_like"]),
    estimateComment: firstDeepValue(sources, ["estimateComment", "estimate_comment", "predict_comment", "expected_comment"]),
    estimateCollect: firstDeepValue(sources, ["estimateCollect", "estimate_collect", "predict_collect", "expected_collect"]),
    plantingValue: firstDeepValue(sources, ["plantingValue", "planting_value", "grass_value", "recommend_value", "seeding_value"]),
    plantingIndex: firstDeepValue(sources, ["plantingIndex", "planting_index", "grass_index", "recommend_index", "seeding_index"]),
    plantingPlay: firstDeepValue(sources, ["plantingPlay", "planting_play", "grass_play", "seeding_play"]),
    gpm: formatCost(firstDeepValue(sources, ["gpm", "GPM", "thousand_play_gmv", "thousand_play_amount"])),
    thousandPlayGmv: formatCost(firstDeepValue(sources, ["thousandPlayGmv", "thousand_play_gmv", "thousand_play_amount", "gpm"])),
    componentClickRate: formatPercent(firstDeepValue(sources, ["componentClickRate", "component_click_rate", "component_ctr", "item_click_rate"]), 1),
    cartClickRate: formatPercent(firstDeepValue(sources, ["cartClickRate", "cart_click_rate", "shopping_cart_click_rate", "cart_ctr"]), 1),
    conversionRate: formatPercent(firstDeepValue(sources, ["conversionRate", "conversion_rate", "convert_rate", "cvr"]), 1),
    afterSearchAvgCount: firstPresent(seedPageMetrics.afterSearchAvgCount, firstDeepValue(seedApiSources, seedKeys.afterSearchAvgCount), firstDeepValue(seedFallbackSources, [
      "afterSearchAvgCount",
      "after_search_avg_count",
      "after_search_count_avg",
      "avg_after_search_count",
      "avg_search_after_watch_count",
      "search_after_watch_avg_count",
      "watch_after_search_avg_count"
    ])),
    afterSearchRate: firstPresent(seedPageMetrics.afterSearchRate, formatPercentMetric(firstDeepValue(seedApiSources, seedKeys.afterSearchRate)), formatPercentMetric(firstDeepValue(seedFallbackSources, [
      "afterSearchRate",
      "after_search_rate",
      "search_after_watch_rate",
      "watch_after_search_rate"
    ]))),
    blueWordClickRate: firstPresent(seedPageMetrics.blueWordClickRate, formatPercentMetric(firstDeepValue(seedApiSources, seedKeys.blueWordClickRate)), formatPercentMetric(firstDeepValue(seedFallbackSources, [
      "blueWordClickRate",
      "blue_word_click_rate",
      "small_blue_word_click_rate",
      "blue_word_ctr",
      "blue_word_clk_rate"
    ]))),
    personalAfterSearchAvgCount: firstPresent(seedPageMetrics.personalAfterSearchAvgCount, firstDeepValue(seedApiSources, seedKeys.personalAfterSearchAvgCount), firstDeepValue(seedFallbackSources, [
      "personalAfterSearchAvgCount",
      "personal_after_search_avg_count",
      "personal_after_search_count_avg",
      "personal_avg_after_search_count",
      "personal_search_after_watch_avg_count",
      "personal_watch_after_search_avg_count"
    ])),
    personalAfterSearchRate: firstPresent(seedPageMetrics.personalAfterSearchRate, formatPercentMetric(firstDeepValue(seedApiSources, seedKeys.personalAfterSearchRate)), formatPercentMetric(firstDeepValue(seedFallbackSources, [
      "personalAfterSearchRate",
      "personal_after_search_rate",
      "personal_search_after_watch_rate",
      "personal_watch_after_search_rate"
    ]))),
    personalBlueWordClickRate: firstPresent(seedPageMetrics.personalBlueWordClickRate, formatPercentMetric(firstDeepValue(seedApiSources, seedKeys.personalBlueWordClickRate)), formatPercentMetric(firstDeepValue(seedFallbackSources, [
      "personalBlueWordClickRate",
      "personal_blue_word_click_rate",
      "personal_small_blue_word_click_rate",
      "personal_blue_word_ctr",
      "personal_blue_word_clk_rate"
    ]))),
    a3GrowthCount: firstPresent(seedPageMetrics.a3GrowthCount, firstDeepValue(seedApiSources, seedKeys.a3GrowthCount), firstDeepValue(seedFallbackSources, ["a3GrowthCount", "a3_growth_count", "a3_increase_count", "a3_growth", "a3_count"])),
    shopEntryCost: firstPresent(seedPageMetrics.shopEntryCost, firstDeepValue(seedApiSources, seedKeys.shopEntryCost), firstDeepValue(seedFallbackSources, ["shopEntryCost", "shop_entry_cost", "store_entry_cost", "shop_visit_cost", "enter_shop_cost"])),
    interactionRate: firstPresent(contentPageMetrics.interactionRate, formatPercent(firstDeepValue(apiBusinessSources, ["interact_rate", "interactionRate", "interaction_rate", "avg_interaction_rate"]), 1), formatPercent(firstDeepValue(sources, ["interact_rate", "interactionRate", "interaction_rate", "avg_interaction_rate"]), 1)),
    finishRate: firstPresent(
      contentPageMetrics.finishRate,
      formatPercent(firstDeepValue([unwrap(bundle.spreadInfo)], [
        "play_over_rate",
        "playOverRate",
        "finishRate",
        "finish_rate",
        "complete_rate",
        "video_finish_rate",
        "play_complete_rate",
        "avg_play_over_rate"
      ]), 1)
    ),
    playMedian: firstPresent(contentPageMetrics.playMedian, formatXingtuCount(firstDeepValue(apiBusinessSources, ["play_mid", "playMedian", "play_median", "median_play", "vv_median"])), formatXingtuCount(firstDeepValue(sources, ["play_mid", "playMedian", "play_median", "median_play", "vv_median"]))),
    likeMedian: firstDeepValue(sources, ["like_median", "digg_median", "median_like"]),
    commentMedian: firstDeepValue(sources, ["comment_median", "median_comment"]),
    shareMedian: firstDeepValue(sources, ["share_median", "median_share"]),
    collectMedian: firstDeepValue(sources, ["collect_median", "favorite_median", "median_collect"]),
    avgPlay: firstDeepValue(sources, ["avg_play", "avg_play_count", "average_play"]),
    publishWorks: firstPresent(contentPageMetrics.publishWorks, formatPublishWorks(firstDeepValue(apiBusinessSources, ["item_num", "publishWorks", "publish_works", "publish_count", "work_count", "item_count", "item_cnt"]), requestedFilters.contentVideoType), formatPublishWorks(firstDeepValue(sources, ["item_num", "publishWorks", "publish_works", "publish_count", "work_count", "item_count", "item_cnt"]), requestedFilters.contentVideoType)),
    avgDuration: firstPresent(contentPageMetrics.avgDuration, formatDurationSeconds(firstDeepValue(apiBusinessSources, ["avgDuration", "avg_duration", "average_duration", "avg_video_duration", "item_avg_duration"])), formatDurationSeconds(firstDeepValue(sources, ["avgDuration", "avg_duration", "average_duration", "avg_video_duration", "item_avg_duration"]))),
    avgLike: firstPresent(contentPageMetrics.avgLike, formatXingtuCount(firstDeepValue(apiBusinessSources, ["like_avg", "avgLike", "avg_like", "avg_digg", "average_like"])), formatXingtuCount(firstDeepValue(sources, ["like_avg", "avgLike", "avg_like", "avg_digg", "average_like"]))),
    avgComment: firstPresent(contentPageMetrics.avgComment, formatXingtuCount(firstDeepValue(apiBusinessSources, ["comment_avg", "avgComment", "avg_comment", "average_comment"])), formatXingtuCount(firstDeepValue(sources, ["comment_avg", "avgComment", "avg_comment", "average_comment"]))),
    avgShare: firstPresent(contentPageMetrics.avgShare, formatXingtuCount(firstDeepValue(apiBusinessSources, ["share_avg", "avgShare", "avg_share", "average_share"])), formatXingtuCount(firstDeepValue(sources, ["share_avg", "avgShare", "avg_share", "average_share"]))),
    avgCollect: firstDeepValue(sources, ["avg_collect", "avg_favorite", "average_collect"]),
    viralRate: firstPresent(estimatePageMetrics.viralRate, selectedViralRate, formatPercent(firstDeepValue(sources, ["viralRate", "viral_rate", "hot_rate", "popular_rate", "explosive_rate", "hit_rate", "burst_text_rate"]), 1)),
    fansProfile: summarizeFansProfile(unwrap(bundle.fansDistribution)),
    fansGender: summarizeByKeys(unwrap(bundle.fansDistribution), ["gender", "sex"]),
    fansAge: summarizeByKeys(unwrap(bundle.fansDistribution), ["age"]),
    fansCity: summarizeByKeys(unwrap(bundle.fansDistribution), ["city", "province", "region"])
  };
}

function buildNoteMetrics(note = {}) {
  if (!note) {
    return {};
  }

  const sources = [note];
  const like = firstDeepValue(sources, ["digg_count", "diggCount", "digg_count_str", "digg_cnt", "diggCnt", "like_count", "likeCount", "like_count_str", "like_cnt", "likeCnt", "praise_count", "praiseCount", "praise_cnt", "praiseCnt", "digg", "like", "likes"]);
  const comment = firstDeepValue(sources, ["comment_count", "commentCount", "comment_count_str", "comment_cnt", "commentCnt", "comments_count", "commentsCount", "comment", "comments"]);
  const share = firstDeepValue(sources, ["share_count", "shareCount", "share_count_str", "share_count_all", "shareCountAll", "share_cnt", "shareCnt", "share_cnt_td", "shareCntTd", "share_cnt_all", "shareCntAll", "share_cnt_total", "shareCntTotal", "total_share_cnt", "totalShareCnt", "repost_count", "repostCount", "repost_count_all", "repostCountAll", "forward_count", "forwardCount", "forward_count_all", "forwardCountAll", "forward_cnt", "forwardCnt", "forward_cnt_all", "forwardCntAll", "share", "shares"]);
  const collect = firstDeepValue(sources, ["collect_count", "favorite_count", "collectCount", "favoriteCount", "collect_cnt", "favorite_cnt", "collect", "favorite"]);

  return {
    title: firstDeepValue(sources, ["title", "item_title", "desc", "description"]),
    awemeId: note.awemeId ?? firstDeepValue(sources, ["aweme_id", "aweme_id_str", "item_id", "item_id_str", "video_id", "video_id_str", "group_id", "group_id_str", "id", "id_str"]),
    url: firstPresent(
      firstDeepValue(sources, ["share_url", "shareUrl", "video_url", "videoUrl", "item_url", "itemUrl", "aweme_url", "awemeUrl", "detail_url", "detailUrl", "url", "href"]),
      buildDouyinVideoUrl(note.awemeId ?? firstDeepValue(sources, ["aweme_id", "aweme_id_str", "item_id", "item_id_str", "video_id", "video_id_str", "group_id", "group_id_str", "id", "id_str"]))
    ),
    publishTime: formatTime(firstDeepValue(sources, ["create_time", "publish_time", "release_time"])),
    playCount: firstDeepValue(sources, [
      "play_count",
      "playCount",
      "play_count_str",
      "play_cnt",
      "playCnt",
      "play_cnt_str",
      "play_num",
      "playNum",
      "play_num_str",
      "playNumStr",
      "vv",
      "vv_count",
      "vvCount",
      "vv_cnt",
      "vvCnt",
      "vv_num",
      "vvNum",
      "video_play_count",
      "videoPlayCount",
      "video_play_cnt",
      "videoPlayCnt",
      "item_play_count",
      "itemPlayCount",
      "item_play_cnt",
      "itemPlayCnt",
      "aweme_play_count",
      "awemePlayCount",
      "aweme_play_cnt",
      "awemePlayCnt",
      "watch_cnt",
      "watchCnt",
      "watch_count",
      "watchCount",
      "view_count",
      "viewCount",
      "view_cnt",
      "viewCnt",
      "view_num",
      "viewNum",
      "read_count",
      "readCount",
      "read_cnt",
      "readCnt",
      "read_num",
      "readNum",
      "show_count",
      "showCount",
      "show_cnt",
      "showCnt",
      "show_num",
      "showNum",
      "display_count",
      "displayCount",
      "display_cnt",
      "displayCnt"
    ]),
    exposure: firstDeepValue(sources, ["show_count", "exposure_count", "impression_count"]),
    read: firstDeepValue(sources, ["read_count", "view_count", "watch_cnt", "watch_count", "play_count"]),
    likeCount: like,
    collectCount: collect,
    commentCount: comment,
    shareCount: share,
    interactionCount: firstDeepValue(sources, ["interaction_count", "interact_count", "total_interaction"]) ?? sumNumbers(like, collect, comment, share),
    finishRate: formatPercent(firstDeepValue(sources, ["finish_rate", "complete_rate", "play_over_rate"])),
    avgPlayDuration: firstDeepValue(sources, ["avg_play_duration", "average_play_time", "avg_watch_duration"]),
    itemType: firstDeepValue(sources, ["item_type", "aweme_type", "media_type", "type"]),
    matchConfidence: note.matchConfidence ?? 1
  };
}

function pickBasePageMetrics(pageMetrics = {}) {
  return {
    authorId: pageMetrics.authorId,
    nickname: pageMetrics.nickname,
    homeUrl: pageMetrics.homeUrl,
    fansCount: pageMetrics.fansCount,
    videoPrice1To20: pageMetrics.videoPrice1To20,
    videoPrice21To60: pageMetrics.videoPrice21To60,
    videoPrice60Plus: pageMetrics.videoPrice60Plus,
    mcnName: pageMetrics.mcnName
  };
}

function estimateMetricKeys(videoType) {
  if (videoType === "1-20s视频") {
    return {
      cpm: ["cpm_1_20", "prospective_1_20_cpm", "sn_prospective_1_20_cpm", "promotion_prospective_1_20_cpm"],
      cpe: ["cpe_1_20", "prospective_1_20_cpe", "sn_prospective_1_20_cpe"],
      play: ["vv", "sn_vv", "expected_play_num_1_20", "expected_1_20_play_num", "expected_vv_1_20", "prospective_1_20_vv", "prospective_1_20_play_num", "promotion_prospective_1_20_vv", "promotion_prospective_1_20_play_num"],
      viral: ["platform_hot_rate", "sn_platform_hot_rate", "burst_text_rate_1_20", "burst_1_20_text_rate", "viral_rate_1_20"]
    };
  }
  if (videoType === "60s以上视频") {
    return {
      cpm: ["cpm_60", "prospective_60_cpm", "sn_prospective_60_cpm", "promotion_prospective_60_cpm"],
      cpe: ["cpe_60", "prospective_60_cpe", "sn_prospective_60_cpe"],
      play: ["vv", "sn_vv", "expected_play_num_60", "expected_60_play_num", "expected_vv_60", "prospective_60_vv", "prospective_60_play_num", "promotion_prospective_60_vv", "promotion_prospective_60_play_num"],
      viral: ["platform_hot_rate", "sn_platform_hot_rate", "burst_text_rate_60", "burst_60_text_rate", "viral_rate_60"]
    };
  }
  if (videoType === "图文") {
    return {
      cpm: ["pic_cpm", "pic_expected_cpm", "prospective_pic_cpm"],
      cpe: ["pic_cpe", "pic_expected_cpe", "prospective_pic_cpe"],
      play: ["vv", "sn_vv", "pic_expected_play_num", "expected_pic_play_num", "expected_pic_vv", "prospective_pic_vv", "promotion_prospective_pic_vv", "promotion_prospective_pic_play_num"],
      viral: ["platform_hot_rate", "sn_platform_hot_rate", "pic_burst_text_rate", "burst_pic_text_rate", "pic_viral_rate"]
    };
  }
  return {
    cpm: ["cpm_21_60", "cpm_20_60", "prospective_20_60_cpm", "sn_prospective_20_60_cpm", "promotion_prospective_20_60_cpm"],
    cpe: ["cpe_21_60", "cpe_20_60", "prospective_20_60_cpe", "sn_prospective_20_60_cpe"],
    play: ["vv", "sn_vv", "expected_play_num_21_60", "expected_play_num_20_60", "expected_20_60_play_num", "expected_vv_20_60", "prospective_20_60_vv", "prospective_20_60_play_num", "promotion_prospective_20_60_vv", "promotion_prospective_20_60_play_num", "expected_play_num"],
    viral: ["platform_hot_rate", "sn_platform_hot_rate", "burst_text_rate_21_60", "burst_text_rate_20_60", "burst_20_60_text_rate", "viral_rate_20_60", "burst_text_rate"]
  };
}

function seedMetricKeys(filters = {}) {
  const days = Number(filters.plantingRangeDays);
  const preferRequestedRange = Number.isFinite(days) && days !== 30;
  const ordered = (rangeKeys, defaultKeys, day30Keys = []) => preferRequestedRange
    ? [...rangeKeys, ...defaultKeys, ...day30Keys]
    : [...defaultKeys, ...day30Keys, ...rangeKeys];

  return {
    afterSearchAvgCount: ordered(
      [
        "task_search_after_view_cnt_range",
        "task_search_after_view_count_range",
        "avg_search_after_view_cnt_range",
        "avg_search_after_view_count_range",
        "search_after_view_cnt_range",
        "search_after_view_count_range"
      ],
      [
        "avg_search_after_view_cnt",
        "avg_search_after_view_count",
        "order_avg_search_after_view_cnt",
        "order_avg_search_after_view_count",
        "star_avg_search_after_view_cnt",
        "star_avg_search_after_view_count"
      ],
      ["task_avg_search_after_view_cnt_30d", "task_avg_search_after_view_count_30d"]
    ),
    afterSearchRate: ordered(
      ["task_search_after_view_rate_range", "avg_search_after_view_rate_range", "search_after_view_rate_range"],
      ["avg_search_after_view_rate", "order_search_after_view_rate", "star_search_after_view_rate"],
      ["task_avg_search_after_view_rate_30d", "task_search_after_view_rate_30d"]
    ),
    blueWordClickRate: ordered(
      [
        "task_blue_word_click_rate_range",
        "task_blue_word_ctr_range",
        "task_small_blue_word_click_rate_range",
        "search_word_ctr_range",
        "search_word_click_rate_range",
        "blue_word_click_rate_range",
        "small_blue_word_click_rate_range"
      ],
      ["search_word_ctr", "search_word_click_rate", "task_small_blue_word_click_rate", "order_blue_word_click_rate", "star_blue_word_click_rate"],
      ["task_blue_word_click_rate_30d", "task_blue_word_ctr_30d"]
    ),
    personalAfterSearchAvgCount: ordered(
      [
        "personal_search_after_view_cnt_range",
        "personal_search_after_view_count_range",
        "personal_avg_search_after_view_cnt_range",
        "personal_avg_search_after_view_count_range"
      ],
      ["personal_avg_search_after_view_cnt", "personal_avg_search_after_view_count"],
      ["personal_avg_search_after_view_cnt_30d", "personal_avg_search_after_view_count_30d"]
    ),
    personalAfterSearchRate: ordered(
      ["personal_search_after_view_rate_range", "personal_avg_search_after_view_rate_range"],
      ["personal_avg_search_after_view_rate"],
      ["personal_avg_search_after_view_rate_30d", "personal_search_after_view_rate_30d"]
    ),
    personalBlueWordClickRate: ordered(
      [
        "personal_blue_word_click_rate_range",
        "personal_blue_word_ctr_range",
        "personal_small_blue_word_click_rate_range",
        "personal_search_word_ctr_range",
        "personal_search_word_click_rate_range"
      ],
      ["personal_search_word_ctr", "personal_search_word_click_rate", "personal_small_blue_word_click_rate"],
      ["personal_blue_word_click_rate_30d", "personal_blue_word_ctr_30d"]
    ),
    a3GrowthCount: ordered(
      ["a3_growth_count_range", "avg_a3_incr_cnt_range", "a3_incr_cnt_range"],
      ["avg_a3_incr_cnt", "a3_incr_cnt"],
      ["avg_a3_incr_cnt_30d", "a3_incr_cnt_30d"]
    ),
    shopEntryCost: ordered(
      ["avg_enter_shop_cost_range", "star_overflow_avg_enter_shop_cost_30d_range", "star_overflow_avg_enter_shop_cost_range"],
      ["star_overflow_avg_enter_shop_cost", "avg_enter_shop_cost"],
      ["star_overflow_avg_enter_shop_cost_30d"]
    )
  };
}

function shouldTrustBusinessPageMetrics(bundle = {}) {
  return shouldTrustBusinessPageMetricsSection(bundle, "content") &&
    shouldTrustBusinessPageMetricsSection(bundle, "estimate") &&
    shouldTrustBusinessPageMetricsSection(bundle, "seed");
}

function shouldTrustBusinessPageMetricsSection(bundle = {}, section) {
  if (!bundle.pageMetrics) {
    return false;
  }
  const requested = bundle.requestedFilters ?? {};
  const applied = bundle.appliedFilters ?? {};
  const matchesValue = (expected, actual) => !expected || actual === expected;
  const matchesBoolean = (expected, actual) => expected === null || expected === undefined || actual === null || actual === undefined || actual === expected;
  if (section === "content") {
    return (matchesValue(requested.contentDataRange, applied.contentDataRange) || matchesValue(requested.contentDataRange, bundle.pageMetrics.contentDataRange)) &&
      (matchesValue(requested.contentVideoType, applied.contentVideoType) || matchesValue(requested.contentVideoType, bundle.pageMetrics.contentVideoType)) &&
      matchesBoolean(requested.onlyAssigned, applied.onlyAssigned) &&
      matchesBoolean(requested.contentExcludeMarketing, applied.contentExcludeMarketing);
  }
  if (section === "estimate") {
    return (matchesValue(requested.estimateVideoType, applied.estimateVideoType) || matchesValue(requested.estimateVideoType, bundle.pageMetrics.estimateVideoType)) &&
      matchesBoolean(requested.estimateExcludeMarketing, applied.estimateExcludeMarketing);
  }
  if (section === "seed") {
    return bundle.pageMetrics.plantingRangeVerified === true &&
      matchesValue(requested.plantingDataRange, bundle.pageMetrics.plantingDataRange);
  }
  return false;
}

function hasSeedPageMetrics(pageMetrics = {}) {
  return [
    "afterSearchAvgCount",
    "afterSearchRate",
    "blueWordClickRate",
    "personalAfterSearchAvgCount",
    "personalAfterSearchRate",
    "personalBlueWordClickRate",
    "a3GrowthCount",
    "shopEntryCost"
  ].some((key) => {
    const value = pageMetrics[key];
    return value !== null && value !== undefined && value !== "";
  });
}

function resolveAccountMetricValue(metrics, field, status = {}) {
  const normalized = normalize(field);
  const aliases = [
    [["达人昵称", "昵称", "账号昵称"], metrics.nickname],
    [["达人id", "星图达人id", "达人星图id", "o_author_id"], metrics.authorId],
    [["抖音号", "达人账号id"], metrics.douyinId],
    [["主页链接", "达人主页链接"], metrics.homeUrl],
    [["星图链接", "达人星图链接"], metrics.xingtuUrl],
    [["内容类目", "账号行业", "行业"], metrics.category],
    [["mcn名称", "mcn机构", "机构名称"], metrics.mcnName],
    [["粉丝量/w", "粉丝量w", "粉丝数/w"], metrics.fansCountWan],
    [["粉丝量", "粉丝数"], metrics.fansCount],
    [["报价", "平台裸价", "裸价"], metrics.platformBasePrice],
    [["平台报价含10%服务费", "平台报价（含10%服务费）", "平台报价"], metrics.platformServicePrice],
    [["1-20s视频价格", "1-20秒视频价格"], firstPresent(metrics.videoPrice1To20, metrics.videoPrice)],
    [["21-60s视频价格", "21-60秒视频价格"], metrics.videoPrice21To60],
    [["60s以上视频价格", "60秒以上视频价格"], metrics.videoPrice60Plus],
    [["图文报价", "图文价格"], metrics.picturePrice],
    [["视频报价", "视频价格"], metrics.videoPrice],
    [["预期cpm", "预估cpm", "cpm"], metrics.expectedCpm],
    [["预期cpe", "预估cpe", "cpe"], metrics.expectedCpe],
    [["预期播放量"], metrics.expectedPlay],
    [["预期互动量"], metrics.expectedInteraction],
    [["性价比"], metrics.costPerformance],
    [["性价比指数"], metrics.costPerformanceIndex],
    [["效果预估"], metrics.effectEstimate],
    [["预估播放量"], metrics.estimatePlay],
    [["预估互动量"], metrics.estimateInteraction],
    [["预估点赞量"], metrics.estimateLike],
    [["预估评论量"], metrics.estimateComment],
    [["预估收藏量"], metrics.estimateCollect],
    [["种草价值"], metrics.plantingValue],
    [["种草指数"], metrics.plantingIndex],
    [["预估种草播放量"], metrics.plantingPlay],
    [["gpm", "千次播放成交金额"], firstPresent(metrics.gpm, metrics.thousandPlayGmv)],
    [["组件点击率"], metrics.componentClickRate],
    [["购物车点击率"], metrics.cartClickRate],
    [["转化率"], metrics.conversionRate],
    [["商单视频平均看后搜次数"], metrics.afterSearchAvgCount],
    [["商单视频看后搜率"], metrics.afterSearchRate],
    [["商单视频小蓝词点击率"], metrics.blueWordClickRate],
    [["个人视频平均看后搜次数"], metrics.personalAfterSearchAvgCount],
    [["个人视频看后搜率"], metrics.personalAfterSearchRate],
    [["个人视频小蓝词点击率"], metrics.personalBlueWordClickRate],
    [["a3增长数"], metrics.a3GrowthCount],
    [["进店成本"], metrics.shopEntryCost],
    [["互动率"], metrics.interactionRate],
    [["完播率", "视频完播率"], metrics.finishRate],
    [["播放中位数", "播放量中位数"], metrics.playMedian],
    [["发布作品"], metrics.publishWorks],
    [["平均时长"], metrics.avgDuration],
    [["点赞中位数", "中位点赞量"], metrics.likeMedian],
    [["评论中位数", "中位评论量"], metrics.commentMedian],
    [["分享中位数", "中位分享量", "转发中位数"], metrics.shareMedian],
    [["收藏中位数", "中位收藏量"], metrics.collectMedian],
    [["平均播放量"], metrics.avgPlay],
    [["平均点赞", "平均点赞量"], metrics.avgLike],
    [["平均评论", "平均评论量"], metrics.avgComment],
    [["平均转发", "平均分享量"], metrics.avgShare],
    [["平均收藏量"], metrics.avgCollect],
    [["爆文率"], metrics.viralRate],
    [["粉丝画像"], metrics.fansProfile],
    [["粉丝性别"], metrics.fansGender],
    [["粉丝年龄"], metrics.fansAge],
    [["粉丝城市"], metrics.fansCity],
    [["星图采集状态", "采集状态"], status.status],
    [["匹配置信度"], status.matchConfidence],
    [["最近采集时间"], status.collectedAt],
    [["错误原因"], status.error]
  ];

  return pickAlias(aliases, normalized);
}

function resolveNoteMetricValue(metrics, field, status = {}) {
  const normalized = normalize(field);
  const aliases = [
    [["作品标题", "笔记标题", "视频标题"], metrics.title],
    [["作品链接", "发布链接"], metrics.url],
    [["实际发布时间", "发布时间"], metrics.publishTime],
    [["播放量"], metrics.playCount],
    [["曝光量"], metrics.exposure],
    [["阅读量"], metrics.read],
    [["点赞", "点赞量"], metrics.likeCount],
    [["收藏", "收藏量"], metrics.collectCount],
    [["评论", "评论量"], metrics.commentCount],
    [["分享", "分享量", "转发", "转发量"], metrics.shareCount],
    [["总互动", "互动量"], metrics.interactionCount],
    [["作品完播率"], metrics.finishRate],
    [["平均播放时长"], metrics.avgPlayDuration],
    [["作品类型"], metrics.itemType],
    [["作品匹配状态"], status.noteStatus],
    [["采集状态"], status.status],
    [["匹配置信度"], metrics.matchConfidence ?? status.matchConfidence],
    [["最近采集时间"], status.collectedAt],
    [["错误原因"], status.error]
  ];

  return pickAlias(aliases, normalized);
}

function pickAlias(aliases, normalized) {
  const match = aliases.find(([names]) => names.some((name) => normalize(name) === normalized));
  return match ? match[1] : undefined;
}

function unwrap(value) {
  let current = value;
  for (let index = 0; index < 4; index += 1) {
    if (!current || typeof current !== "object") {
      return current;
    }
    if (current.data !== undefined) {
      current = current.data;
      continue;
    }
    if (current.result !== undefined) {
      current = current.result;
      continue;
    }
    return current;
  }
  return current;
}

function firstDeepValue(sources, keys) {
  for (const source of sources) {
    const value = findDeepValue(source, keys);
    const scalar = toMetricScalar(value);
    if (scalar !== null && scalar !== undefined && scalar !== "") {
      return scalar;
    }
  }
  return null;
}

function firstPositiveDeepValue(sources, keys) {
  for (const source of sources) {
    const value = findDeepValue(source, keys);
    const scalar = toMetricScalar(value);
    if (scalar === null || scalar === undefined || scalar === "") {
      continue;
    }
    const numeric = toNumber(scalar);
    if (numeric === null || numeric > 0) {
      return scalar;
    }
  }
  return null;
}

function findDeepValue(value, keys, seen = new Set()) {
  if (!value || typeof value !== "object" || seen.has(value)) {
    return null;
  }
  seen.add(value);
  for (const key of keys) {
    if (value[key] !== undefined && value[key] !== null && String(value[key]).trim() !== "") {
      return value[key];
    }
  }
  for (const item of Object.values(value)) {
    if (item && typeof item === "object") {
      const nested = findDeepValue(item, keys, seen);
      if (nested !== null && nested !== undefined && String(nested).trim() !== "") {
        return nested;
      }
    }
  }
  return null;
}

function joinTagValues(sources) {
  const tags = [];
  for (const source of sources) {
    collectTagValues(source, tags);
  }
  return tags.length ? [...new Set(tags)].slice(0, 8).join("；") : null;
}

function collectTagValues(value, acc, seen = new Set()) {
  if (!value || typeof value !== "object" || seen.has(value) || acc.length >= 20) {
    return;
  }
  seen.add(value);
  if (Array.isArray(value)) {
    for (const item of value) {
      collectTagValues(item, acc, seen);
    }
    return;
  }
  for (const key of ["tag", "tag_name", "name", "category_name", "industry_name"]) {
    if (typeof value[key] === "string" && value[key].length <= 24) {
      acc.push(value[key]);
    }
  }
  for (const item of Object.values(value)) {
    collectTagValues(item, acc, seen);
  }
}

function summarizeFansProfile(value) {
  const parts = [
    summarizeByKeys(value, ["gender", "sex"]),
    summarizeByKeys(value, ["age"]),
    summarizeByKeys(value, ["city", "province", "region"])
  ].filter(Boolean);
  return parts.join("；") || null;
}

function summarizeByKeys(value, keys) {
  const buckets = [];
  collectBuckets(value, keys, buckets);
  return buckets.slice(0, 5).map((item) => {
    const label = item.label ?? item.name ?? item.key;
    const ratio = item.ratio ?? item.value ?? item.percent;
    return ratio == null ? label : `${label}:${formatPercent(ratio)}`;
  }).filter(Boolean).join("，") || null;
}

function collectBuckets(value, keys, acc, seen = new Set()) {
  if (!value || typeof value !== "object" || seen.has(value) || acc.length >= 20) {
    return;
  }
  seen.add(value);
  if (Array.isArray(value)) {
    for (const item of value) {
      if (item && typeof item === "object") {
        acc.push(item);
      }
      collectBuckets(item, keys, acc, seen);
    }
    return;
  }
  for (const key of keys) {
    if (Array.isArray(value[key])) {
      collectBuckets(value[key], keys, acc, seen);
    }
  }
  for (const item of Object.values(value)) {
    collectBuckets(item, keys, acc, seen);
  }
}

function normalizePrice(value) {
  const numeric = toNumber(value);
  return numeric == null ? value : numeric;
}

function formatCost(value, digits = 2) {
  const numeric = toNumber(value);
  return numeric == null ? value : round(numeric, digits);
}

function formatPercent(value, digits = 2) {
  const numeric = toNumber(value);
  if (numeric == null) {
    return value;
  }
  if (typeof value === "string" && value.includes("%")) {
    return value;
  }
  if (numeric > 0 && numeric <= 1) {
    return `${round(numeric * 100, digits)}%`;
  }
  if (numeric > 100 && numeric <= 10000) {
    return `${round(numeric / 100, digits)}%`;
  }
  return `${round(numeric, digits)}%`;
}

function formatPercentMetric(value) {
  if (typeof value === "string" && /[-~至到>＜<]|以下|以上/.test(value)) {
    return value;
  }
  return formatPercent(value);
}

function formatXingtuCount(value) {
  value = toMetricScalar(value);
  if (value === null || value === undefined || value === "") {
    return value;
  }
  if (typeof value === "string") {
    const text = value.trim();
    if (!text || /[-~至到>＜<]|以下|以上|%|w|万/i.test(text)) {
      return text;
    }
  }
  const numeric = toNumber(value);
  if (numeric == null) {
    return value;
  }
  if (Math.abs(numeric) >= 10000) {
    return `${formatCompactDecimal(numeric / 10000, 1)}w`;
  }
  return formatCompactDecimal(numeric, 1);
}

function formatPublishWorks(value, videoType) {
  value = toMetricScalar(value);
  if (value === null || value === undefined || value === "") {
    return value;
  }
  if (typeof value === "string" && /[<>+]/.test(value)) {
    return value.trim();
  }
  const numeric = toNumber(value);
  if (numeric == null || videoType !== "星图视频") {
    return value;
  }
  if (numeric === 0) {
    return 0;
  }
  if (numeric < 5) {
    return "<5";
  }
  if (numeric <= 10) {
    return "5+";
  }
  return "10+";
}

function formatCompactDecimal(value, digits = 1) {
  const rounded = round(Number(value), digits);
  return rounded.toLocaleString("en-US", {
    minimumFractionDigits: Number.isInteger(rounded) ? 0 : digits,
    maximumFractionDigits: digits
  });
}

function formatDurationSeconds(value) {
  if (value === null || value === undefined || value === "") {
    return value;
  }
  if (typeof value === "string" && /秒|s$/i.test(value.trim())) {
    return value;
  }
  const numeric = toNumber(value);
  if (numeric == null) {
    return value;
  }
  const seconds = numeric > 1000 ? numeric / 100 : numeric;
  return `${round(seconds, 1)}s`;
}

function formatTime(value) {
  if (!value) {
    return null;
  }
  const numeric = Number(value);
  if (Number.isFinite(numeric)) {
    const ms = numeric < 10000000000 ? numeric * 1000 : numeric;
    return new Date(ms).toISOString().slice(0, 19).replace("T", " ");
  }
  return value;
}

function buildXingtuUrl(authorId) {
  if (!authorId) {
    return null;
  }
  return `https://www.xingtu.cn/ad/creator/author-homepage/douyin-video/${encodeURIComponent(authorId)}`;
}

function buildDouyinHomeUrl(secUid) {
  if (!secUid) {
    return null;
  }
  return `https://www.douyin.com/user/${encodeURIComponent(secUid)}`;
}

function buildDouyinVideoUrl(awemeId) {
  if (!awemeId) {
    return null;
  }
  return `https://www.douyin.com/video/${encodeURIComponent(awemeId)}`;
}

function toNumber(value) {
  value = toMetricScalar(value);
  if (value === null || value === undefined || String(value).trim() === "") {
    return null;
  }
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }
  const normalized = String(value).replace(/,/g, "").trim();
  if (/万|w/i.test(normalized)) {
    const parsed = Number.parseFloat(normalized);
    return Number.isFinite(parsed) ? parsed * 10000 : null;
  }
  const parsed = Number.parseFloat(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function toMetricScalar(value, seen = new Set()) {
  if (!value || typeof value !== "object" || seen.has(value)) {
    return value;
  }
  seen.add(value);
  for (const key of [
    "value",
    "val",
    "num",
    "number",
    "count",
    "amount",
    "price",
    "rate",
    "ratio",
    "percent",
    "avg",
    "median"
  ]) {
    if (value[key] !== undefined && value[key] !== null && value[key] !== "") {
      return toMetricScalar(value[key], seen);
    }
  }
  if (value.data !== undefined) {
    return toMetricScalar(value.data, seen);
  }
  return null;
}

function sumNumbers(...values) {
  const numbers = values.map(toNumber).filter((value) => value != null);
  return numbers.length ? numbers.reduce((sum, value) => sum + value, 0) : null;
}

function round(value, digits = 2) {
  const factor = 10 ** digits;
  return Math.round(Number(value) * factor) / factor;
}

function firstPresent(...values) {
  return values.find((value) => value !== null && value !== undefined && value !== "") ?? null;
}

function normalize(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[()]/g, (token) => (token === "(" ? "（" : "）"))
    .toLowerCase()
    .trim();
}
