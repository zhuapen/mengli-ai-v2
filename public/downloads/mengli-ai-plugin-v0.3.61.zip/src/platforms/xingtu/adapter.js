export class XingtuAdapter {
  constructor(client) {
    this.client = client;
  }

  async collectRowMetrics(locators, accountFields, noteFields) {
    return this.client.collectRowMetrics(locators, accountFields, noteFields);
  }
}
