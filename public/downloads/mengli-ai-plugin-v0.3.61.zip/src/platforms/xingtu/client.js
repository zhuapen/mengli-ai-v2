export class XingtuPageClient {
  constructor() {
    this.collectorTabId = null;
    this.collectorWindowId = null;
  }

  async collectRowMetrics(locators, accountFields, noteFields) {
    return this.send("collect-xingtu-row-metrics-v79", { locators, accountFields, noteFields });
  }

  async send(action, payload) {
    let lastError = null;
    for (let collectorAttempt = 0; collectorAttempt < 2; collectorAttempt += 1) {
      let tab = null;
      try {
        tab = await withTimeout(
          this.getCollectorTab(payload?.locators),
          35000,
          "巨量星图采集页打开超时"
        );

        for (let attempt = 0; attempt < 3; attempt += 1) {
          await withTimeout(ensureContentScript(tab.id), 12000, "巨量星图采集脚本注入超时");
          const response = await withTimeout(
            chrome.tabs.sendMessage(tab.id, {
              source: "xingtu-data-collector",
              action,
              payload
            }),
            260000,
            "巨量星图页面采集无响应，请刷新插件后重试"
          );
          if (response?.error) {
            throw new Error(response.error);
          }
          if (response?.redirectUrl) {
            await chrome.tabs.update(tab.id, { url: response.redirectUrl });
            tab = await withTimeout(waitForTabReady(tab.id, response.redirectUrl), 30000, "巨量星图达人页跳转超时");
            continue;
          }
          return response;
        }
        throw new Error("巨量星图采集页跳转后仍未进入达人主页");
      } catch (error) {
        lastError = error;
        if (tab?.id && tab.id === this.collectorTabId) {
          await closeTabQuietly(tab.id);
        }
        this.collectorTabId = null;
        this.collectorWindowId = null;
        if (!isRetryableCollectorError(error) || collectorAttempt >= 1) {
          throw error;
        }
        await sleep(800);
      }
    }
    throw lastError ?? new Error("巨量星图采集失败");
  }

  async getCollectorTab(locators = {}) {
    const targetUrl = locators?.xingtuProfileUrl || buildXingtuProfileUrl(locators?.xingtuAuthorId);
    const url = targetUrl || "https://www.xingtu.cn/";
    const existing = await this.getReusableCollectorTab();
    if (existing?.id) {
      if (existing.url !== url) {
        await chrome.tabs.update(existing.id, { url });
        return waitForTabReady(existing.id, url);
      }
      return existing.status === "complete" && tabMatchesExpectedUrl(existing, url) ? existing : waitForTabReady(existing.id, url);
    }

    const created = await chrome.tabs.create({
      url,
      active: false
    });
    this.collectorWindowId = created.windowId ?? null;
    this.collectorTabId = created?.id ?? null;
    return waitForTabReady(created?.id, url);
  }

  async getReusableCollectorTab() {
    if (!this.collectorTabId) {
      return null;
    }

    try {
      const tab = await chrome.tabs.get(this.collectorTabId);
      if (!this.collectorWindowId || tab.windowId !== this.collectorWindowId) {
        this.collectorTabId = null;
        this.collectorWindowId = null;
        return null;
      }
      if (tab.active) {
        this.collectorTabId = null;
        this.collectorWindowId = null;
        return null;
      }
      return tab;
    } catch (_error) {
      this.collectorTabId = null;
      this.collectorWindowId = null;
      return null;
    }
  }
}

function isRetryableCollectorError(error) {
  const message = String(error?.message || error || "");
  if (/登录|权限|无权限|未授权/.test(message)) {
    return false;
  }
  return /超时|未进入|未切到|未读取到|采集页|筛选|无响应|跳转后/.test(message);
}

async function closeTabQuietly(tabId) {
  try {
    await chrome.tabs.remove(tabId);
  } catch (_error) {
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function buildXingtuProfileUrl(authorId) {
  if (!authorId) {
    return "";
  }
  return `https://www.xingtu.cn/ad/creator/author-homepage/douyin-video/${encodeURIComponent(authorId)}`;
}

function waitForTabReady(tabId, expectedUrl = "") {
  if (!tabId) {
    throw new Error("巨量星图采集页创建失败");
  }

  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("巨量星图采集页加载超时"));
    }, 30000);

    const listener = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId !== tabId || changeInfo.status !== "complete" || !tabMatchesExpectedUrl(tab, expectedUrl)) {
        return;
      }

      clearTimeout(timeoutId);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(tab);
    };

    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete" && tabMatchesExpectedUrl(tab, expectedUrl)) {
        clearTimeout(timeoutId);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(tab);
      }
    }).catch((error) => {
      clearTimeout(timeoutId);
      chrome.tabs.onUpdated.removeListener(listener);
      reject(error);
    });
  });
}

function tabMatchesExpectedUrl(tab, expectedUrl = "") {
  if (!expectedUrl) {
    return true;
  }
  const currentUrl = String(tab?.url ?? "");
  if (!currentUrl) {
    return false;
  }
  const expectedAuthorId = extractAuthorIdFromUrl(expectedUrl);
  if (expectedAuthorId) {
    return currentUrl.includes("/author-homepage/") && currentUrl.includes(expectedAuthorId);
  }
  try {
    const current = new URL(currentUrl);
    const expected = new URL(expectedUrl);
    return current.origin === expected.origin && current.pathname === expected.pathname;
  } catch (_error) {
    return currentUrl === expectedUrl;
  }
}

function extractAuthorIdFromUrl(value) {
  const text = String(value ?? "");
  const match = text.match(/\/author-homepage\/[^/?#]+\/([^/?#]+)/i) ||
    text.match(/[?&](?:o_author_id|author_id|id)=([^&#]+)/i);
  return match ? decodeURIComponent(match[1]) : "";
}

function withTimeout(promise, timeoutMs, message) {
  let timeoutId;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error(message)), timeoutMs);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timeoutId));
}

async function ensureContentScript(tabId) {
  try {
      const response = await chrome.tabs.sendMessage(tabId, {
        source: "xingtu-data-collector",
        action: "xingtu-ping-v79"
      });
    if (response?.currentVersion === "2026-06-15-xingtu-planting-hard-verify-v79" ||
        response?.version === "2026-06-15-xingtu-planting-hard-verify-v79") {
      return;
    }
  } catch (_error) {
  }
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["src/content/xingtu-content.js"]
  });
}
