export class HuxuanPageClient {
  constructor() {
    this.collectorTabId = null;
  }

  async collectRowMetrics(locators, accountFields, noteFields) {
    const tab = await this.getCollectorTab(locators);
    await ensureContentScript(tab.id);
    const payload = { locators, accountFields, noteFields };
    let result = await this.sendToTab(tab.id, "collect-huxuan-row-metrics-v2", payload);
    if (shouldRetrySparseAccountResult(result, accountFields)) {
      const retryUrl = locators?.huxuanProfileUrl || buildHuxuanProfileUrl(locators?.appid || locators?.finderId);
      if (retryUrl) {
        await chrome.tabs.update(tab.id, { url: retryUrl, active: false });
        await waitForTabComplete(tab.id);
      } else {
        await chrome.tabs.reload(tab.id);
        await waitForTabComplete(tab.id);
      }
      await ensureContentScript(tab.id);
      result = await this.sendToTab(tab.id, "collect-huxuan-row-metrics-v2", payload);
    }
    if (shouldRetrySparseAccountResult(result, accountFields)) {
      throw new Error("腾讯互选页面关键数据未读到，已停止导出以避免空白或错填；请确认达人页加载完整后重试");
    }
    return result;
  }

  async send(action, payload) {
    const tab = await this.getCollectorTab(payload?.locators);
    await ensureContentScript(tab.id);
    return this.sendToTab(tab.id, action, payload);
  }

  async sendToTab(tabId, action, payload) {
    const message = {
      source: "huxuan-data-collector",
      action,
      payload
    };
    let response;
    try {
      response = await withTimeout(chrome.tabs.sendMessage(tabId, message), HUXUAN_CONTENT_MESSAGE_TIMEOUT_MS, "腾讯互选内容采集超时");
    } catch (error) {
      if (!isMissingReceiverError(error)) {
        throw error;
      }
      await refreshTabAndEnsureContentScript(tabId);
      response = await withTimeout(chrome.tabs.sendMessage(tabId, message), HUXUAN_CONTENT_MESSAGE_TIMEOUT_MS, "腾讯互选内容采集超时");
    }
    if (response?.error) {
      throw new Error(response.error);
    }
    return response;
  }

  async getCollectorTab(locators = {}) {
    const targetUrl = locators?.huxuanProfileUrl || buildHuxuanProfileUrl(locators?.appid || locators?.finderId);
    const url = targetUrl || "https://huxuan.qq.com/trade/selection/";

    const existing = await this.getReusableCollectorTab();
    if (existing?.id) {
      if (!sameHuxuanCreator(existing.url, url)) {
        await chrome.tabs.update(existing.id, { url, active: false });
        return waitForTabComplete(existing.id);
      }
      return existing.status === "complete" ? existing : waitForTabComplete(existing.id);
    }

    const created = await chrome.tabs.create({ url, active: false });
    this.collectorTabId = created.id ?? null;
    return waitForTabComplete(created.id);
  }

  async getReusableCollectorTab() {
    if (!this.collectorTabId) {
      return null;
    }

    try {
      const tab = await chrome.tabs.get(this.collectorTabId);
      if (tab?.active) {
        this.collectorTabId = null;
        return null;
      }
      return tab || null;
    } catch (_error) {
      this.collectorTabId = null;
      return null;
    }
  }

}

const EXPECTED_HUXUAN_CONTENT_SCRIPT_VERSION = "2026-06-15-huxuan-note-debug-v34";
const HUXUAN_CONTENT_MESSAGE_TIMEOUT_MS = 180000;

function sameHuxuanCreator(left, right) {
  const leftId = extractCreatorIdFromUrl(left);
  const rightId = extractCreatorIdFromUrl(right);
  if (!leftId && !rightId) {
    return normalizeHuxuanPath(left) === normalizeHuxuanPath(right);
  }
  return Boolean(leftId && rightId && leftId === rightId);
}

function buildHuxuanProfileUrl(creatorId) {
  if (!creatorId) {
    return "";
  }
  return `https://huxuan.qq.com/trade/selection/finder_trade_detail?id=${encodeURIComponent(creatorId)}&from=free-trade`;
}

function normalizeHuxuanPath(value) {
  try {
    const url = new URL(String(value || ""));
    return `${url.origin}${url.pathname}`;
  } catch (_error) {
    return String(value || "");
  }
}

function extractCreatorIdFromUrl(value) {
  try {
    const url = new URL(String(value || ""));
    return url.searchParams.get("id") || url.searchParams.get("appid") || "";
  } catch (_error) {
    const match = String(value || "").match(/[?&](?:id|appid)=([^&#]+)/i);
    return match ? decodeURIComponent(match[1]) : "";
  }
}

function waitForTabComplete(tabId) {
  if (!tabId) {
    throw new Error("腾讯互选采集页创建失败");
  }

  return new Promise((resolve, reject) => {
    let settled = false;
    const done = (handler, value) => {
      if (settled) {
        return;
      }
      settled = true;
      clearTimeout(timeoutId);
      clearTimeout(readyEnoughTimeoutId);
      chrome.tabs.onUpdated.removeListener(listener);
      handler(value);
    };
    const timeoutId = setTimeout(() => {
      done(reject, new Error("腾讯互选采集页加载超时"));
    }, 90000);
    const readyEnoughTimeoutId = setTimeout(() => {
      chrome.tabs.get(tabId).then((tab) => {
        if (/^https:\/\/huxuan\.qq\.com\//i.test(tab?.url || "")) {
          done(resolve, tab);
        }
      }).catch(() => {});
    }, 12000);

    const listener = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId !== tabId) {
        return;
      }
      if (changeInfo.status === "complete") {
        done(resolve, tab);
      }
    };

    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") {
        done(resolve, tab);
      }
    }).catch((error) => {
      done(reject, error);
    });
  });
}

async function ensureContentScript(tabId) {
  const ping = await pingContentScript(tabId);
  if (ping?.ok === true && ping.version === EXPECTED_HUXUAN_CONTENT_SCRIPT_VERSION) {
    return;
  }
  if (ping?.ok === true && ping.version !== EXPECTED_HUXUAN_CONTENT_SCRIPT_VERSION) {
    await refreshTabAndEnsureContentScript(tabId);
    return;
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["src/content/huxuan-content.js"]
    });
    await sleep(250);
    const injectedPing = await pingContentScript(tabId);
    if (injectedPing?.ok === true && injectedPing.version === EXPECTED_HUXUAN_CONTENT_SCRIPT_VERSION) {
      return;
    }
  } catch (error) {
    if (!isDuplicateInjectionError(error)) {
      throw error;
    }
  }

  await refreshTabAndEnsureContentScript(tabId);
}

async function refreshTabAndEnsureContentScript(tabId) {
  await chrome.tabs.reload(tabId);
  await waitForTabComplete(tabId);
  let ping = await pingContentScript(tabId);
  if (ping?.ok === true && ping.version === EXPECTED_HUXUAN_CONTENT_SCRIPT_VERSION) {
    return;
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["src/content/huxuan-content.js"]
    });
  } catch (error) {
    if (!isDuplicateInjectionError(error)) {
      throw error;
    }
  }
  await sleep(250);
  ping = await pingContentScript(tabId);
  if (!(ping?.ok === true && ping.version === EXPECTED_HUXUAN_CONTENT_SCRIPT_VERSION)) {
    throw new Error("腾讯互选采集页脚本注入失败，请刷新页面后重试");
  }
}

async function pingContentScript(tabId) {
  try {
    const response = await withTimeout(chrome.tabs.sendMessage(tabId, {
      source: "huxuan-data-collector",
      action: "huxuan-ping"
    }), 2000, "腾讯互选采集页连接超时");
    return response?.ok === true ? response : null;
  } catch (_error) {
    return null;
  }
}

function isMissingReceiverError(error) {
  return /Receiving end does not exist|Could not establish connection/i.test(error?.message || String(error));
}

function isDuplicateInjectionError(error) {
  return /already been declared|Identifier .* has already been declared/i.test(error?.message || String(error));
}

function shouldRetrySparseAccountResult(result, accountFields = []) {
  if (!accountFields.length || !requiresVisibleAccountData(accountFields)) {
    return false;
  }
  const pageMetrics = result?.account?.bundle?.pageMetrics;
  if (!pageMetrics || pageMetrics.success === false) {
    return true;
  }
  const usefulValues = [
    pageMetrics.nickname,
    pageMetrics.fans_count,
    pageMetrics.short_video_price,
    pageMetrics.long_video_price,
    pageMetrics.average_play_count,
    pageMetrics.play_median,
    pageMetrics.finish_rate,
    pageMetrics.interaction_rate
  ].filter((value) => value !== undefined && value !== null && String(value).trim() !== "");
  return usefulValues.length < 3;
}

function requiresVisibleAccountData(fields = []) {
  return fields.some((field) => {
    const normalized = String(field ?? "").replace(/\s+/g, "").toLowerCase();
    return !/^(?:互选链接|主页链接|视频号id|达人id|互选id|互选appid|appid)$/.test(normalized);
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function withTimeout(promise, timeoutMs, message) {
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      setTimeout(() => reject(new Error(message)), timeoutMs);
    })
  ]);
}
