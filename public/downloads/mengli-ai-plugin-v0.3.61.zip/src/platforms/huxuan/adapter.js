import { retryWithBackoff } from "../../shared/queue.js";

export class HuxuanAdapter {
  constructor(client) {
    this.client = client;
  }

  async collectRowMetrics(locators, accountFields, noteFields) {
    return retryWithBackoff(
      () => this.client.collectRowMetrics(locators, accountFields, noteFields),
      {
        retryCount: 0,
        retryMinDelaySeconds: 0,
        retryMaxDelaySeconds: 0
      }
    );
  }
}
