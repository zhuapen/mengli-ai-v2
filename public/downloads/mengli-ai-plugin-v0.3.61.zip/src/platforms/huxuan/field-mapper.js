export function getHuxuanMetricCandidates(bundle, matchedNote = null) {
  const account = buildAccountMetrics(bundle);
  const note = buildNoteMetrics(matchedNote);

  return {
    "平台": "腾讯互选视频号",
    "达人昵称": account.nickname,
    "视频号昵称": account.nickname,
    "达人ID": account.finderId,
    "互选ID": account.finderId,
    "视频号ID": account.finderId,
    "互选appid": account.appid,
    "主页链接": account.profileUrl,
    "互选链接": account.huxuanUrl,
    "内容类目": account.category,
    "账号标签": account.tags,
    "联系方式（微信）": account.wechatContact,
    "微信联系方式": account.wechatContact,
    "微信号": account.wechatContact,
    "账号简介": account.description,
    "认证信息": account.verifyInfo,
    "粉丝量": account.fansCount,
    "1-60s价格": account.shortPrice,
    "60s以上价格": account.longPrice,
    "平均播放量": account.averagePlayCount,
    "播放中位数": account.playMedian,
    "预期CPM": account.expectedCpm,
    "完播率": account.finishRate,
    "互动率": account.interactionRate,
    "预期CPE": account.expectedCpe,
    "平均拇指赞量": account.thumbLikeAverage,
    "平均转发量": account.forwardAverage,
    "平均爱心赞量": account.loveLikeAverage,
    "平均评论量": account.commentAverage,
    "粉丝性别画像": account.fansGenderProfile,
    "观众性别画像": account.audienceGenderProfile,
    "粉丝画像": account.fansProfile,
    "观众画像": account.audienceProfile,
    "性别画像": account.genderProfile,
    "年龄画像": account.ageProfile,
    "城市画像": account.cityProfile,
    "地域画像": account.regionProfile,
    "作品链接": note.url,
    "发布时间": note.publishTime,
    "播放量": note.playCount,
    "大拇指点赞量": note.thumbLikeCount,
    "转发量": note.shareCount,
    "爱心赞量": note.loveLikeCount,
    "评论量": note.commentCount,
    "总互动": note.interactionCount
  };
}

export function mapHuxuanAccountFields(bundle, requestedFields = [], status = {}) {
  const metrics = buildAccountMetrics(bundle);
  const fields = requestedFields.length ? requestedFields : Object.keys(metrics);

  return fields.reduce((acc, field) => {
    const value = resolveAccountMetricValue(metrics, field, status);
    if (value !== undefined && value !== null && value !== "") {
      acc[field] = value;
    }
    return acc;
  }, {});
}

export function mapHuxuanNoteFields(note, requestedFields = [], status = {}) {
  const metrics = buildNoteMetrics(note);
  const fields = requestedFields.length ? requestedFields : Object.keys(metrics);

  return fields.reduce((acc, field) => {
    const value = resolveNoteMetricValue(metrics, field, status);
    if (value !== undefined && value !== null && value !== "") {
      acc[field] = value;
    }
    return acc;
  }, {});
}

function buildAccountMetrics(bundle = {}) {
  bundle = bundle ?? {};
  const detail = unwrap(bundle.detail);
  const searchResult = unwrap(bundle.searchResult);
  const sources = [detail, searchResult, bundle.pageMetrics, bundle];
  const visibleFirstSources = [bundle.pageMetrics, detail, searchResult, bundle];
  const visiblePageSources = [bundle.pageMetrics].filter(Boolean);
  const appid = bundle.appid ?? firstDeepValue(sources, ["appid", "app_id", "finder_appid"]);
  const price = normalizePrice(firstDeepValue(visibleFirstSources, [
    "price",
    "quote_price",
    "quotation",
    "cooperation_price",
    "video_price",
    "publish_price"
  ]));
  const shortPrice = normalizePrice(firstDeepValue(visibleFirstSources, [
    "short_video_price",
    "shortVideoPrice",
    "price_1_60",
    "price_1_60s",
    "video_price_1_60",
    "short_price",
    "video_price",
    "publish_price",
    "price"
  ]));
  const longPrice = normalizePrice(firstDeepValue(visibleFirstSources, [
    "long_video_price",
    "longVideoPrice",
    "price_60_plus",
    "price_60s_plus",
    "video_price_60_plus",
    "video_long_price",
    "long_price"
  ]));
  const fansCount = firstDeepValue(sources, [
    "fans_count",
    "follower_count",
    "followers_count",
    "fans_num",
    "follower",
    "total_fans"
  ]);
  const performanceSources = [bundle.pageMetrics, scopeObject(visibleFirstSources, [
    "performance",
    "performance_data",
    "spread_data",
    "propagation",
    "video_performance",
    "trade_performance",
    "finder_video_show",
    "performance_info",
    "data_indicator"
  ]), ...visibleFirstSources];
  const fansProfile = scopeObject(visibleFirstSources, ["user_profile", "userProfile", "fans_profile", "follower_profile", "fans_portrait", "follower_portrait"]);
  const audienceProfile = scopeObject(visibleFirstSources, ["viewer_profile", "viewerProfile", "audience_profile", "audience_portrait", "viewer_portrait"]);
  const selectedProfile = bundle.filters?.audienceScope === "观众画像" ? audienceProfile : fansProfile;
  const fansGenderProfile = normalizeGenderRatio(firstDeepValue(visibleFirstSources, ["fans_gender_profile", "fansGenderProfile"]))
    ?? normalizeGenderRatio(scopeObject([fansProfile], ["gender", "gender_distribution", "gender_ratio"]));
  const audienceGenderProfile = normalizeGenderRatio(firstDeepValue(visibleFirstSources, ["audience_gender_profile", "audienceGenderProfile"]))
    ?? normalizeGenderRatio(scopeObject([audienceProfile], ["gender", "gender_distribution", "gender_ratio"]));
  const chartError = firstDeepValue(sources, ["chart_error", "chartError"]);
  const fansGenderFeedback = fansGenderProfile ? null : missingGenderFeedback(chartError, "粉丝画像");
  const audienceGenderFeedback = audienceGenderProfile ? null : missingGenderFeedback(chartError, "观众画像");

  return {
    platform: "腾讯互选视频号",
    appid,
    nickname: bundle.pageMetrics?.nickname ?? pickCreatorNickname(visibleFirstSources, appid),
    finderId: firstDeepValue(sources, ["finder_id", "finderId", "uniq_id", "username", "alias", "wechat_id"]) ?? appid,
    profileUrl: firstDeepValue(sources, ["profile_url", "home_url", "homepage", "finder_url", "share_url"]),
    huxuanUrl: buildHuxuanUrl(appid),
    category: normalizeJoin(firstDeepValue(visiblePageSources, ["category_name", "category", "content_category", "industry_name", "first_category_name"])),
    tags: normalizeJoin(firstDeepValue(visiblePageSources, ["tags", "tag_list", "tag_names", "label_list", "labels"])),
    wechatContact: firstDeepValue(visibleFirstSources, ["wechat_contact", "wechatContact", "contact_wechat", "contactWechat", "wechat_id", "wechatId"]),
    description: firstDeepValue(visiblePageSources, ["description", "desc", "signature", "introduction", "intro"]),
    verifyInfo: firstDeepValue(sources, ["verify_info", "verifyInfo", "certification", "auth_info"]),
    fansCount,
    fansCountWan: toNumber(fansCount) == null ? null : round(toNumber(fansCount) / 10000, 2),
    price: formatCurrency(price),
    shortPrice: formatCurrency(shortPrice ?? price),
    longPrice: formatCurrency(longPrice),
    cooperationStatus: firstDeepValue(sources, ["cooperation_status", "cooperate_status", "status_name", "status"]),
    canPromote: normalizeBooleanLabel(firstDeepValue(sources, ["can_promote", "can_cooperate", "can_order", "available"])),
    performanceScope: bundle.filters?.performanceScope,
    averagePlayCount: firstDeepValue(performanceSources, ["average_play_count", "avg_play_count", "average_play", "avg_play", "avg_vv", "play_avg", "read_avg"]),
    playMedian: firstDeepValue(performanceSources, ["play_median", "median_play", "vv_median", "view_median", "read_median"]),
    expectedCpm: firstDeepValue(performanceSources, ["expected_cpm", "expect_cpm", "cpm", "predict_cpm"]),
    expectedCpe: firstDeepValue(performanceSources, ["expected_cpe", "expect_cpe", "cpe", "predict_cpe"]),
    likeMedian: firstDeepValue(performanceSources, ["like_median", "median_like", "like_count_median"]),
    commentMedian: firstDeepValue(performanceSources, ["comment_median", "median_comment", "comment_count_median"]),
    shareMedian: firstDeepValue(performanceSources, ["share_median", "median_share", "share_count_median"]),
    thumbLikeAverage: firstDeepValue(performanceSources, ["thumb_like_average", "thumb_like_avg", "avg_thumb_like", "average_thumb_up", "avg_up_like", "avg_like_count", "like_avg"]),
    forwardAverage: firstDeepValue(performanceSources, ["forward_average", "forward_avg", "share_average", "share_avg", "avg_share_count"]),
    loveLikeAverage: firstDeepValue(performanceSources, ["love_like_average", "love_like_avg", "favorite_average", "favorite_avg", "collect_average", "collect_avg"]),
    commentAverage: firstDeepValue(performanceSources, ["comment_average", "comment_avg", "avg_comment_count"]),
    interactionRate: formatRate(firstDeepValue(performanceSources, ["interaction_rate", "engagement_rate", "interact_rate"])),
    finishRate: formatRate(firstDeepValue(performanceSources, ["finish_rate", "completion_rate", "complete_rate", "play_finish_rate"])),
    audienceScope: bundle.filters?.audienceScope,
    fansGenderProfile,
    audienceGenderProfile,
    fansGenderFeedback,
    audienceGenderFeedback,
    fansProfile: fansGenderProfile ?? fansGenderFeedback ?? summarizeProfile(fansProfile),
    audienceProfile: audienceGenderProfile ?? audienceGenderFeedback ?? summarizeProfile(audienceProfile),
    chartError,
    genderProfile: summarizeProfile(scopeObject([selectedProfile, ...sources], ["gender", "gender_distribution", "gender_ratio"])),
    ageProfile: summarizeProfile(scopeObject([selectedProfile, ...sources], ["age", "age_distribution", "age_ratio"])),
    cityProfile: summarizeProfile(scopeObject([selectedProfile, ...sources], ["city", "city_distribution", "city_ratio"])),
    regionProfile: summarizeProfile(scopeObject([selectedProfile, ...sources], ["region", "province", "area", "region_distribution", "province_distribution"]))
  };
}

function buildNoteMetrics(note = {}) {
  const sources = [note, unwrap(note)];
  const videoId = firstDeepValue(sources, ["export_id", "feed_export_id", "finder_export_id", "encrypted_feed_id", "video_id", "id"]);
  const thumbLikeCount = firstDeepValue(sources, ["fav_pv", "thumb_like_count", "thumbLikeCount", "thumb_up_count", "up_like_count", "like_count", "likeCount", "likes", "like_num"]);
  const loveLikeCount = firstDeepValue(sources, ["heart_pv", "love_like_count", "loveLikeCount", "favorite_count", "favorite_num", "collect_count", "collectCount"]);
  const commentCount = firstDeepValue(sources, ["comment_pv", "comment_count", "commentCount", "comments", "comment_num"]);
  const shareCount = firstDeepValue(sources, ["share_pv", "share_count", "shareCount", "forward_count", "forwardCount", "shares", "share_num"]);

  return {
    title: firstDeepValue(sources, ["title", "desc", "description", "video_title"]),
    url: firstDeepValue(sources, ["url", "share_url", "video_url", "publish_url", "link", "feed_url", "finder_url"]) ?? buildWeixinSphUrl(videoId),
    publishTime: normalizeTime(firstDeepValue(sources, ["release_time", "publish_time", "publishTime", "create_time", "createTime", "time"])),
    playCount: firstDeepValue(sources, ["read_pv", "play_count", "playCount", "read_count", "view_count", "vv", "exposure_count"]),
    thumbLikeCount,
    loveLikeCount,
    commentCount,
    shareCount,
    interactionCount: sumNumbers(thumbLikeCount, commentCount, shareCount, loveLikeCount),
    type: firstDeepValue(sources, ["type", "video_type", "media_type"]),
    matchMethod: firstDeepValue(sources, ["match_method", "matchMethod"]),
    publishTitleSource: firstDeepValue(sources, ["publish_title_source", "publishTitleSource"]),
    publishTitleError: firstDeepValue(sources, ["publish_title_error", "publishTitleError"])
  };
}

function resolveAccountMetricValue(metrics, field, status) {
  const normalized = normalizeField(field);
  const pairs = [
    [["平台"], metrics.platform],
    [["达人昵称", "视频号昵称", "昵称"], metrics.nickname],
    [["达人id", "互选id", "互选号", "视频号id", "视频号"], metrics.finderId],
    [["互选appid", "appid"], metrics.appid],
    [["主页链接", "视频号主页", "视频号链接"], metrics.profileUrl],
    [["互选链接", "互选主页"], metrics.huxuanUrl],
    [["内容类目", "账号行业"], metrics.category],
    [["账号标签", "标签"], metrics.tags],
    [["联系方式（微信）", "微信联系方式", "微信号"], metrics.wechatContact],
    [["账号简介", "简介"], metrics.description],
    [["认证信息"], metrics.verifyInfo],
    [["粉丝量", "粉丝数"], metrics.fansCount],
    [["粉丝量/w", "粉丝量（万）"], metrics.fansCountWan],
    [["报价", "平台裸价"], metrics.price],
    [["1-60s价格", "1至60秒价格", "1至60秒视频报价"], metrics.shortPrice],
    [["60s以上价格", "60秒以上价格", "60秒以上视频报价"], metrics.longPrice],
    [["合作状态"], metrics.cooperationStatus],
    [["是否可投放"], metrics.canPromote],
    [["传播表现筛选", "传播表现口径"], metrics.performanceScope],
    [["平均播放量"], metrics.averagePlayCount],
    [["播放中位数", "播放量中位数"], metrics.playMedian],
    [["预期cpm"], metrics.expectedCpm],
    [["预期cpe"], metrics.expectedCpe],
    [["点赞中位数"], metrics.likeMedian],
    [["评论中位数"], metrics.commentMedian],
    [["分享中位数"], metrics.shareMedian],
    [["平均拇指赞量"], metrics.thumbLikeAverage],
    [["平均转发量"], metrics.forwardAverage],
    [["平均爱心赞量"], metrics.loveLikeAverage],
    [["平均评论量"], metrics.commentAverage],
    [["互动率"], metrics.interactionRate],
    [["完播率"], metrics.finishRate],
    [["粉丝性别画像"], metrics.fansGenderProfile ?? metrics.fansGenderFeedback],
    [["观众性别画像"], metrics.audienceGenderProfile ?? metrics.audienceGenderFeedback],
    [["受众画像筛选", "受众画像口径"], metrics.audienceScope],
    [["粉丝画像"], metrics.fansGenderProfile ?? metrics.fansProfile],
    [["观众画像"], metrics.audienceGenderProfile ?? metrics.audienceProfile],
    [["画像采集错误"], metrics.chartError],
    [["性别画像"], metrics.genderProfile],
    [["年龄画像"], metrics.ageProfile],
    [["城市画像"], metrics.cityProfile],
    [["地域画像"], metrics.regionProfile],
    [["采集状态"], status.status],
    [["匹配置信度"], status.matchConfidence],
    [["最近采集时间"], status.collectedAt],
    [["错误原因"], status.error]
  ];
  return resolveByPairs(normalized, pairs);
}

function resolveNoteMetricValue(metrics, field, status) {
  const normalized = normalizeField(field);
  const pairs = [
    [["作品标题", "视频标题"], metrics.title],
    [["作品链接", "发布链接", "视频链接"], status.shouldWritePublishUrl ? (status.sourcePublishUrl || metrics.url) : undefined],
    [["发布时间", "实际发布时间"], metrics.publishTime],
    [["播放量", "阅读量", "曝光量"], metrics.playCount],
    [["点赞", "点赞量", "大拇指点赞量"], metrics.thumbLikeCount],
    [["评论", "评论量"], metrics.commentCount],
    [["分享", "分享量", "转发", "转发量"], metrics.shareCount],
    [["收藏", "收藏量", "爱心赞量"], metrics.loveLikeCount],
    [["总互动", "互动量"], metrics.interactionCount],
    [["作品类型"], metrics.type],
    [["作品匹配方式"], metrics.matchMethod],
    [["短链标题来源"], metrics.publishTitleSource],
    [["短链解析错误"], metrics.publishTitleError],
    [["作品匹配状态"], status.noteStatus],
    [["采集状态"], status.status],
    [["匹配置信度"], status.matchConfidence],
    [["最近采集时间"], status.collectedAt],
    [["错误原因"], status.error]
  ];
  return resolveByPairs(normalized, pairs);
}

function resolveByPairs(normalized, pairs) {
  for (const [aliases, value] of pairs) {
    const normalizedAliases = aliases.map(normalizeField);
    if (normalizedAliases.some((alias) => normalized === alias || normalized.includes(alias))) {
      return value;
    }
  }
  return undefined;
}

function firstDeepValue(sources, keys) {
  for (const source of sources) {
    const objects = collectObjects(source);
    for (const object of objects) {
      for (const key of keys) {
        if (object && Object.prototype.hasOwnProperty.call(object, key)) {
          const value = object[key];
          if (value !== undefined && value !== null && value !== "") {
            return value;
          }
        }
      }
    }
  }
  return null;
}

function allDeepValues(sources, keys) {
  const values = [];
  const seen = new Set();
  for (const source of sources) {
    const objects = collectObjects(source);
    for (const object of objects) {
      for (const key of keys) {
        if (object && Object.prototype.hasOwnProperty.call(object, key)) {
          const value = object[key];
          const text = String(value ?? "").trim();
          if (text && !seen.has(text)) {
            seen.add(text);
            values.push(value);
          }
        }
      }
    }
  }
  return values;
}

function pickCreatorNickname(sources, appid) {
  const candidates = allDeepValues(sources, [
    "nickname",
    "nick_name",
    "finder_nickname",
    "finderNickname",
    "finder_name",
    "finderName",
    "author_name",
    "authorName",
    "name"
  ]);
  return candidates.find((value) => isLikelyCreatorNickname(value, appid)) ?? null;
}

function isLikelyCreatorNickname(value, appid) {
  const text = String(value ?? "").trim();
  if (!text || text === String(appid ?? "").trim()) {
    return false;
  }
  if (/^(?:达人昵称|视频号昵称|昵称|用户头像|创作者广场|达人名单|腾讯广告互选平台)$/.test(text)) {
    return false;
  }
  if (/MCN[:：]?|有限公司|公司|传媒|文化传媒|营销|客服|萌力互动|飞瀑互动/.test(text)) {
    return false;
  }
  if (/^(?:互联网自媒体|财经自媒体|生活博主|搞笑幽默博主|美食|生活|游戏|其他)$/.test(text)) {
    return false;
  }
  return text.length <= 40;
}

function scopeObject(sources, keys) {
  const found = firstDeepValue(sources, keys);
  if (found && typeof found === "object") {
    return found;
  }
  return null;
}

function collectObjects(value, seen = new Set(), output = []) {
  if (!value || typeof value !== "object" || seen.has(value)) {
    return output;
  }
  seen.add(value);
  if (!Array.isArray(value)) {
    output.push(value);
  }
  for (const child of Array.isArray(value) ? value : Object.values(value)) {
    collectObjects(child, seen, output);
  }
  return output;
}

function unwrap(value) {
  if (!value || typeof value !== "object") {
    return value;
  }
  return value.data ?? value.result ?? value.resp ?? value;
}

function normalizePrice(value) {
  const number = toNumber(value);
  return number == null ? null : number;
}

function formatCurrency(value) {
  const number = toNumber(value);
  if (number == null) {
    return value;
  }
  return `¥${number.toLocaleString("en-US")}`;
}

function normalizeField(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[()]/g, (token) => (token === "(" ? "（" : "）"))
    .toLowerCase()
    .trim();
}

function normalizeJoin(value) {
  if (Array.isArray(value)) {
    return value.map((item) => {
      if (item && typeof item === "object") {
        return item.name ?? item.label ?? item.tag_name ?? item.title ?? "";
      }
      return item;
    }).filter(Boolean).join("、");
  }
  return value;
}

function summarizeProfile(value) {
  if (!value || typeof value !== "object") {
    return normalizeJoin(value);
  }
  const entries = Array.isArray(value)
    ? value.map((item) => {
        if (!item || typeof item !== "object") {
          return normalizeJoin(item);
        }
        const label = item.name ?? item.label ?? item.key ?? item.title ?? item.gender ?? item.age ?? item.city ?? item.province;
        const ratio = item.ratio ?? item.rate ?? item.percent ?? item.value ?? item.count;
        return formatProfilePair(label, ratio);
      })
    : Object.entries(value).map(([key, item]) => {
        if (item && typeof item === "object") {
          const label = item.name ?? item.label ?? item.key ?? key;
          const ratio = item.ratio ?? item.rate ?? item.percent ?? item.value ?? item.count;
          if (ratio === undefined || ratio === null || ratio === "") {
            const nested = summarizeProfile(item);
            return nested ? `${label}:${nested}` : label;
          }
          return formatProfilePair(label, ratio);
        }
        return formatProfilePair(key, item);
      });
  return entries.filter(Boolean).join("、");
}

function missingGenderFeedback(chartError, scopeLabel) {
  if (!String(chartError ?? "").includes(`${scopeLabel}性别分布未识别`)) {
    return null;
  }
  return `未识别（${scopeLabel}性别分布）`;
}

function normalizeGenderRatio(value) {
  if (!value) {
    return null;
  }
  const text = typeof value === "object"
    ? summarizeProfile(value)
    : normalizeJoin(value) || String(value);
  const male = extractGenderPercent(text, /男(?:性)?\s*[:：]?\s*(\d+(?:\.\d+)?)\s*%?/)
    ?? extractGenderPercent(text, /(\d+(?:\.\d+)?)\s*%?\s*男(?:性)?/);
  const female = extractGenderPercent(text, /女(?:性)?\s*[:：]?\s*(\d+(?:\.\d+)?)\s*%?/)
    ?? extractGenderPercent(text, /(\d+(?:\.\d+)?)\s*%?\s*女(?:性)?/);
  if (male != null && female != null) {
    const normalized = normalizeGenderPercentPair(male, female);
    return `男:${formatGenderNumber(normalized.male)}%、女:${formatGenderNumber(normalized.female)}%`;
  }
  if (!/[男女]/.test(String(text))) {
    const ratio = String(text).match(/(\d+(?:\.\d+)?)\s*[:：]\s*(\d+(?:\.\d+)?)/);
    if (ratio) {
      const normalized = normalizeGenderPercentPair(Number(ratio[1]), Number(ratio[2]));
      return `男:${formatGenderNumber(normalized.male)}%、女:${formatGenderNumber(normalized.female)}%`;
    }
  }
  return null;
}

function extractGenderPercent(text, pattern) {
  const match = String(text ?? "").match(pattern);
  if (!match) {
    return null;
  }
  const number = Number(match[1]);
  if (!Number.isFinite(number)) {
    return null;
  }
  return number > 0 && number <= 1 ? number * 100 : number;
}

function normalizeGenderPercentPair(male, female) {
  let normalizedMale = normalizeGenderPercentValue(male);
  let normalizedFemale = normalizeGenderPercentValue(female);
  const total = normalizedMale + normalizedFemale;
  if ((normalizedMale > 100 || normalizedFemale > 100) && total >= 9900 && total <= 10100) {
    normalizedMale /= 100;
    normalizedFemale /= 100;
  } else if ((normalizedMale > 100 || normalizedFemale > 100) && total >= 990 && total <= 1010) {
    normalizedMale /= 10;
    normalizedFemale /= 10;
  }
  return { male: normalizedMale, female: normalizedFemale };
}

function normalizeGenderPercentValue(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    return 0;
  }
  return number > 0 && number <= 1 ? number * 100 : number;
}

function formatGenderNumber(value) {
  const rounded = round(value, 2);
  return Number.isInteger(rounded) ? String(rounded) : String(rounded).replace(/0+$/, "").replace(/\.$/, "");
}

function formatProfilePair(label, value) {
  if (label === undefined || label === null || label === "") {
    return normalizeJoin(value);
  }
  if (value === undefined || value === null || value === "") {
    return String(label);
  }
  return `${label}:${formatRate(value) ?? value}`;
}

function formatRate(value) {
  if (typeof value === "string" && value.includes("%")) {
    return value.trim();
  }
  const number = toNumber(value);
  if (number == null) {
    return value;
  }
  if (number > 0 && number <= 1) {
    return `${round(number * 100, 2)}%`;
  }
  return String(value).includes("%") ? value : `${round(number, 2)}%`;
}

function normalizeBooleanLabel(value) {
  if (typeof value === "boolean") {
    return value ? "是" : "否";
  }
  if (value === 1 || value === "1") {
    return "是";
  }
  if (value === 0 || value === "0") {
    return "否";
  }
  return value;
}

function normalizeTime(value) {
  const number = toNumber(value);
  if (number && number > 1000000000) {
    const timestamp = number > 100000000000 ? number : number * 1000;
    return formatDateTime(new Date(timestamp));
  }
  return value;
}

function formatDateTime(date) {
  const parts = new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  }).formatToParts(date).reduce((acc, part) => {
    acc[part.type] = part.value;
    return acc;
  }, {});
  return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}:${parts.second}`;
}

function toNumber(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === "string") {
    const cleaned = value.replace(/,/g, "").replace(/[￥¥元]/g, "").trim();
    const match = cleaned.match(/-?\d+(?:\.\d+)?/);
    if (match) {
      let number = Number(match[0]);
      if (/[万wW]/.test(cleaned)) {
        number *= 10000;
      }
      return Number.isFinite(number) ? number : null;
    }
  }
  return null;
}

function sumNumbers(...values) {
  const numbers = values.map(toNumber).filter((value) => value != null);
  return numbers.length ? numbers.reduce((sum, value) => sum + value, 0) : null;
}

function round(value, digits = 2) {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function buildHuxuanUrl(appid) {
  if (!appid) {
    return null;
  }
  return `https://huxuan.qq.com/trade/selection/finder_trade_detail?id=${encodeURIComponent(appid)}&from=free-trade`;
}

function buildWeixinSphUrl(videoId) {
  const text = String(videoId ?? "").trim();
  if (!/^[A-Za-z0-9_-]{6,}$/.test(text)) {
    return null;
  }
  return `https://weixin.qq.com/sph/${encodeURIComponent(text)}`;
}
