import { retryWithBackoff } from "../../shared/queue.js";

export class PgyAdapter {
  constructor(client) {
    this.client = client;
  }

  async collectRowMetrics(locators, accountFields, noteFields, collectionOptions) {
    return retryWithBackoff(() => this.client.collectRowMetrics(locators, accountFields, noteFields, collectionOptions));
  }

  async collectAccountMetrics(locators, fields, collectionOptions) {
    return retryWithBackoff(() => this.client.collectAccountMetrics(locators, fields, collectionOptions));
  }

  async collectNoteMetrics(locators, fields) {
    return retryWithBackoff(() => this.client.collectNoteMetrics(locators, fields));
  }

  async collectNotePopupMetrics(locators, matchedNote) {
    return retryWithBackoff(() => this.client.collectNotePopupMetrics(locators, matchedNote));
  }

  async collectVisibleSelectedPerformance(locators, collectionOptions) {
    return retryWithBackoff(() => this.client.collectVisibleSelectedPerformance(locators, collectionOptions));
  }
}
