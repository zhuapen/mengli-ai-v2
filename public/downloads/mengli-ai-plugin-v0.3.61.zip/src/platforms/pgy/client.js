export class PgyPageClient {
  constructor() {
    this.collectorTabId = null;
  }

  async collectRowMetrics(locators, accountFields, noteFields, collectionOptions) {
    return this.send("collect-row-metrics", { locators, accountFields, noteFields, collectionOptions });
  }

  async collectAccountMetrics(locators, fields, collectionOptions) {
    return this.send("collect-account-metrics", { locators, fields, collectionOptions });
  }

  async collectNoteMetrics(locators, fields) {
    return this.send("collect-note-metrics", { locators, fields });
  }

  async collectNotePopupMetrics(locators, matchedNote) {
    const tab = await this.getCollectorTab(locators);
    await ensureContentScript(tab.id);

    return sendMessageWithTimeout(tab.id, {
      source: "media-data-collector",
      action: "collect-note-popup-metrics",
      payload: { locators, matchedNote }
    });
  }

  async collectVisibleSelectedPerformance(locators, collectionOptions) {
    const tab = await this.getCollectorTab(locators);
    await ensureContentScript(tab.id);

    return sendMessageWithTimeout(tab.id, {
      source: "media-data-collector",
      action: "pgy-collect-visible-selected-performance-v2",
      payload: { collectionOptions }
    });
  }

  async send(action, payload) {
    const tab = payload?.locators ? await this.getCollectorTab(payload.locators) : await this.findPgyTab();
    await ensureContentScript(tab.id);

    return sendMessageWithTimeout(tab.id, {
      source: "media-data-collector",
      action,
      payload
    });
  }

  async getCollectorTab(locators) {
    const userId = extractProfileUserId(locators?.pgyProfileUrl) || extractProfileUserId(locators?.profileUrl);
    if (!userId) {
      throw new Error("当前行缺少可用的小红书主页或蒲公英达人主页链接，无法打开后台详情页补抓");
    }

    const url = `https://pgy.xiaohongshu.com/solar/pre-trade/blogger-detail/${userId}`;
    const existing = await this.getReusableCollectorTab();
    if (existing?.id) {
      await chrome.tabs.update(existing.id, { url, active: false });
      return waitForTabComplete(existing.id);
    }

    const tab = await chrome.tabs.create({ url, active: false });
    this.collectorTabId = tab.id ?? null;
    return waitForTabComplete(tab.id);
  }

  async getReusableCollectorTab() {
    if (!this.collectorTabId) {
      return null;
    }

    try {
      const tab = await chrome.tabs.get(this.collectorTabId);
      return tab?.active ? null : tab;
    } catch (_error) {
      this.collectorTabId = null;
      return null;
    }
  }

  async findPgyTab() {
    const tabs = await chrome.tabs.query({
      url: ["https://pgy.xiaohongshu.com/*"]
    });
    const tab = tabs[0];
    if (!tab?.id) {
      throw new Error("未找到已打开的蒲公英页面");
    }
    return tab;
  }
}

function sendMessageWithTimeout(tabId, message, timeoutMs = 45000) {
  return Promise.race([
    chrome.tabs.sendMessage(tabId, message),
    new Promise((_, reject) => {
      setTimeout(() => {
        reject(new Error(`${message.action} 采集超时`));
      }, timeoutMs);
    })
  ]);
}

function waitForTabComplete(tabId) {
  if (!tabId) {
    throw new Error("后台采集页创建失败");
  }

  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("后台采集页加载超时"));
    }, 30000);

    const listener = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId !== tabId || changeInfo.status !== "complete") {
        return;
      }

      clearTimeout(timeoutId);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(tab);
    };

    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") {
        clearTimeout(timeoutId);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(tab);
      }
    }).catch((error) => {
      clearTimeout(timeoutId);
      chrome.tabs.onUpdated.removeListener(listener);
      reject(error);
    });
  });
}

function extractProfileUserId(profileUrl) {
  if (!profileUrl) {
    return "";
  }

  try {
    const url = new URL(profileUrl);
    const segments = url.pathname.split("/").filter(Boolean);
    return segments.at(-1) ?? "";
  } catch (_error) {
    return "";
  }
}

async function ensureContentScript(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, {
      source: "media-data-collector",
      action: "ping"
    });
    if (response?.version === "2026-06-03-data-performance-v14") {
      return;
    }
  } catch (_error) {
  }
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["vendor/md5/md5.min.js", "src/content/pgy-content.js"]
  });
}
