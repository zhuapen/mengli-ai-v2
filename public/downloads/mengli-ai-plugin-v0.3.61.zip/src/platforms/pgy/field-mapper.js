import { PGY_DEFAULT_FILTERS, PGY_FILTER_LABELS } from "../../shared/constants.js";

export function mapAccountFields(bundle, cooperationType, requestedFields = [], collectionOptions = {}) {
  const metrics = buildAccountMetrics(bundle, cooperationType, collectionOptions);
  const fields = requestedFields.length ? requestedFields : Object.keys(metrics);

  return fields.reduce((acc, field) => {
    const value = resolveMetricValue(metrics, field);
    if (value !== undefined) {
      acc[field] = value;
    }
    return acc;
  }, {});
}

export function getAccountMetricCandidates(bundle, cooperationType, collectionOptions = {}) {
  const metrics = buildAccountMetrics(bundle, cooperationType, collectionOptions);

  return {
    "达人id": metrics.creatorId,
    "达人昵称": metrics.creatorNickname,
    "蒲公英主页": metrics.pgyProfileUrl,
    "蒲公英链接": metrics.pgyProfileUrl,
    "蒲公英主页链接": metrics.pgyProfileUrl,
    "小红书主页": metrics.xhsProfileUrl,
    "小红书链接": metrics.xhsProfileUrl,
    "主页链接": metrics.xhsProfileUrl,
    "内容类目": metrics.contentCategory,
    "合作形式": cooperationType,
    "平台裸价": metrics.platformBasePrice,
    "平台报价（含10%服务费）": metrics.platformServicePrice,
    "曝光中位数": metrics.impMedian,
    "阅读中位数": metrics.readMedian,
    "互动中位数": metrics.interactionMedian,
    "外溢进店中位数": metrics.storeMedian,
    "默认口径": metrics.filterLabel,
    "数据表现口径": metrics.filterLabel,
    "阅读中位数-日常30天全流量": metrics.commonReadMedian,
    "阅读中位数-合作90天": metrics.coopReadMedian90,
    "阅读中位数-合作30天": metrics.coopReadMedian30,
    "预估cpm（图文）": metrics.pictureCpm,
    "预估cpm（视频）": metrics.videoCpm,
    "预估阅读单价（图文）": metrics.pictureReadCost,
    "预估阅读单价（视频）": metrics.videoReadCost,
    "成本候选-接口预估cpm（图文）": metrics.rawPictureCpm,
    "成本候选-接口预估cpm（视频）": metrics.rawVideoCpm,
    "成本候选-接口阅读单价（图文）": metrics.rawPictureReadCost,
    "成本候选-接口阅读单价（视频）": metrics.rawVideoReadCost,
    "按成本字段探测": metrics.costProbe,
    "预估互动单价（图文）": metrics.pictureEngageCost,
    "预估互动单价（视频）": metrics.videoEngageCost,
    "预估外溢进店单价（图文）": metrics.pictureStoreCost,
    "预估外溢进店单价（视频）": metrics.videoStoreCost,
    "数据表现-预估CPM": metrics.performanceCpm,
    "数据表现-预估阅读单价": metrics.performanceReadCost,
    "数据表现-预估互动单价": metrics.performanceEngageCost,
    "数据表现-外溢进店单价": metrics.performanceStoreCost,
    "中位点赞量": metrics.likeMedian,
    "中位收藏量": metrics.collectMedian,
    "中位评论量": metrics.commentMedian,
    "中位分享量": metrics.shareMedian,
    "中位关注量": metrics.followMedian,
    "互动率": metrics.interactionRate,
    "视频完播率": metrics.videoFullViewRate,
    "图文3秒阅读率": metrics.picture3sViewRate,
    "千赞笔记比例": metrics.thousandLikePercent,
    "百赞笔记比例": metrics.hundredLikePercent
  };
}

export function mapNoteFields(note, requestedFields = []) {
  if (!note) {
    return {};
  }

  const metrics = {
    resolvedPublishUrl: firstValue(note.resolvedPublishUrl, note.publishUrl),
    exposure: firstValue(note.impNum, note.exposureNum, note.impressionNum),
    read: firstValue(note.readNum, note.readUserNum, note.readCount, note.effectiveReadNum),
    like: firstValue(note.likeNum, note.likeCount, note.likedCount, note.likes),
    collect: firstValue(note.collectNum, note.favNum, note.favCount, note.collectCount, note.collectedCount, note.collects),
    share: firstValue(note.shareNum, note.shareCount, note.shares),
    follow: firstValue(note.followNum, note.followCount, note.followCnt),
    interaction: firstValue(note.interactionNum, note.interactCount, note.engageNum, sumInteraction(note))
  };
  discardImpossibleTraffic(metrics);
  discardAccountLevelNoteNoise(metrics);
  metrics.comment = firstValue(
    note.commentNum,
    note.cmtNum,
    note.commentCount,
    note.comments,
    inferCommentCount(metrics)
  );
  metrics.follow = firstValue(metrics.follow, inferFollowCount(metrics));
  metrics.collect = firstValue(metrics.collect, inferCollectCount(metrics));
  const fields = requestedFields.length ? requestedFields : ["曝光量", "阅读量", "点赞", "收藏", "评论", "转发", "总互动"];

  return fields.reduce((acc, field) => {
    const value = resolveNoteMetricValue(metrics, field);
    if (value !== undefined) {
      acc[field] = value;
    }
    return acc;
  }, {});
}

function discardImpossibleTraffic(metrics) {
  const exposure = toNumber(metrics.exposure);
  const read = toNumber(metrics.read);
  const like = toNumber(metrics.like);
  const interaction = toNumber(metrics.interaction);

  if (Number.isFinite(exposure) && Number.isFinite(read) && exposure >= 1000 && read > 0 && read < exposure * 0.001) {
    metrics.read = null;
  }

  if (Number.isFinite(interaction) && Number.isFinite(like) && interaction > 0 && like > interaction) {
    metrics.like = null;
  }
}

function discardAccountLevelNoteNoise(metrics) {
  for (const key of ["like", "collect", "comment", "share", "follow", "interaction"]) {
    if (isHugeMetric(metrics[key]) || isImpossibleNotePart(key, metrics[key], metrics)) {
      metrics[key] = null;
    }
  }
}

function isFiniteMetric(value) {
  const numeric = toNumber(value);
  return Number.isFinite(numeric) && numeric > 0;
}

function isHugeMetric(value) {
  const numeric = toNumber(value);
  return Number.isFinite(numeric) && numeric >= 1000000;
}

function isImpossibleNotePart(key, value, metrics) {
  const numeric = toNumber(value);
  const read = toNumber(metrics.read);
  const interaction = toNumber(metrics.interaction);
  if (key === "collect" && Number.isFinite(interaction) && interaction > 0) {
    return numeric > interaction;
  }

  return Number.isFinite(numeric) && Number.isFinite(read) && read > 0 && numeric > read * 2;
}

function toNumber(value) {
  return typeof value === "number"
    ? value
    : Number(String(value ?? "").replace(/,/g, ""));
}

function buildAccountMetrics(bundle, cooperationType, collectionOptions = {}) {
  const filters = normalizePgyFilters(bundle.collectionOptions ?? collectionOptions);
  const basicData = unwrap(bundle.basicData);
  const resolvedCreator = unwrap(bundle.fdResolvedCreator);
  const selectedPerformance = buildSelectedPerformance(bundle, filters);
  const dailyAllTraffic30 = unwrap(bundle.fdRecentPerformance);
  const pageCostMetrics = unwrap(bundle.fdPageCostMetrics);
  const dailyPicture30 = mergeMetrics(
    unwrap(bundle.fdDailyPicturePerformance),
    unwrap(bundle.fdDailyPicturePerformanceAlt)
  );
  const dailyVideo30 = mergeMetrics(
    unwrap(bundle.fdDailyVideoPerformance),
    unwrap(bundle.fdDailyVideoPerformanceAlt)
  );
  const coopPerformance90 = unwrap(bundle.fdNinetyPgyRecentPerformance);
  const coopPerformance30 = unwrap(bundle.fdThirtyCooperateRecentPerformance);
  const costEffective = unwrap(bundle.fdCostEffective);
  const isVideo = String(cooperationType ?? "").includes("视频");
  const isPicture = String(cooperationType ?? "").includes("图文");
  const selectedPerformancePayload = unwrap(bundle.fdSelectedPerformance);
  const selectedCoreData = unwrap(bundle.fdSelectedCoreData)?.sumData ?? unwrap(bundle.fdSelectedCoreData);
  const primaryPerformance = selectedPerformance;
  const primaryPerformanceSource = mergeMetrics(primaryPerformance, selectedPerformancePayload);
  const primaryCoreSource = mergeMetrics(selectedCoreData, primaryPerformanceSource);
  const basePrice = isVideo ? basicData?.videoPrice : basicData?.picturePrice;
  const costKeys = [
    "estimatePictureCpm",
    "estimateVideoCpm",
    "pictureCpm",
    "videoCpm",
    "estimateCpm",
    "cpm",
    "estimatePicReadPrice",
    "estimatePictureReadPrice",
    "estimateVideoReadPrice",
    "pictureReadCost",
    "videoReadCost",
    "pictureReadPrice",
    "videoReadPrice",
    "estimateReadPrice",
    "readCost",
    "readPrice",
    "estimatePictureEngageCost",
    "estimateVideoEngageCost",
    "pictureEngageCost",
    "videoEngageCost",
    "estimatePictureStoreCost",
    "estimateVideoStoreCost",
    "pictureStoreCost",
    "videoStoreCost"
  ];
  const pictureCpm = pageCostMetrics?.pictureCpm ?? null;
  const videoCpm = pageCostMetrics?.videoCpm ?? null;
  const pictureReadCost = pageCostMetrics?.pictureReadCost ?? null;
  const videoReadCost = pageCostMetrics?.videoReadCost ?? null;
  const rawPictureReadCost = pickCostMetric(dailyPicture30, [
    "estimatePicReadPrice",
    "estimatePictureReadPrice",
    "pictureReadCost",
    "pictureReadPrice",
    "estimateReadPrice",
    "readCost",
    "readPrice"
  ]);
  const rawVideoReadCost = pickCostMetric(dailyVideo30, [
    "estimateVideoReadPrice",
    "videoReadCost",
    "videoReadPrice",
    "estimateReadPrice",
    "readCost",
    "readPrice"
  ]);

  return {
    creatorId: firstNonEmpty(
      resolvedCreator?.redId,
      basicData?.redId,
      basicData?.red_id,
      basicData?.xhsId,
      basicData?.xhs_id,
      resolvedCreator?.userId,
      basicData?.userId
    ),
    creatorNickname: firstNonEmpty(
      resolvedCreator?.nickname,
      basicData?.nickName,
      basicData?.nickname,
      basicData?.name,
      basicData?.userName
    ),
    pgyProfileUrl: firstNonEmpty(
      resolvedCreator?.pgyProfileUrl,
      resolvedCreator?.userId ? buildPgyProfileUrl(resolvedCreator.userId) : "",
      basicData?.userId ? buildPgyProfileUrl(basicData.userId) : ""
    ),
    xhsProfileUrl: firstNonEmpty(
      resolvedCreator?.xhsProfileUrl,
      resolvedCreator?.userId ? buildXhsProfileUrl(resolvedCreator.userId) : "",
      basicData?.userId ? buildXhsProfileUrl(basicData.userId) : ""
    ),
    contentCategory: formatContentCategory(basicData),
    fansCount: basicData?.fansCount ?? null,
    fansCountWan: basicData?.fansCount == null ? null : round(basicData.fansCount / 10000, 2),
    platformBasePrice: basePrice ?? null,
    platformServicePrice: basePrice == null ? null : round(basePrice * 1.1, 2),
    picturePrice: basicData?.picturePrice ?? null,
    videoPrice: basicData?.videoPrice ?? null,

    impMedian: selectedCoreData?.imp ?? primaryPerformance?.impMedian ?? null,
    readMedian: selectedCoreData?.read ?? primaryPerformance?.readMedian ?? null,
    interactionMedian: firstValue(
      selectedCoreData?.engage,
      primaryPerformance?.mEngagementNum,
      primaryPerformance?.mEngagementNumMcn,
      primaryPerformance?.mengagementNum,
      primaryPerformance?.interactionMedian
    ),
    storeMedian: firstValue(
      selectedCoreData?.thirdUserNum,
      pickCostMetric(primaryPerformanceSource, [
        "外溢进店中位数",
        "进店中位数",
        "shopVisitMedian",
        "shopVisitNumMedian",
        "shopVisitCntMedian",
        "storeVisitMedian",
        "storeVisitNumMedian",
        "storeMedian",
        "overflowStoreMedian",
        "overflowStoreNumMedian",
        "outerStoreMedian",
        "outShopMedian",
        "mShopVisitNum",
        "mShopVisitCnt",
        "mStoreVisitNum",
        "mStoreVisitCnt",
        "mOuterStoreNum",
        "mOverflowStoreNum",
        "shopVisitNum",
        "shopVisitCnt",
        "storeVisitNum",
        "storeVisitCnt"
      ]),
      findValueByKeyMatching(primaryPerformanceSource, isStoreMedianKeyPath)
    ),
    commonReadMedian: dailyAllTraffic30?.readMedian ?? null,
    coopReadMedian90: coopPerformance90?.readMedian ?? basicData?.readMidCoop30 ?? null,
    coopReadMedian30: coopPerformance30?.readMedian ?? null,

    cpm: isVideo ? formatCostMetric(videoCpm) : formatCostMetric(pictureCpm),
    cpe: isVideo
      ? firstValue(basicData?.estimateVideoEngageCost, primaryPerformance?.estimateVideoEngageCost, costEffective?.estimateVideoEngageCost)
      : firstValue(basicData?.estimatePictureEngageCost, primaryPerformance?.estimatePictureEngageCost, costEffective?.estimatePictureEngageCost),
    filterLabel: describePgyFilters(filters),
    pictureCpm: formatCostMetric(pictureCpm),
    videoCpm: formatCostMetric(videoCpm),
    pictureReadCost: formatCostMetric(pictureReadCost),
    videoReadCost: formatCostMetric(videoReadCost),
    costProbe: {
      fdRecentPerformance: collectMatchingFields(dailyAllTraffic30, costKeys),
      fdDailyPicturePerformance: collectMatchingFields(dailyPicture30, costKeys),
      fdDailyVideoPerformance: collectMatchingFields(dailyVideo30, costKeys),
      fdPageCostMetrics: pageCostMetrics,
      fdCostEffective: collectMatchingFields(costEffective, costKeys),
      basicData: collectMatchingFields(basicData, costKeys)
    },
    rawPictureCpm: firstValue(basicData?.estimatePictureCpm, primaryPerformance?.estimatePictureCpm, costEffective?.estimatePictureCpm),
    rawVideoCpm: firstValue(basicData?.estimateVideoCpm, primaryPerformance?.estimateVideoCpm, costEffective?.estimateVideoCpm),
    rawPictureReadCost: firstValue(
      pageCostMetrics?.pictureReadCost,
      basicData?.estimatePicReadPrice,
      basicData?.estimatePictureReadPrice,
      basicData?.pictureReadCost,
      rawPictureReadCost,
      costEffective?.estimatePicReadPrice,
      costEffective?.pictureReadCost,
      costEffective?.pictureReadPrice,
      primaryPerformance?.estimatePicReadPrice,
      null
    ),
    rawVideoReadCost: firstValue(
      pageCostMetrics?.videoReadCost,
      basicData?.estimateVideoReadPrice,
      basicData?.videoReadCost,
      rawVideoReadCost,
      costEffective?.estimateVideoReadPrice,
      costEffective?.videoReadCost,
      costEffective?.videoReadPrice,
      primaryPerformance?.estimateVideoReadPrice,
      null
    ),
    pictureEngageCost: formatCostMetric(firstValue(pageCostMetrics?.pictureEngageCost, basicData?.estimatePictureEngageCost, primaryPerformance?.estimatePictureEngageCost, costEffective?.estimatePictureEngageCost)),
    videoEngageCost: formatCostMetric(firstValue(pageCostMetrics?.videoEngageCost, basicData?.estimateVideoEngageCost, primaryPerformance?.estimateVideoEngageCost, costEffective?.estimateVideoEngageCost)),
    pictureStoreCost: formatCostMetric(pageCostMetrics?.pictureStoreCost),
    videoStoreCost: formatCostMetric(pageCostMetrics?.videoStoreCost),
    performanceCpm: formatCostMetric(pickCostMetric(primaryCoreSource, ["预估CPM", "预估cpm", "estimateCpm", "estimateCPM", "cpm", "cpmPrice", "avgCpm", "estimateAvgCpm", "expectedCpm", "estimatedCpm", "mCpm", "mCPM", "mediumCpm", "medianCpm"])),
    performanceReadCost: formatCostMetric(firstValue(selectedCoreData?.cpv, pickCostMetric(primaryCoreSource, ["预估阅读单价", "阅读单价", "estimateReadPrice", "estimateReadCost", "readCost", "readPrice", "readUnitPrice", "readUnitCost", "costPerRead", "expectedReadPrice", "estimatedReadPrice", "mReadPrice", "mReadCost", "mediumReadPrice", "medianReadPrice"]))),
    performanceEngageCost: formatCostMetric(firstValue(selectedCoreData?.cpe, pickCostMetric(primaryCoreSource, ["预估互动单价", "互动单价", "estimateEngageCost", "estimateEngagePrice", "engageCost", "engagePrice", "estimateInteractionCost", "estimateInteractionPrice", "interactionCost", "interactionPrice", "interactionUnitPrice", "costPerInteraction", "expectedInteractionPrice", "estimatedInteractionPrice", "mEngagePrice", "mEngageCost", "mInteractionPrice", "mInteractionCost", "mediumInteractionPrice", "medianInteractionPrice"]))),
    performanceStoreCost: formatCostMetric(firstValue(selectedCoreData?.cpuv, pickCostMetric(primaryCoreSource, [
      "外溢进店单价",
      "预估外溢进店单价",
      "进店单价",
      "estimateStoreCost",
      "estimateStorePrice",
      "storeCost",
      "storePrice",
      "storeUnitPrice",
      "storeUnitCost",
      "shopVisitCost",
      "shopVisitPrice",
      "shopVisitUnitCost",
      "shopVisitUnitPrice",
      "mShopVisitCost",
      "mShopVisitPrice",
      "shopVisitUnitPrice",
      "visitCost",
      "visitPrice",
      "overflowStoreCost",
      "overflowStorePrice",
      "estimateShopVisitCost",
      "estimateShopVisitPrice",
      "estimateVisitCost",
      "estimateVisitPrice",
      "estimateOverflowStoreCost",
      "estimateOverflowStorePrice",
      "expectedShopVisitCost",
      "expectedShopVisitPrice"
    ]))),

    likeMedian: primaryPerformance?.likeMedian ?? null,
    collectMedian: primaryPerformance?.collectMedian ?? null,
    commentMedian: primaryPerformance?.commentMedian ?? null,
    shareMedian: primaryPerformance?.shareMedian ?? null,
    followMedian: primaryPerformance?.mfollowCnt ?? primaryPerformance?.mFollowCnt ?? null,
    interactionRate: primaryPerformance?.interactionRate ?? null,
    videoFullViewRate: primaryPerformance?.videoFullViewRate ?? null,
    picture3sViewRate: primaryPerformance?.picture3sViewRate ?? null,
    thousandLikePercent: primaryPerformance?.thousandLikePercent ?? null,
    hundredLikePercent: primaryPerformance?.hundredLikePercent ?? null
  };
}

function resolveMetricValue(metrics, field) {
  const normalized = normalize(field);
  const aliases = [
    [["内容类目", "账号行业", "行业"], metrics.contentCategory],
    [["达人id", "达人ID", "id", "小红书号"], metrics.creatorId],
    [["达人昵称", "昵称"], metrics.creatorNickname],
    [["蒲公英主页", "蒲公英链接", "蒲公英主页链接"], metrics.pgyProfileUrl],
    [["小红书主页", "小红书链接", "主页链接"], metrics.xhsProfileUrl],
    [["粉丝量/w", "粉丝量w", "粉丝数/w"], metrics.fansCountWan],
    [["粉丝量", "粉丝数"], metrics.fansCount],
    [["平台裸价", "裸价", "报价"], metrics.platformBasePrice],
    [["平台报价含10%服务费", "平台报价（含10%服务费）", "平台报价"], metrics.platformServicePrice],
    [["图文报价", "图文价格"], metrics.picturePrice],
    [["视频报价", "视频价格"], metrics.videoPrice],
    [["曝光中位数"], metrics.impMedian],
    [["阅读中位数"], metrics.readMedian],
    [["互动中位数", "中位互动量"], metrics.interactionMedian],
    [["外溢进店中位数", "外溢中位数", "进店中位数"], metrics.storeMedian],
    [["cpm"], metrics.cpm],
    [["cpe"], metrics.cpe],
    [["预估cpm图文", "预估cpm（图文）", "图文cpm"], metrics.pictureCpm],
    [["预估cpm视频", "预估cpm（视频）", "视频cpm"], metrics.videoCpm],
    [["预估阅读单价图文", "预估阅读单价（图文）", "图文阅读单价"], metrics.pictureReadCost],
    [["预估阅读单价视频", "预估阅读单价（视频）", "视频阅读单价"], metrics.videoReadCost],
    [["预估互动单价图文", "预估互动单价（图文）", "图文互动单价"], metrics.pictureEngageCost],
    [["预估互动单价视频", "预估互动单价（视频）", "视频互动单价"], metrics.videoEngageCost],
    [["预估外溢进店单价图文", "预估外溢进店单价（图文）", "图文外溢进店单价"], metrics.pictureStoreCost],
    [["预估外溢进店单价视频", "预估外溢进店单价（视频）", "视频外溢进店单价"], metrics.videoStoreCost],
    [["数据表现口径"], metrics.filterLabel],
    [["预估cpm", "数据表现预估cpm", "数据表现-预估cpm"], metrics.performanceCpm],
    [["预估阅读单价", "数据表现预估阅读单价", "数据表现-预估阅读单价"], metrics.performanceReadCost],
    [["预估互动单价", "数据表现预估互动单价", "数据表现-预估互动单价"], metrics.performanceEngageCost],
    [["外溢进店单价", "数据表现外溢进店单价", "数据表现-外溢进店单价"], metrics.performanceStoreCost],
    [["中位点赞量", "点赞中位数"], metrics.likeMedian],
    [["中位收藏量", "收藏中位数"], metrics.collectMedian],
    [["中位评论量", "评论中位数"], metrics.commentMedian],
    [["中位分享量", "分享中位数", "中位转发量", "转发中位数"], metrics.shareMedian],
    [["中位关注量", "关注中位数"], metrics.followMedian],
    [["互动率"], metrics.interactionRate],
    [["视频完播率"], metrics.videoFullViewRate],
    [["图文3秒阅读率", "图文3s阅读率"], metrics.picture3sViewRate],
    [["千赞笔记比例"], metrics.thousandLikePercent],
    [["百赞笔记比例"], metrics.hundredLikePercent]
  ];

  const match = aliases.find(([names]) => names.some((name) => normalize(name) === normalized));
  return match ? match[1] : undefined;
}

function formatContentCategory(basicData) {
  const categories = basicData?.contentTags
    ?.map((item) => {
      const children = item.taxonomy2Tags?.length ? `-${item.taxonomy2Tags.join("/")}` : "";
      return `${item.taxonomy1Tag ?? ""}${children}`;
    })
    .filter(Boolean);

  return categories?.length ? categories.join("；") : null;
}

function sumInteraction(note) {
  const parts = [
    note.likeNum,
    firstValue(note.collectNum, note.favNum),
    firstValue(note.commentNum, note.cmtNum),
    note.shareNum
  ]
    .filter((value) => typeof value === "number");

  return parts.length ? parts.reduce((sum, value) => sum + value, 0) : null;
}

function inferCommentCount(metrics) {
  const values = [metrics.interaction, metrics.like, metrics.collect, metrics.share];
  if (values.some((value) => typeof value !== "number")) {
    return null;
  }

  const comment = metrics.interaction - metrics.like - metrics.collect - metrics.share;
  return comment >= 0 ? comment : null;
}

function inferCollectCount(metrics) {
  const values = [metrics.interaction, metrics.like, metrics.comment, metrics.share, metrics.follow];
  if (values.some((value) => typeof value !== "number")) {
    return null;
  }

  const collect = metrics.interaction - metrics.like - metrics.comment - metrics.share - metrics.follow;
  return collect >= 0 ? collect : null;
}

function inferFollowCount(metrics) {
  const values = [metrics.interaction, metrics.like, metrics.collect, metrics.comment, metrics.share];
  if (values.some((value) => typeof value !== "number")) {
    return null;
  }

  const follow = metrics.interaction - metrics.like - metrics.collect - metrics.comment - metrics.share;
  return follow >= 0 ? follow : null;
}

function resolveNoteMetricValue(metrics, field) {
  const normalized = normalize(field);
  const aliases = [
    [["转长链接", "长链接", "发布长链接"], metrics.resolvedPublishUrl],
    [["曝光量", "曝光"], metrics.exposure],
    [["阅读量", "阅读"], metrics.read],
    [["点赞", "点赞量"], metrics.like],
    [["收藏", "收藏量"], metrics.collect],
    [["评论", "评论量"], metrics.comment],
    [["转发", "转发量", "分享", "分享量"], metrics.share],
    [["关注", "关注量"], metrics.follow],
    [["总互动", "互动量"], metrics.interaction]
  ];
  const match = aliases.find(([names]) => names.some((name) => normalize(name) === normalized));
  const value = match ? match[1] : undefined;
  return value === null ? undefined : value;
}

function firstValue(...values) {
  return values.find((value) => value !== undefined && value !== null) ?? null;
}

function firstNonEmpty(...values) {
  return values.find((value) => value !== undefined && value !== null && String(value).trim() !== "") ?? null;
}

function buildPgyProfileUrl(userId) {
  return `https://pgy.xiaohongshu.com/solar/pre-trade/blogger-detail/${userId}`;
}

function buildXhsProfileUrl(userId) {
  return `https://www.xiaohongshu.com/user/profile/${userId}`;
}

function pickCostMetric(source, keys) {
  for (const key of keys) {
    const value = findValueByKey(source, key);
    if (value !== undefined && value !== null && value !== "") {
      return value;
    }
  }

  return null;
}

function findValueByKey(source, key) {
  if (!source || typeof source !== "object") {
    return undefined;
  }

  if (Object.prototype.hasOwnProperty.call(source, key)) {
    return source[key];
  }

  for (const value of Object.values(source)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        const found = findValueByKey(item, key);
        if (found !== undefined) {
          return found;
        }
      }
      continue;
    }

    if (value && typeof value === "object") {
      const found = findValueByKey(value, key);
      if (found !== undefined) {
        return found;
      }
    }
  }

  return undefined;
}

function findValueByKeyMatching(source, matcher, path = []) {
  if (!source || typeof source !== "object") {
    return undefined;
  }

  if (Array.isArray(source)) {
    for (const item of source) {
      const found = findValueByKeyMatching(item, matcher, path);
      if (found !== undefined) {
        return found;
      }
    }
    return undefined;
  }

  for (const [key, value] of Object.entries(source)) {
    const nextPath = [...path, key];
    if (matcher(nextPath) && isUsableMetricCandidate(value)) {
      return value;
    }
    if (value && typeof value === "object") {
      const found = findValueByKeyMatching(value, matcher, nextPath);
      if (found !== undefined) {
        return found;
      }
    }
  }

  return undefined;
}

function isStoreMedianKeyPath(path) {
  const normalized = normalize(path.join("."));
  const hasStoreSignal = /(进店|外溢|shop|store|visit|overflow|outer|outshop)/.test(normalized);
  const hasMedianSignal = /(中位|median|middle)/.test(normalized) || /\bm(shop|store|visit|overflow|outer)/.test(normalized);
  const hasCostSignal = /(单价|成本|价格|费率|比例|率|cost|price|rate|percent|cpm|cpe)/.test(normalized);
  return hasStoreSignal && hasMedianSignal && !hasCostSignal;
}

function isUsableMetricCandidate(value) {
  if (value === undefined || value === null) {
    return false;
  }
  const text = String(value).trim();
  if (!text || text === "-") {
    return false;
  }
  return /^-?\d+(?:,\d{3})*(?:\.\d+)?%?$/.test(text) || /^-?\d+(?:\.\d+)?$/.test(text);
}

function formatCostMetric(value) {
  if (value === undefined || value === null || value === "") {
    return "-";
  }

  return value;
}

function mergeMetrics(primary, fallback) {
  if (!primary && !fallback) {
    return null;
  }

  const merged = { ...(fallback ?? {}) };
  for (const [key, value] of Object.entries(primary ?? {})) {
    const fallbackValue = merged[key];
    if (isEmptyMetricValue(value) && !isEmptyMetricValue(fallbackValue)) {
      continue;
    }
    merged[key] = value;
  }

  return merged;
}

function buildSelectedPerformance(bundle, filters) {
  const selected = unwrapPerformance(bundle.fdSelectedPerformance);
  const sameScopeFallback = pickSameScopePerformance(bundle, filters);
  return mergeMetrics(selected, sameScopeFallback);
}

function pickSameScopePerformance(bundle, filters) {
  if (filters.traffic !== "all") {
    return null;
  }

  if (filters.noteType === "all" && filters.business === "daily" && filters.dateRange === "30") {
    return unwrapPerformance(bundle.fdRecentPerformance);
  }

  if (filters.noteType === "picture" && filters.business === "daily" && filters.dateRange === "30") {
    return mergeMetrics(
      unwrapPerformance(bundle.fdDailyPicturePerformance),
      unwrapPerformance(bundle.fdDailyPicturePerformanceAlt)
    );
  }

  if (filters.noteType === "video" && filters.business === "daily" && filters.dateRange === "30") {
    return mergeMetrics(
      unwrapPerformance(bundle.fdDailyVideoPerformance),
      unwrapPerformance(bundle.fdDailyVideoPerformanceAlt)
    );
  }

  if (filters.noteType === "all" && filters.business === "daily" && filters.dateRange === "90") {
    return unwrapPerformance(bundle.fdNinetyPersonalRecentPerformance);
  }

  if (filters.noteType === "all" && filters.business === "cooperation" && filters.dateRange === "30") {
    return unwrapPerformance(bundle.fdThirtyCooperateRecentPerformance);
  }

  if (filters.noteType === "all" && filters.business === "cooperation" && filters.dateRange === "90") {
    return unwrapPerformance(bundle.fdNinetyPgyRecentPerformance);
  }

  return null;
}

function isEmptyMetricValue(value) {
  return value === undefined ||
    value === null ||
    value === "" ||
    value === 0 ||
    value === "0" ||
    value === "0.0";
}

function collectMatchingFields(source, keys, path = "") {
  if (!source || typeof source !== "object") {
    return {};
  }

  return Object.entries(source).reduce((acc, [key, value]) => {
    const nextPath = path ? `${path}.${key}` : key;
    if (keys.includes(key) || /cpm|cost|price|read/i.test(key)) {
      if (value == null || typeof value !== "object") {
        acc[nextPath] = value;
      }
    }

    if (value && typeof value === "object") {
      Object.assign(acc, collectMatchingFields(value, keys, nextPath));
    }

    return acc;
  }, {});
}

function round(value, digits) {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function normalizePgyFilters(options = {}) {
  return {
    business: ["daily", "cooperation"].includes(options?.business) ? options.business : PGY_DEFAULT_FILTERS.business,
    noteType: ["all", "picture", "video"].includes(options?.noteType) ? options.noteType : PGY_DEFAULT_FILTERS.noteType,
    dateRange: ["30", "90", 30, 90].includes(options?.dateRange) ? String(options.dateRange) : PGY_DEFAULT_FILTERS.dateRange,
    traffic: ["all", "natural"].includes(options?.traffic) ? options.traffic : PGY_DEFAULT_FILTERS.traffic
  };
}

function describePgyFilters(options = {}) {
  const filters = normalizePgyFilters(options);
  return [
    PGY_FILTER_LABELS.business[filters.business],
    PGY_FILTER_LABELS.noteType[filters.noteType],
    PGY_FILTER_LABELS.dateRange[filters.dateRange],
    PGY_FILTER_LABELS.traffic[filters.traffic]
  ].filter(Boolean).join(" / ");
}

function normalize(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[()]/g, (token) => (token === "(" ? "（" : "）"))
    .toLowerCase()
    .trim();
}

function unwrap(payload) {
  return payload?.data ?? payload ?? null;
}

function unwrapPerformance(payload) {
  const data = unwrap(payload);
  if (!data || typeof data !== "object") {
    return data;
  }

  if (hasPerformanceMetrics(data)) {
    return data;
  }

  return findPerformanceObject(data) ?? data;
}

function findPerformanceObject(value, depth = 0) {
  if (!value || typeof value !== "object" || depth > 6) {
    return null;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findPerformanceObject(item, depth + 1);
      if (found) {
        return found;
      }
    }
    return null;
  }

  if (hasPerformanceMetrics(value)) {
    return value;
  }

  for (const child of Object.values(value)) {
    const found = findPerformanceObject(child, depth + 1);
    if (found) {
      return found;
    }
  }

  return null;
}

function hasPerformanceMetrics(value) {
  if (!value || typeof value !== "object") {
    return false;
  }

  return [
    "impMedian",
    "readMedian",
    "mEngagementNum",
    "mEngagementNumMcn",
    "interactionMedian",
    "likeMedian",
    "collectMedian",
    "commentMedian",
    "shareMedian",
    "estimateCpm",
    "estimateReadPrice",
    "estimateEngageCost",
    "estimateStoreCost"
  ].some((key) => Object.prototype.hasOwnProperty.call(value, key));
}
