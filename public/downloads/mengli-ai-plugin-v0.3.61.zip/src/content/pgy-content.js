const PGY_CONTENT_VERSION = "2026-06-03-data-performance-v14";
const STORE_MEDIAN_LABELS = [
  "外溢进店中位数",
  "外溢进店人数中位数",
  "外溢进店量中位数",
  "外溢中位数",
  "进店中位数",
  "进店人数中位数",
  "外溢进店",
  "进店"
];

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.source !== "media-data-collector") {
    return false;
  }

  if (message.action === "ping") {
    sendResponse({ ok: true, version: PGY_CONTENT_VERSION });
    return false;
  }

  if (message.action === "collect-account-metrics") {
    collectAccountMetrics(message.payload)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ error: error.message }));
    return true;
  }

  if (message.action === "collect-note-metrics") {
    collectNoteMetrics(message.payload)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ error: error.message }));
    return true;
  }

  if (message.action === "collect-row-metrics") {
    collectRowMetrics(message.payload)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ error: error.message }));
    return true;
  }

  if (message.action === "collect-note-popup-metrics") {
    collectNotePopupMetrics(message.payload)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ error: error.message }));
    return true;
  }

  if (message.action === "collect-visible-selected-performance" || message.action === "pgy-collect-visible-selected-performance-v2") {
    collectVisibleSelectedPerformance(message.payload)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ error: error.message }));
    return true;
  }

  return false;
});

const PGY_DEFAULT_FILTERS = Object.freeze({
  business: "daily",
  noteType: "all",
  dateRange: "30",
  traffic: "all"
});

function normalizePgyFilters(options = {}) {
  return {
    business: ["daily", "cooperation"].includes(options?.business) ? options.business : PGY_DEFAULT_FILTERS.business,
    noteType: ["all", "picture", "video"].includes(options?.noteType) ? options.noteType : PGY_DEFAULT_FILTERS.noteType,
    dateRange: ["30", "90", 30, 90].includes(options?.dateRange) ? String(options.dateRange) : PGY_DEFAULT_FILTERS.dateRange,
    traffic: ["all", "natural"].includes(options?.traffic) ? options.traffic : PGY_DEFAULT_FILTERS.traffic
  };
}

async function collectRowMetrics({ locators, accountFields = [], noteFields = [], collectionOptions = {} }) {
  const creator = await resolveCreator(locators, { required: accountFields.length > 0 });
  const userId = creator.userId;
  const shouldReadCostPage = shouldReadPageCostMetrics(accountFields);
  const filters = normalizePgyFilters(collectionOptions);
  const bundle = userId ? await fetchPgyBundle(userId, filters) : {};
  const pageCostResult = shouldReadCostPage ? buildApiCostResult(bundle) : emptyPageCostResult();
  const matchedNote = noteFields.length
    ? await resolvePublishedNote({ userId, bundle, publishUrl: locators.publishUrl, requestedFields: noteFields })
    : null;
  const enrichedBundle = {
    ...bundle,
    fdResolvedCreator: creator
  };

  return {
    account: accountFields.length
      ? {
          status: "ok",
          locators,
          fields: accountFields,
          userId,
          bundle: {
            ...enrichedBundle,
            fdPageCostMetrics: pageCostResult.metrics,
            fdPageSnapshot: pageCostResult.debug
          }
        }
      : null,
    note: noteFields.length
      ? {
          status: "ok",
          locators,
          fields: noteFields,
          userId,
          bundle: enrichedBundle,
          matchedNote
        }
      : null
  };
}

async function collectAccountMetrics({ locators, fields, collectionOptions = {} }) {
  const creator = await resolveCreator(locators);
  const userId = creator.userId;
  const shouldReadCostPage = shouldReadPageCostMetrics(fields);
  const filters = normalizePgyFilters(collectionOptions);
  const bundle = await fetchPgyBundle(userId, filters);
  const pageCostResult = shouldReadCostPage ? buildApiCostResult(bundle) : emptyPageCostResult();

  return {
    status: "ok",
    locators,
    fields,
    userId,
    bundle: {
      ...bundle,
      fdResolvedCreator: creator,
      fdPageCostMetrics: pageCostResult.metrics,
      fdPageSnapshot: pageCostResult.debug
    }
  };
}

function shouldReadPageCostMetrics(fields = []) {
  return fields.some(isVariantCostField);
}

function isVariantCostField(field) {
  const normalized = normalizeMetricName(field);
  return /(?:图文|视频)/.test(normalized) &&
    /(?:cpm|阅读单价|互动单价|外溢进店|进店单价)/i.test(normalized);
}

function normalizeMetricName(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[()]/g, (token) => (token === "(" ? "（" : "）"))
    .toLowerCase()
    .trim();
}

function emptyPageCostResult() {
  return {
    metrics: emptyCostMetrics(),
    debug: null
  };
}

function buildApiCostResult(bundle) {
  const metrics = deriveApiCostMetrics(bundle);

  return {
    metrics,
    debug: {
      url: location.href,
      title: document.title,
      mode: "api-only",
      source: "pgy-data-summary",
      hasAnyMetric: hasAnyMetric(metrics)
    }
  };
}

function deriveApiCostMetrics(bundle) {
  const personalSummary = unwrap(bundle.fdDataSummaryPersonal);
  const coopSummary = unwrap(bundle.fdDataSummaryCooperation);
  const costEffective = unwrap(bundle.fdCostEffective);
  const basicData = unwrap(bundle.basicData);
  const summarySources = [coopSummary, personalSummary];
  const sources = [coopSummary, personalSummary, costEffective, basicData];

  return {
    pictureCpm: firstPresentInSources(sources, [
      "pictureCpm",
      "estimatePictureCpm",
      "estimatePicCpm",
      "picCpm"
    ]) ?? findMetricByLabels(sources, ["预估CPM（图文）", "预估CPM(图文)", "图文CPM"]),
    videoCpm: firstPresentInSources(sources, [
      "videoCpm",
      "estimateVideoCpm"
    ]) ?? findMetricByLabels(sources, ["预估CPM（视频）", "预估CPM(视频)", "视频CPM"]),
    pictureReadCost: findMetricByLabels(summarySources, ["预估阅读单价（图文）", "预估阅读单价(图文)", "图文阅读单价"], { readCost: true }) ?? firstPresentInSources(sources, [
      "pictureReadCost",
      "pictureReadPrice",
      "estimatePictureReadCost",
      "estimatePictureReadPrice",
      "estimatePicReadPrice"
    ], { readCost: true }),
    videoReadCost: findMetricByLabels(summarySources, ["预估阅读单价（视频）", "预估阅读单价(视频)", "视频阅读单价"], { readCost: true }) ?? firstPresentInSources(sources, [
      "videoReadCost",
      "videoReadPrice",
      "estimateVideoReadCost",
      "estimateVideoReadPrice"
    ], { readCost: true })
  };
}

function firstPresentInSources(sources, keys, options = {}) {
  for (const source of sources) {
    for (const key of keys) {
      const value = findValueByKey(source, key);
      if (value !== undefined && value !== null && value !== "" && value !== 0 && value !== "0") {
        return normalizeCostValue(value, options);
      }
    }
  }

  return null;
}

function normalizeCostValue(value, options = {}) {
  if (value === "-") {
    return value;
  }

  if (typeof value === "string") {
    const cleaned = value.replace(/,/g, "").trim();
    if (cleaned === "-" || cleaned === "0" || cleaned === "0.0" || cleaned.startsWith("- ")) {
      return "-";
    }
    const number = Number(cleaned);
    if (Number.isFinite(number)) {
      return normalizeReadCostScale(number, options);
    }
    const match = cleaned.match(/-?\d+(?:\.\d+)?/);
    return match ? normalizeReadCostScale(Number(match[0]), options) : value;
  }

  if (typeof value === "number") {
    return value === 0 ? "-" : normalizeReadCostScale(value, options);
  }

  return value;
}

function normalizeReadCostScale(value, options = {}) {
  if (!options.readCost || typeof value !== "number" || !Number.isFinite(value)) {
    return value;
  }

  if (Math.abs(value) > 20) {
    return Math.round((value / 100) * 100) / 100;
  }

  return value;
}

function findMetricByLabels(sources, labels, options = {}) {
  for (const source of sources) {
    const normalizedLabels = labels.map(normalizeText);
    const value = findMetricByLabelsInSource(source, normalizedLabels) ??
      findMetricByLabelTextWindow(source, normalizedLabels);
    if (value !== undefined && value !== null && value !== "") {
      return normalizeCostValue(value, options);
    }
  }

  return null;
}

function findMetricByLabelsInSource(source, normalizedLabels) {
  if (!source || typeof source !== "object") {
    return undefined;
  }

  if (Array.isArray(source)) {
    for (const item of source) {
      const value = findMetricByLabelsInSource(item, normalizedLabels);
      if (value !== undefined) {
        return value;
      }
    }
    return undefined;
  }

  const labelText = normalizeText([
    source.label,
    source.name,
    source.title,
    source.indicatorName,
    source.fieldName,
    source.labelName,
    source.metricName,
    source.metricLabel,
    source.text,
    source.desc
  ].filter(Boolean).join(" "));

  if (normalizedLabels.some((label) => labelText.includes(label))) {
    const value = pickMetricObjectValue(source);
    if (value !== undefined) {
      return value;
    }
  }

  for (const value of Object.values(source)) {
    const nested = findMetricByLabelsInSource(value, normalizedLabels);
    if (nested !== undefined) {
      return nested;
    }
  }

  return undefined;
}

function pickMetricObjectValue(source) {
  for (const key of ["value", "valueText", "showValue", "displayValue", "textValue", "num", "number", "amount", "cost", "price", "metricValue", "metricNum", "currentValue"]) {
    const value = source[key];
    if (value !== undefined && value !== null && typeof value !== "object") {
      return value;
    }
  }

  return undefined;
}

function findMetricByLabelTextWindow(source, normalizedLabels) {
  if (!source || typeof source !== "object") {
    return undefined;
  }

  const text = normalizeText(JSON.stringify(source));
  for (const label of normalizedLabels) {
    const index = text.indexOf(label);
    if (index < 0) {
      continue;
    }

    const windowText = text.slice(index + label.length, index + label.length + 220);
    const explicit = windowText.match(/["']?(?:value|valuetext|showvalue|displayvalue|textvalue|metricvalue|metricnum|currentvalue|num|number|amount|cost|price)["']?[:：]?["']?(-|[0-9]+(?:\.[0-9]+)?)/i);
    if (explicit) {
      return explicit[1];
    }

    const loose = windowText.match(/(-|[0-9]+(?:\.[0-9]+)?)/);
    if (loose) {
      return loose[1];
    }
  }

  return undefined;
}

function normalizeText(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[()]/g, (token) => (token === "(" ? "（" : "）"))
    .toLowerCase();
}

function findValueByKey(source, key) {
  if (!source || typeof source !== "object") {
    return undefined;
  }

  if (Object.prototype.hasOwnProperty.call(source, key)) {
    return source[key];
  }

  for (const value of Object.values(source)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        const nested = findValueByKey(item, key);
        if (nested !== undefined) {
          return nested;
        }
      }
      continue;
    }

    if (value && typeof value === "object") {
      const nested = findValueByKey(value, key);
      if (nested !== undefined) {
        return nested;
      }
    }
  }

  return undefined;
}

function findValueByKeyMatching(source, matcher, path = []) {
  if (!source || typeof source !== "object") {
    return undefined;
  }

  if (Array.isArray(source)) {
    for (const item of source) {
      const found = findValueByKeyMatching(item, matcher, path);
      if (found !== undefined) {
        return found;
      }
    }
    return undefined;
  }

  for (const [key, value] of Object.entries(source)) {
    const nextPath = [...path, key];
    if (matcher(nextPath) && isUsableMetricCandidate(value)) {
      return value;
    }
    if (value && typeof value === "object") {
      const found = findValueByKeyMatching(value, matcher, nextPath);
      if (found !== undefined) {
        return found;
      }
    }
  }

  return undefined;
}

function isStoreMedianKeyPath(path) {
  const normalized = normalizeText(path.join("."));
  const hasStoreSignal = /(进店|外溢|shop|store|visit|overflow|outer|outshop)/.test(normalized);
  const hasMedianSignal = /(中位|median|middle)/.test(normalized) || /\bm(shop|store|visit|overflow|outer)/.test(normalized);
  const hasCostSignal = /(单价|成本|价格|费率|比例|率|cost|price|rate|percent|cpm|cpe)/.test(normalized);
  return hasStoreSignal && hasMedianSignal && !hasCostSignal;
}

function isUsableMetricCandidate(value) {
  if (value === undefined || value === null) {
    return false;
  }
  const text = String(value).trim();
  if (!text || text === "-") {
    return false;
  }
  return /^-?\d+(?:,\d{3})*(?:\.\d+)?%?$/.test(text) || /^-?\d+(?:\.\d+)?$/.test(text);
}

function unwrap(payload) {
  if (!payload || typeof payload !== "object") {
    return payload;
  }

  if (Object.prototype.hasOwnProperty.call(payload, "data")) {
    return payload.data;
  }

  return payload;
}

async function collectNoteMetrics({ locators, fields, collectionOptions = {} }) {
  const creator = await resolveCreator(locators, { required: false });
  const userId = creator.userId;
  const filters = normalizePgyFilters(collectionOptions);
  const bundle = userId ? await fetchPgyBundle(userId, filters) : {};
  const matchedNote = await resolvePublishedNote({ userId, bundle, publishUrl: locators.publishUrl, requestedFields: fields });

  return {
    status: "ok",
    locators,
    fields,
    userId,
    bundle: {
      ...bundle,
      fdResolvedCreator: creator
    },
    matchedNote
  };
}

async function collectNotePopupMetrics({ locators, matchedNote }) {
  const noteId = matchedNote?.noteId || extractNoteId(locators?.publishUrl);
  const title = matchedNote?.title ?? "";
  const debug = {
    url: location.href,
    title: document.title,
    noteId,
    noteTitle: title,
    attempts: []
  };

  clickTextIfVisible("笔记数据");
  await sleep(700);

  const candidates = await findNoteCardCandidates({ noteId, title, note: matchedNote });
  debug.candidateCount = candidates.length;
  debug.candidates = candidates.slice(0, 8).map(describeElement);

  for (const candidate of candidates.slice(0, 10)) {
    const clickable = findNoteCoverClickable(candidate) ?? candidate;
    dispatchHumanClick(clickable);
    await sleep(1000);

    const popupText = pickPopupText();
    const metrics = parseNotePopupMetrics(popupText);
    const attempt = {
      clicked: describeElement(clickable),
      popupTextProbe: popupText.slice(0, 500).replace(/\s+/g, " "),
      metrics
    };
    debug.attempts.push(attempt);

    if (hasAnyNoteMetric(metrics)) {
      closePopupIfOpen();
      return {
        status: "ok",
        metrics,
        accountMetrics: {},
        debug
      };
    }

    closePopupIfOpen();
    await sleep(300);
  }

  return {
    status: "empty",
    metrics: null,
    accountMetrics: {},
    debug
  };
}

async function readVisibleDetailAccountMetrics() {
  const scaleText = document.body?.innerText ?? "";
  clickTextIfVisible("按成本");
  await sleep(500);
  const costText = document.body?.innerText ?? "";

  return {
    "曝光中位数": pickVisibleMetric(scaleText, ["曝光中位数"]),
    "阅读中位数": pickVisibleMetric(scaleText, ["阅读中位数"]),
    "互动中位数": pickVisibleMetric(scaleText, ["互动中位数"]),
    "中位点赞量": pickVisibleMetric(scaleText, ["中位点赞量", "点赞中位数"]),
    "中位收藏量": pickVisibleMetric(scaleText, ["中位收藏量", "收藏中位数"]),
    "中位评论量": pickVisibleMetric(scaleText, ["中位评论量", "评论中位数"]),
    "中位分享量": pickVisibleMetric(scaleText, ["中位分享量", "分享中位数"]),
    "中位关注量": pickVisibleMetric(scaleText, ["中位关注量", "关注中位数"]),
    "视频完播率": pickVisibleMetric(scaleText, ["视频完播率"]),
    "千赞笔记比例": pickVisibleMetric(scaleText, ["千赞笔记比例"]),
    "百赞笔记比例": pickVisibleMetric(scaleText, ["百赞笔记比例"]),
    "预估cpm（图文）": pickVisibleMetric(costText, ["预估CPM（图文）", "预估CPM(图文)"]),
    "预估cpm（视频）": pickVisibleMetric(costText, ["预估CPM（视频）", "预估CPM(视频)"]),
    "预估阅读单价（图文）": pickVisibleMetric(costText, ["预估阅读单价（图文）", "预估阅读单价(图文)"]),
    "预估阅读单价（视频）": pickVisibleMetric(costText, ["预估阅读单价（视频）", "预估阅读单价(视频)"])
  };
}

async function collectVisibleSelectedPerformance({ collectionOptions = {} } = {}) {
  const filters = normalizePgyFilters(collectionOptions);
  clickTextIfVisible("笔记数据");
  await sleep(700);
  let section = findDataPerformanceSection();
  section?.scrollIntoView?.({ block: "center" });
  await sleep(300);

  const filterState = await applyDataPerformanceFilters(filters);
  const filterWarning = filterState.ok
    ? null
    : `数据表现页面筛选校验未通过：期望 ${Object.values(filterState.expected).join(" / ")}，当前 ${Object.values(filterState.current).filter(Boolean).join(" / ") || "未读取到"}`;
  section = findDataPerformanceSection() ?? section;

  clickTextInDataPerformance("按规模");
  await sleep(600);
  const scaleText = readDataPerformanceText(section);

  clickTextInDataPerformance("按成本");
  await sleep(700);
  section = findDataPerformanceSection() ?? section;
  const costText = readDataPerformanceText(section);

  const mergedText = `${scaleText}
${costText}`;

  const pageMetrics = {
    "曝光中位数": pickVisibleMetric(scaleText, ["曝光中位数"]),
    "阅读中位数": pickVisibleMetric(scaleText, ["阅读中位数"]),
    "互动中位数": pickVisibleMetric(scaleText, ["互动中位数"]),
    "中位互动量": pickVisibleMetric(scaleText, ["互动中位数", "中位互动量"]),
    "外溢进店中位数": pickDataPerformanceCardMetric(STORE_MEDIAN_LABELS) ?? pickVisibleMetric(scaleText, STORE_MEDIAN_LABELS),
    "外溢中位数": pickDataPerformanceCardMetric(STORE_MEDIAN_LABELS) ?? pickVisibleMetric(scaleText, STORE_MEDIAN_LABELS),
    "预估cpm": pickDataPerformanceCardMetric(["预估CPM", "预估cpm"]) ?? pickVisibleMetric(costText, ["预估CPM", "预估cpm"]),
    "数据表现-预估CPM": pickDataPerformanceCardMetric(["预估CPM", "预估cpm"]) ?? pickVisibleMetric(costText, ["预估CPM", "预估cpm"]),
    "预估阅读单价": pickDataPerformanceCardMetric(["预估阅读单价", "阅读单价"]) ?? pickVisibleMetric(costText, ["预估阅读单价", "阅读单价"]),
    "数据表现-预估阅读单价": pickDataPerformanceCardMetric(["预估阅读单价", "阅读单价"]) ?? pickVisibleMetric(costText, ["预估阅读单价", "阅读单价"]),
    "预估互动单价": pickDataPerformanceCardMetric(["预估互动单价", "互动单价"]) ?? pickVisibleMetric(costText, ["预估互动单价", "互动单价"]),
    "数据表现-预估互动单价": pickDataPerformanceCardMetric(["预估互动单价", "互动单价"]) ?? pickVisibleMetric(costText, ["预估互动单价", "互动单价"]),
    "外溢进店单价": pickDataPerformanceCardMetric(["外溢进店单价", "外溢进店", "进店单价", "进店"]) ?? pickVisibleMetric(costText, ["外溢进店单价", "外溢进店", "进店单价", "进店"]),
    "数据表现-外溢进店单价": pickDataPerformanceCardMetric(["外溢进店单价", "外溢进店", "进店单价", "进店"]) ?? pickVisibleMetric(costText, ["外溢进店单价", "外溢进店", "进店单价", "进店"]),
    "中位点赞量": pickVisibleMetric(mergedText, ["中位点赞量", "点赞中位数"]),
    "中位收藏量": pickVisibleMetric(mergedText, ["中位收藏量", "收藏中位数"]),
    "中位评论量": pickVisibleMetric(mergedText, ["中位评论量", "评论中位数"]),
    "中位分享量": pickVisibleMetric(mergedText, ["中位分享量", "分享中位数"]),
    "中位关注量": pickVisibleMetric(mergedText, ["中位关注量", "关注中位数"]),
    "互动率": pickVisibleMetric(mergedText, ["互动率"]),
    "视频完播率": pickVisibleMetric(mergedText, ["视频完播率"]),
    "图文3秒阅读率": pickVisibleMetric(mergedText, ["图文3秒阅读率", "图文3s阅读率"]),
    "千赞笔记比例": pickVisibleMetric(mergedText, ["千赞笔记比例"]),
    "百赞笔记比例": pickVisibleMetric(mergedText, ["百赞笔记比例"])
  };

  return {
    status: "ok",
    filters,
    metrics: pageMetrics,
    debug: {
      url: location.href,
      title: document.title,
      hasSection: Boolean(section),
      filterState,
      filterWarning,
      trustPageMetrics: filterState.ok,
      pageMetricKeys: Object.keys(compactMetricObject(pageMetrics)),
      scaleProbe: scaleText.slice(0, 500).replace(/\s+/g, " "),
      costProbe: costText.slice(0, 500).replace(/\s+/g, " ")
    }
  };
}

async function collectSelectedPerformanceApiMetrics(userId, filters) {
  const payload = await fetchSelectedPerformance(userId, filters);
  const performance = findSelectedPerformanceObject(payload?.data ?? payload);
  if (!performance) {
    return {};
  }
  const interactionMedian = firstPresent(
    findValueByKey(performance, "mEngagementNum"),
    findValueByKey(performance, "mEngagementNumMcn"),
    findValueByKey(performance, "mengagementNum"),
    findValueByKey(performance, "interactionMedian")
  );
  const storeMedian = firstPresent(
    findValueByKey(performance, "shopVisitMedian"),
    findValueByKey(performance, "shopVisitNumMedian"),
    findValueByKey(performance, "shopVisitCntMedian"),
    findValueByKey(performance, "storeVisitMedian"),
    findValueByKey(performance, "storeMedian"),
    findValueByKey(performance, "overflowStoreMedian"),
    findValueByKey(performance, "mShopVisitNum"),
    findValueByKey(performance, "mShopVisitCnt"),
    findValueByKey(performance, "mStoreVisitNum"),
    findValueByKey(performance, "shopVisitNum"),
    findValueByKey(performance, "shopVisitCnt"),
    findValueByKeyMatching(performance, isStoreMedianKeyPath)
  );
  const cpm = firstPresent(findValueByKey(performance, "estimateCpm"), findValueByKey(performance, "cpm"), findValueByKey(performance, "estimateAvgCpm"));
  const readCost = firstPresent(findValueByKey(performance, "estimateReadPrice"), findValueByKey(performance, "estimateReadCost"), findValueByKey(performance, "readCost"), findValueByKey(performance, "readPrice"));
  const engageCost = firstPresent(findValueByKey(performance, "estimateEngageCost"), findValueByKey(performance, "engageCost"), findValueByKey(performance, "engagePrice"), findValueByKey(performance, "estimateInteractionCost"), findValueByKey(performance, "interactionCost"));
  const storeCost = firstPresent(findValueByKey(performance, "estimateStoreCost"), findValueByKey(performance, "storeCost"), findValueByKey(performance, "storePrice"), findValueByKey(performance, "shopVisitCost"), findValueByKey(performance, "visitCost"), findValueByKey(performance, "overflowStoreCost"), findValueByKey(performance, "estimateShopVisitCost"), findValueByKey(performance, "estimateVisitCost"), findValueByKey(performance, "estimateOverflowStoreCost"));
  return compactMetricObject({
    "曝光中位数": findValueByKey(performance, "impMedian"),
    "阅读中位数": findValueByKey(performance, "readMedian"),
    "互动中位数": interactionMedian,
    "中位互动量": interactionMedian,
    "外溢进店中位数": storeMedian,
    "外溢中位数": storeMedian,
    "预估cpm": cpm,
    "数据表现-预估CPM": cpm,
    "预估阅读单价": readCost,
    "数据表现-预估阅读单价": readCost,
    "预估互动单价": engageCost,
    "数据表现-预估互动单价": engageCost,
    "外溢进店单价": storeCost,
    "数据表现-外溢进店单价": storeCost,
    "中位点赞量": findValueByKey(performance, "likeMedian"),
    "中位收藏量": findValueByKey(performance, "collectMedian"),
    "中位评论量": findValueByKey(performance, "commentMedian"),
    "中位分享量": findValueByKey(performance, "shareMedian"),
    "中位关注量": firstPresent(findValueByKey(performance, "mfollowCnt"), findValueByKey(performance, "mFollowCnt")),
    "互动率": findValueByKey(performance, "interactionRate"),
    "视频完播率": findValueByKey(performance, "videoFullViewRate"),
    "图文3秒阅读率": firstPresent(findValueByKey(performance, "picture3sViewRate"), findValueByKey(performance, "picture3sReadRate")),
    "千赞笔记比例": findValueByKey(performance, "thousandLikePercent"),
    "百赞笔记比例": findValueByKey(performance, "hundredLikePercent")
  });
}

function mergeMetricObjects(primary = {}, fallback = {}) {
  const merged = { ...primary };
  for (const [key, value] of Object.entries(fallback ?? {})) {
    if (isCollectedMetricEmpty(merged[key]) && !isCollectedMetricEmpty(value)) {
      merged[key] = value;
    }
  }
  return compactMetricObject(merged);
}

function corePerformanceMetricsMatch(apiMetrics = {}, pageMetrics = {}) {
  const coreFields = ["曝光中位数", "阅读中位数", "互动中位数"];
  let compared = 0;
  for (const field of coreFields) {
    const apiValue = toComparableMetric(apiMetrics[field]);
    const pageValue = toComparableMetric(pageMetrics[field]);
    if (apiValue === null || pageValue === null) {
      continue;
    }
    compared += 1;
    if (apiValue !== pageValue) {
      return false;
    }
  }
  return compared >= 2;
}

function toComparableMetric(value) {
  if (isCollectedMetricEmpty(value) || value === "-") {
    return null;
  }
  const parsed = Number(String(value).replace(/,/g, "").replace(/%$/, ""));
  return Number.isFinite(parsed) ? parsed : null;
}

function compactMetricObject(metrics = {}) {
  return Object.fromEntries(Object.entries(metrics).filter(([, value]) => !isCollectedMetricEmpty(value)));
}

function isCollectedMetricEmpty(value) {
  return value === undefined || value === null || String(value).trim() === "";
}

async function applyDataPerformanceFilters(filters) {
  const businessLabel = filters.business === "cooperation" ? "合作笔记" : "日常笔记";
  await ensureDataPerformanceTab(businessLabel);
  await ensureDataPerformanceDropdown(["图文+视频", "图文", "视频"], filters.noteType === "picture" ? "图文" : filters.noteType === "video" ? "视频" : "图文+视频");
  await ensureDataPerformanceDropdown(["近30日", "近90日"], filters.dateRange === "90" ? "近90日" : "近30日");
  await ensureDataPerformanceDropdown(["全流量", "仅自然流量"], filters.traffic === "natural" ? "仅自然流量" : "全流量");
  return waitForDataPerformanceFilters(filters);
}

async function ensureDataPerformanceTab(desired) {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const target = findDataPerformanceControl(desired);
    if (target) {
      target.click();
    }
    await sleep(500);
    if (isDataPerformanceTabSelected(desired)) {
      return;
    }
  }
}

async function ensureDataPerformanceDropdown(options, desired) {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const current = getCurrentDataPerformanceOption(options);
    if (current === desired) {
      return;
    }
    if (current && clickVisibleTextInDataPerformance(current)) {
      await sleep(350);
    } else {
      const opener = findDataPerformanceDropdownTrigger(options);
      if (opener) {
      await openDropdownFromTrigger(opener, desired);
      }
    }
    const option = findDropdownOptionElement(desired);
    if (option) {
      dispatchHumanClick(option);
    } else {
      clickVisibleTextAnywhere(desired);
    }
    await sleep(650);
    if (getCurrentDataPerformanceOption(options) === desired) {
      return;
    }
  }
}

async function openDropdownFromTrigger(opener, desired) {
  const target = findClickableAncestor(opener) ?? opener;
  dispatchHumanClick(target);
  for (let attempt = 0; attempt < 8; attempt += 1) {
    await sleep(120);
    if (findDropdownOptionElement(desired)) {
      return;
    }
  }
}

async function waitForDataPerformanceFilters(filters) {
  const expected = {
    business: filters.business === "cooperation" ? "合作笔记" : "日常笔记",
    noteType: filters.noteType === "picture" ? "图文" : filters.noteType === "video" ? "视频" : "图文+视频",
    dateRange: filters.dateRange === "90" ? "近90日" : "近30日",
    traffic: filters.traffic === "natural" ? "仅自然流量" : "全流量"
  };
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const current = getCurrentDataPerformanceFilters(expected);
    if (current.ok) {
      return current;
    }
    await sleep(300);
  }
  return getCurrentDataPerformanceFilters(expected);
}

function getCurrentDataPerformanceFilters(expected) {
  const current = {
    business: getSelectedDataPerformanceTab(["日常笔记", "合作笔记"]) ?? expected.business,
    noteType: getCurrentDataPerformanceOption(["图文+视频", "图文", "视频"]),
    dateRange: getCurrentDataPerformanceOption(["近30日", "近90日"]),
    traffic: getCurrentDataPerformanceOption(["全流量", "仅自然流量"])
  };
  return {
    ok: current.business === expected.business &&
      current.noteType === expected.noteType &&
      current.dateRange === expected.dateRange &&
      current.traffic === expected.traffic,
    expected,
    current
  };
}

function getCurrentDataPerformanceOption(options) {
  const section = findDataPerformanceSection();
  const boundedText = readBoundedDataPerformanceText();
  const sectionText = section?.innerText ?? "";
  const bodyText = document.body?.innerText ?? "";
  const bodyStart = bodyText.lastIndexOf("数据表现");
  const bodyEnd = bodyText.indexOf("粉丝分析", bodyStart);
  const bodyPerformanceText = bodyStart > -1 ? bodyText.slice(bodyStart, bodyEnd > bodyStart ? bodyEnd : bodyStart + 2500) : "";
  const visibleText = `${boundedText}\n${sectionText}\n${bodyPerformanceText}`;
  const fromText = options.find((option) => visibleText.includes(option));
  if (fromText) {
    return fromText;
  }
  return options.find((option) => findExactTextElement(option, section, isInDataPerformanceBounds)) ?? null;
}

function findDataPerformanceDropdownTrigger(options) {
  const section = findDataPerformanceSection();
  if (!section) {
    return null;
  }
  const candidates = Array.from(section.querySelectorAll("button, [role='button'], .ant-select-selector, .ant-select, span, div"))
    .filter(isElementVisible)
    .filter(isInDataPerformanceBounds)
    .filter((element) => {
      const text = (element.innerText ?? "").replace(/\s+/g, "");
      return text.length <= 80 && options.some((option) => text.includes(option.replace(/\s+/g, "")));
    })
    .sort((a, b) => {
      const textScore = (element) => (element.innerText ?? "").replace(/\s+/g, "").length;
      const areaScore = (element) => {
        const rect = element.getBoundingClientRect();
        return rect.width * rect.height;
      };
      return textScore(a) - textScore(b) || areaScore(a) - areaScore(b) || scoreClickableElement(b) - scoreClickableElement(a);
    });
  return candidates[0] ?? null;
}

function findDropdownOptionElement(desired) {
  const candidates = Array.from(document.querySelectorAll("[role='option'], .ant-select-item-option, .ant-dropdown-menu-item, li, button, [role='button'], span, div"))
    .filter((element) => {
      const text = element.innerText?.trim();
      return text === desired || text?.split(/\s+/).includes(desired) || (text?.length <= 40 && text?.includes(desired));
    })
    .filter(isElementVisible)
    .sort((a, b) => {
      const roleScore = (element) => element.getAttribute("role") === "option" || element.className?.toString().includes("select-item-option") ? 0 : 1;
      const lengthScore = (element) => element.innerText?.trim().length ?? 999;
      return roleScore(a) - roleScore(b) || lengthScore(a) - lengthScore(b) || scoreClickableElement(b) - scoreClickableElement(a);
    });
  return candidates.map(findClickableAncestor).find(Boolean) ?? candidates[0] ?? null;
}

function isDataPerformanceTabSelected(desired) {
  const element = findExactTextElement(desired, findDataPerformanceSection(), isInDataPerformanceBounds);
  if (!element) {
    return false;
  }
  let current = element;
  for (let depth = 0; current && depth < 4; depth += 1) {
    const ariaSelected = current.getAttribute?.("aria-selected");
    const ariaPressed = current.getAttribute?.("aria-pressed");
    const className = current.className?.toString?.() ?? "";
    if (ariaSelected === "true" || ariaPressed === "true" || /active|selected|checked/.test(className)) {
      return true;
    }
    current = current.parentElement;
  }
  return false;
}

function getSelectedDataPerformanceTab(options) {
  return options.find(isDataPerformanceTabSelected) ?? null;
}

function findDataPerformanceControl(targetText) {
  const section = findDataPerformanceSection();
  if (!section) {
    return null;
  }
  const candidates = Array.from(section.querySelectorAll("button, [role='tab'], [role='button'], .d-button, .d-segment-item, .ant-segmented-item, span, div"))
    .filter((element) => element.innerText?.trim() === targetText)
    .filter(isElementVisible)
    .filter(isInDataPerformanceBounds);
  return preferClickableElement(candidates)[0] ?? null;
}

function findClickableAncestor(element) {
  let current = element;
  for (let depth = 0; current && depth < 5; depth += 1) {
    const text = current.innerText?.trim();
    if (text === element.innerText?.trim() && isElementVisible(current)) {
      const className = current.className?.toString?.() ?? "";
      const role = current.getAttribute?.("role") ?? "";
      const tag = current.tagName?.toLowerCase?.() ?? "";
      if (tag === "button" || role === "button" || role === "option" || /select|option|dropdown|menu|item/.test(className)) {
        return current;
      }
    }
    current = current.parentElement;
  }
  return element;
}

function preferClickableElement(elements) {
  return [...elements].sort((a, b) => scoreClickableElement(b) - scoreClickableElement(a));
}

function scoreClickableElement(element) {
  const className = element.className?.toString?.() ?? "";
  const role = element.getAttribute?.("role") ?? "";
  const tag = element.tagName?.toLowerCase?.() ?? "";
  let score = 0;
  if (tag === "button") score += 10;
  if (role === "button" || role === "tab") score += 8;
  if (/d-button|segment|select/.test(className)) score += 6;
  if (/content|text/.test(className)) score -= 3;
  return score;
}

function findDataPerformanceSection() {
  const heading = findDataPerformanceHeading();
  if (!heading) {
    return null;
  }
  let best = null;
  let current = heading;
  for (let depth = 0; current && depth < 12; depth += 1) {
    const text = current.innerText ?? "";
    if (text.includes("核心指标") && text.includes("日常笔记") && text.includes("合作笔记") && text.includes("全流量")) {
      best = current;
      break;
    }
    current = current.parentElement;
  }
  return best ?? heading.parentElement ?? heading;
}

function getDataPerformanceBounds() {
  const heading = findDataPerformanceHeading();
  if (!heading) {
    return null;
  }

  const start = heading.getBoundingClientRect().top - 8;
  const followingFanHeading = Array.from(document.querySelectorAll("body *"))
    .filter((element) => element.innerText?.trim() === "粉丝分析")
    .filter(isElementVisible)
    .map((element) => element.getBoundingClientRect().top)
    .filter((top) => top > start)
    .sort((a, b) => a - b)[0];

  return {
    top: start,
    bottom: followingFanHeading ?? Number.POSITIVE_INFINITY
  };
}

function findDataPerformanceHeading() {
  const candidates = Array.from(document.querySelectorAll("body *"))
    .filter((element) => element.innerText?.trim() === "数据表现")
    .filter(isElementVisible)
    .filter((element) => {
      const rect = element.getBoundingClientRect();
      return rect.top >= 0 && rect.height > 0;
    });
  if (!candidates.length) {
    return null;
  }
  const fanTops = Array.from(document.querySelectorAll("body *"))
    .filter((element) => element.innerText?.trim() === "粉丝分析")
    .filter(isElementVisible)
    .map((element) => element.getBoundingClientRect().top)
    .sort((a, b) => a - b);
  return candidates
    .filter((element) => {
      const top = element.getBoundingClientRect().top;
      const nextFanTop = fanTops.find((fanTop) => fanTop > top);
      return nextFanTop === undefined || top < nextFanTop;
    })
    .sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top)[0] ?? candidates[0];
}

function isInDataPerformanceBounds(element) {
  const bounds = getDataPerformanceBounds();
  if (!bounds || !element?.getBoundingClientRect) {
    return true;
  }
  const rect = element.getBoundingClientRect();
  return rect.top >= bounds.top && rect.top < bounds.bottom;
}

function readDataPerformanceText(section) {
  const bodyText = document.body?.innerText ?? "";
  const boundedText = readBoundedDataPerformanceText();
  if (boundedText) {
    return boundedText;
  }
  const text = section?.innerText ?? bodyText;
  if (section) {
    const end = text.indexOf("粉丝分析");
    return end > -1 ? text.slice(0, end) : text;
  }
  const start = bodyText.indexOf("数据表现");
  const end = bodyText.indexOf("粉丝分析", start > -1 ? start : 0);
  if (start > -1) {
    return bodyText.slice(start, end > start ? end : start + 2500);
  }
  return bodyText;
}

function readBoundedDataPerformanceText() {
  const bounds = getDataPerformanceBounds();
  if (!bounds) {
    return "";
  }
  const chunks = Array.from(document.querySelectorAll("body *"))
    .filter(isElementVisible)
    .filter(isInDataPerformanceBounds)
    .filter((element) => {
      const text = element.innerText?.trim();
      if (!text) {
        return false;
      }
      const childrenWithText = Array.from(element.children ?? [])
        .filter((child) => child.innerText?.trim())
        .length;
      return childrenWithText === 0 || text.length <= 80;
    })
    .map((element) => element.innerText.trim())
    .join("\n");
  return chunks;
}

function pickDataPerformanceCardMetric(labels) {
  const section = findDataPerformanceSection();
  if (!section) {
    return null;
  }
  for (const label of labels) {
    const labelElement = findExactTextElement(label, section, isInDataPerformanceBounds);
    if (!labelElement) {
      continue;
    }
    const card = findMetricCardContainer(labelElement);
    const value = card ? pickMetricValueFromCard(card, label) : null;
    if (value !== null) {
      return value;
    }
  }
  return null;
}

function findMetricCardContainer(labelElement) {
  let current = labelElement;
  for (let depth = 0; current && depth < 6; depth += 1) {
    const text = current.innerText ?? "";
    if (text.includes(labelElement.innerText?.trim() ?? "") && /-|[0-9]/.test(text)) {
      const rect = current.getBoundingClientRect();
      if (rect.width >= 80 && rect.height >= 40 && rect.width <= 600 && rect.height <= 260) {
        return current;
      }
    }
    current = current.parentElement;
  }
  return labelElement.parentElement ?? labelElement;
}

function pickMetricValueFromCard(card, label) {
  const normalizedLabel = normalizeVisibleText(label);
  const candidates = Array.from(card.querySelectorAll("span, div, p, strong"))
    .filter(isElementVisible)
    .filter((element) => element !== card)
    .map((element) => normalizeVisibleText(element.innerText))
    .filter((text) => text && text !== normalizedLabel)
    .filter((text) => /^-|^[0-9][0-9,]*(?:\.[0-9]+)?(?:%|w|万|元\/?.*)?$/.test(text));
  for (const text of candidates) {
    const value = parseVisibleMetricValue(text);
    if (value !== null) {
      return value;
    }
  }
  return pickMetricAfterLabel(normalizeVisibleText(card.innerText), normalizedLabel);
}

function clickTextInDataPerformance(targetText) {
  const target = findDataPerformanceControl(targetText);
  if (target) {
    target.click();
    return;
  }
  clickVisibleTextInDataPerformance(targetText);
}

function clickVisibleTextInDataPerformance(targetText) {
  return clickVisibleTextByRange(targetText, isInDataPerformanceBounds);
}

function clickVisibleTextAnywhere(targetText) {
  return clickVisibleTextByRange(targetText);
}

function clickVisibleTextByRange(targetText, predicate = null) {
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const ranges = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue ?? "";
    const index = text.indexOf(targetText);
    if (index < 0 || !node.parentElement || !isElementVisible(node.parentElement)) {
      continue;
    }
    if (predicate && !predicate(node.parentElement)) {
      continue;
    }
    const range = document.createRange();
    range.setStart(node, index);
    range.setEnd(node, index + targetText.length);
    const rect = range.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      ranges.push({ rect, node });
    }
  }
  const picked = ranges
    .sort((a, b) => a.rect.top - b.rect.top || a.rect.left - b.rect.left)[0];
  if (!picked) {
    return false;
  }
  const x = picked.rect.left + picked.rect.width / 2;
  const y = picked.rect.top + picked.rect.height / 2;
  const target = document.elementFromPoint(x, y) ?? picked.node.parentElement;
  if (!target) {
    return false;
  }
  dispatchHumanClick(target);
  return true;
}

function clickExactText(targetText) {
  const target = findExactTextElement(targetText, document.body);
  if (target) {
    target.click();
  }
}

function findExactTextElement(targetText, root = document.body, predicate = null) {
  if (!root) {
    return null;
  }
  const candidates = Array.from(root.querySelectorAll("button, [role='tab'], [role='button'], .ant-tabs-tab, .ant-segmented-item, span, div"))
    .filter((element) => element.innerText?.trim() === targetText)
    .filter(isElementVisible)
    .filter((element) => !predicate || predicate(element))
    .sort((a, b) => (a.innerText?.length ?? 0) - (b.innerText?.length ?? 0));
  return candidates[0] ?? null;
}

async function scrapeVisibleCostMetrics(locators = {}) {
  try {
    const labels = {
      pictureCpm: ["预估CPM（图文）", "预估cpm（图文）", "预估图文CPM", "图文CPM"],
      videoCpm: ["预估CPM（视频）", "预估cpm（视频）", "预估视频CPM", "视频CPM"],
      pictureReadCost: ["预估阅读单价（图文）", "预估图文阅读单价", "图文笔记阅读单价", "图文阅读单价"],
      videoReadCost: ["预估阅读单价（视频）", "预估视频阅读单价", "视频笔记阅读单价", "视频阅读单价"]
    };
    const beforeDetailRead = await readDetailCostMetrics(labels);
    const listPageResult = hasAnyMetric(beforeDetailRead.metrics)
      ? emptyListPageCostResult("skipped-detail-ready")
      : await scrapeListPageCostMetrics(locators);
    const detailNavigationResult = !hasAnyMetric(beforeDetailRead.metrics) && !hasAnyMetric(listPageResult.metrics)
      ? await openAccountDetailAndReadCostMetrics(locators, labels)
      : null;
    const detailMetrics = hasAnyMetric(beforeDetailRead.metrics)
      ? beforeDetailRead.metrics
      : detailNavigationResult?.metrics ?? emptyCostMetrics();
    const text = document.body?.innerText ?? "";
    const normalizedText = normalizeVisibleText(text);


    return {
      metrics: {
        pictureCpm: firstPresent(detailMetrics.pictureCpm, listPageResult.metrics.pictureCpm),
        videoCpm: firstPresent(detailMetrics.videoCpm, listPageResult.metrics.videoCpm),
        pictureReadCost: firstPresent(detailMetrics.pictureReadCost, listPageResult.metrics.pictureReadCost),
        videoReadCost: firstPresent(detailMetrics.videoReadCost, listPageResult.metrics.videoReadCost)
      },
      debug: buildPageCostDebug(text, normalizedText, labels, listPageResult, {
        detailCostMetricsSkipped: beforeDetailRead.skipped,
        detailNavigationResult
      })
    };
  } catch (_error) {
    return {
      metrics: {
        pictureCpm: null,
        videoCpm: null,
        pictureReadCost: null,
        videoReadCost: null
      },
      debug: {
        url: location.href,
        title: document.title,
        error: "页面成本字段探测失败"
      }
    };
  }
}

async function readDetailCostMetrics(labels) {
  clickTextIfVisible("笔记数据");
  await sleep(300);
  clickTextIfVisible("按成本");
  await sleep(600);

  const text = document.body?.innerText ?? "";
  const normalizedText = normalizeVisibleText(text);
  const canRead = normalizedText.includes("笔记数据") || normalizedText.includes("按成本");

  if (!canRead) {
    return {
      skipped: true,
      metrics: emptyCostMetrics()
    };
  }

  return {
    skipped: false,
    metrics: {
      pictureCpm: pickVisibleMetric(text, labels.pictureCpm),
      videoCpm: pickVisibleMetric(text, labels.videoCpm),
      pictureReadCost: pickVisibleMetric(text, labels.pictureReadCost),
      videoReadCost: pickVisibleMetric(text, labels.videoReadCost)
    }
  };
}

async function openAccountDetailAndReadCostMetrics(locators, labels) {
  const openResult = await openMatchedAccountDetail(locators);
  if (!openResult.opened) {
    return {
      ...openResult,
      metrics: emptyCostMetrics()
    };
  }

  await sleep(1800);
  const readResult = await readDetailCostMetrics(labels);

  return {
    ...openResult,
    urlAfterOpen: location.href,
    titleAfterOpen: document.title,
    readSkipped: readResult.skipped,
    metrics: readResult.metrics
  };
}

async function openMatchedAccountDetail(locators) {
  const rows = findVisibleAccountRows(locators);
  const row = rows[0] ?? null;
  if (!row) {
    return {
      opened: false,
      reason: "未找到可点击的达人行"
    };
  }

  const candidates = findAccountDetailClickCandidates(row.element, locators);
  if (!candidates.length) {
    return {
      opened: false,
      reason: "达人行内未找到可点击入口",
      rowText: row.text.slice(0, 500),
      clickCandidates: []
    };
  }

  const beforeUrl = location.href;
  const attempts = [];
  const trialCandidates = candidates.slice(0, 6);
  for (const clickable of trialCandidates) {
    dispatchHumanClick(clickable);
    await sleep(900);

    const opened = location.href !== beforeUrl || normalizeVisibleText(document.body?.innerText ?? "").includes("笔记数据");
    const attempt = {
      clicked: describeElement(clickable),
      urlAfterClick: location.href,
      opened
    };
    attempts.push(attempt);

    if (opened) {
      return {
        opened: true,
        clicked: describeElement(clickable),
        clickAttempts: attempts,
        clickCandidates: candidates.map(describeElement),
        triedCandidateCount: trialCandidates.length,
        rowLinks: describeLinks(row.element),
        rowText: row.text.slice(0, 500)
      };
    }
  }

  return {
    opened: false,
    reason: "已尝试点击达人行候选入口，但页面未进入详情",
    clickAttempts: attempts,
    clickCandidates: candidates.map(describeElement),
    triedCandidateCount: trialCandidates.length,
    rowLinks: describeLinks(row.element),
    rowText: row.text.slice(0, 500)
  };
}

function findAccountDetailClickCandidates(rowElement, locators) {
  const nickname = normalizeVisibleText(locators.nickname);
  const elements = Array.from(rowElement.querySelectorAll("a[href], button, [role='button'], [class*='kol-info'], [class*='user-info'], [class*='kol-name'], [class*='name-text'], [class*='name'], [class*='Name'], span, div"))
    .filter(isElementVisible);
  const goodText = (element) => {
    const text = normalizeVisibleText(element.innerText ?? "");
    return !/添加合作|发起邀约|更多操作/.test(text);
  };
  const candidates = [
    ...elements.filter((element) => element.matches("a[href]") && goodText(element)),
    ...elements.filter((element) => /kol-info/i.test(String(element.className ?? "")) && goodText(element)),
    ...elements.filter((element) => /user-info|kol-name|name-text|name/i.test(String(element.className ?? "")) && goodText(element)),
    ...elements.filter((element) => {
      const text = normalizeVisibleText(element.innerText ?? "");
      return nickname && text.includes(nickname) && goodText(element);
    }),
    rowElement
  ];

  return uniqueElements(candidates).slice(0, 12);
}

function uniqueElements(elements) {
  return elements.filter((element, index) => elements.indexOf(element) === index);
}

function dispatchHumanClick(element) {
  dispatchClickLikeEvents(element);
  let current = element.parentElement;
  for (let depth = 0; current && depth < 4; depth += 1) {
    if (isElementVisible(current)) {
      dispatchClickLikeEvents(current);
    }
    current = current.parentElement;
  }
}

function dispatchClickLikeEvents(element) {
  element.scrollIntoView({ block: "center", inline: "center" });
  const rect = element.getBoundingClientRect();
  const eventInit = {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX: rect.left + rect.width / 2,
    clientY: rect.top + rect.height / 2
  };
  for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
    const EventCtor = type.startsWith("pointer") && typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent;
    element.dispatchEvent(new EventCtor(type, {
      ...eventInit,
      pointerType: "mouse",
      isPrimary: true,
      button: 0,
      buttons: type.endsWith("down") ? 1 : 0
    }));
  }
  element.click?.();
  element.dispatchEvent(new MouseEvent("dblclick", {
      bubbles: true,
      cancelable: true,
      view: window
  }));
}

function describeLinks(element) {
  return Array.from(element.querySelectorAll("a[href]"))
    .filter(isElementVisible)
    .map((link) => ({
      href: link.href,
      text: (link.innerText ?? "").replace(/\s+/g, " ").trim().slice(0, 200),
      target: link.target,
      className: String(link.className ?? "").slice(0, 160)
    }))
    .slice(0, 20);
}

function emptyListPageCostResult(stage) {
  return {
    metrics: emptyCostMetrics(),
    debug: {
      stage,
      matchedRowCount: 0,
      matchedRowText: null,
      headerCells: [],
      rowCells: [],
      cpmCellText: null,
      readCostCellText: null,
      attempts: []
    }
  };
}

async function scrapeListPageCostMetrics(locators) {
  const selectedColumnTexts = await ensureCostColumnsVisible();
  const attempts = [];
  const firstAttempt = scrapeListPageCostMetricsAtCurrentScroll(locators, "initial");
  attempts.push(firstAttempt);

  const containers = findHorizontalScrollContainers();
  if (hasAnyMetric(firstAttempt.metrics)) {
    return {
      ...firstAttempt,
      debug: {
        ...firstAttempt.debug,
        selectedColumnTexts,
        scrollContainers: containers.map(describeScrollContainer)
      }
    };
  }

  for (const container of containers) {
    const originalScrollLeft = container.scrollLeft;
    const maxScrollLeft = container.scrollWidth - container.clientWidth;
    const positions = [0.35, 0.7, 1];

    for (const ratio of positions) {
      container.scrollLeft = Math.round(maxScrollLeft * ratio);
      container.dispatchEvent(new Event("scroll", { bubbles: true }));
      await sleep(350);

      const attempt = scrapeListPageCostMetricsAtCurrentScroll(locators, `scroll-${Math.round(ratio * 100)}`);
      attempts.push(attempt);
      if (hasAnyMetric(attempt.metrics)) {
        return withAttempts(attempt, attempts, containers, selectedColumnTexts);
      }
    }

    container.scrollLeft = originalScrollLeft;
    container.dispatchEvent(new Event("scroll", { bubbles: true }));
  }

  return withAttempts(firstAttempt, attempts, containers, selectedColumnTexts);
}

async function ensureCostColumnsVisible() {
  const clicked = [];
  for (const text of ["预估CPM", "预估阅读单价"]) {
    if (clickSelectableTextIfUnchecked(text)) {
      clicked.push(text);
      await sleep(250);
    }
  }

  if (clicked.length) {
    clickFirstVisibleText(["确定", "应用", "完成", "查询", "搜索"]);
    await sleep(900);
  }

  return clicked;
}

function clickSelectableTextIfUnchecked(targetText) {
  const candidates = Array.from(document.querySelectorAll("label, button, [role='checkbox'], [role='menuitemcheckbox'], [class*='checkbox'], [class*='Checkbox'], span, div"))
    .filter((element) => element.innerText?.trim() === targetText)
    .filter(isElementVisible);

  for (const element of candidates) {
    const clickable = element.closest("label, button, [role='checkbox'], [role='menuitemcheckbox'], [class*='checkbox'], [class*='Checkbox']") ?? element;
    if (isSelectedLike(clickable)) {
      continue;
    }

    clickable.click();
    return true;
  }

  return false;
}

function clickFirstVisibleText(targetTexts) {
  for (const targetText of targetTexts) {
    const candidates = Array.from(document.querySelectorAll("button, [role='button'], span, div"))
      .filter((element) => element.innerText?.trim() === targetText)
      .filter(isElementVisible);
    const target = candidates[0];
    if (target) {
      target.click();
      return targetText;
    }
  }

  return null;
}

function isSelectedLike(element) {
  const ariaChecked = element.getAttribute("aria-checked");
  const className = String(element.className ?? "");
  const input = element.matches("input") ? element : element.querySelector("input");

  return ariaChecked === "true" ||
    input?.checked === true ||
    /checked|selected|active/i.test(className);
}

function scrapeListPageCostMetricsAtCurrentScroll(locators, stage) {
  const rows = findVisibleAccountRows(locators);
  const row = rows[0] ?? null;
  const headerCells = row ? findHeaderCellsForRow(row.element) : [];
  const cellTexts = row?.cellTexts ?? [];
  const cpmCellText = pickCellByHeader(headerCells, cellTexts, ["预估CPM", "预估cpm"]) ??
    pickMetricCellByNearbyText(row?.element, ["预估CPM", "预估cpm"]);
  const readCostCellText = pickCellByHeader(headerCells, cellTexts, ["预估阅读单价"]) ??
    pickMetricCellByNearbyText(row?.element, ["预估阅读单价"]);

  return {
    metrics: {
      pictureCpm: parseVariantMetric(cpmCellText, "图文"),
      videoCpm: parseVariantMetric(cpmCellText, "视频"),
      pictureReadCost: parseVariantMetric(readCostCellText, "图文"),
      videoReadCost: parseVariantMetric(readCostCellText, "视频")
    },
    debug: {
      stage,
      matchedRowCount: rows.length,
      matchedRowText: row?.text?.slice(0, 800) ?? null,
      headerCells,
      rowCells: cellTexts.slice(0, 80),
      cpmCellText,
      readCostCellText
    }
  };
}

function hasAnyMetric(metrics) {
  return Object.values(metrics).some((value) => value !== null && value !== undefined);
}

function withAttempts(result, attempts, containers = [], selectedColumnTexts = []) {
  return {
    ...result,
    debug: {
      ...result.debug,
      selectedColumnTexts,
      scrollContainers: containers.map(describeScrollContainer),
      attempts: attempts.map((attempt) => ({
        stage: attempt.debug.stage,
        metrics: attempt.metrics,
        rowCells: attempt.debug.rowCells,
        cpmCellText: attempt.debug.cpmCellText,
        readCostCellText: attempt.debug.readCostCellText
      }))
    }
  };
}

function findHorizontalScrollContainers() {
  return Array.from(document.querySelectorAll("*"))
    .filter((element) => {
      if (!isElementVisible(element)) {
        return false;
      }

      return element.scrollWidth > element.clientWidth + 40;
    })
    .sort((a, b) => (b.scrollWidth - b.clientWidth) - (a.scrollWidth - a.clientWidth))
    .slice(0, 12);
}

function describeScrollContainer(element) {
  const className = typeof element.className === "string" ? element.className : "";
  return {
    tagName: element.tagName,
    className: className.slice(0, 120),
    scrollLeft: element.scrollLeft,
    clientWidth: element.clientWidth,
    scrollWidth: element.scrollWidth
  };
}

function findVisibleAccountRows(locators) {
  const keys = [locators.nickname, locators.creatorId, locators.userId]
    .map((value) => normalizeVisibleText(value))
    .filter(Boolean);

  if (!keys.length) {
    return [];
  }

  const candidates = Array.from(document.querySelectorAll("tr, [class*='row'], [class*='Row']"))
    .filter(isElementVisible)
    .map((element) => ({
      element,
      text: element.innerText ?? "",
      normalizedText: normalizeVisibleText(element.innerText ?? ""),
      cellTexts: collectCellTexts(element)
    }))
    .filter((row) => row.text && keys.some((key) => row.normalizedText.includes(key)));

  return candidates
    .filter((row) => row.cellTexts.length > 1)
    .sort((a, b) => b.cellTexts.length - a.cellTexts.length);
}

function collectCellTexts(element) {
  const cellElements = Array.from(element.querySelectorAll("td, th, [class*='cell'], [class*='Cell']"))
    .filter(isElementVisible);
  const source = cellElements.length ? cellElements : Array.from(element.children).filter(isElementVisible);

  return source
    .map((cell) => (cell.innerText ?? "").replace(/\s+/g, " ").trim())
    .filter(Boolean);
}

async function findNoteCardCandidates({ noteId, title, note }) {
  const normalizedTitle = normalizeVisibleText(title);
  const keys = [
    noteId,
    normalizedTitle,
    normalizedTitle.slice(0, 10),
    note?.publishTime,
    note?.readNum == null ? "" : formatVisibleCount(note.readNum),
    note?.likeNum == null ? "" : formatVisibleCount(note.likeNum),
    note?.collectNum == null ? "" : formatVisibleCount(note.collectNum)
  ].filter((key) => key && key.length >= 4);
  const seen = new Set();
  const candidates = [];

  for (let page = 0; page < 5 && candidates.length < 12; page += 1) {
    const elements = Array.from(document.querySelectorAll("article, li, tr, [class*='note'], [class*='Note'], [class*='card'], [class*='Card'], div"))
      .filter(isElementVisible)
      .map((element) => ({
        element,
        text: element.innerText ?? "",
        normalizedText: normalizeVisibleText(element.innerText ?? "")
      }))
      .filter((item) => item.text && item.text.length < 1400)
      .filter((item) => keys.some((key) => item.normalizedText.includes(normalizeVisibleText(key))));

    for (const item of elements) {
      const card = item.element.closest("article, li, tr, [class*='note'], [class*='Note'], [class*='card'], [class*='Card']") ?? item.element;
      if (seen.has(card)) {
        continue;
      }
      seen.add(card);
      candidates.push(card);
    }

    if (candidates.length) {
      break;
    }

    window.scrollBy({ top: Math.round(window.innerHeight * 0.75), behavior: "instant" });
    await sleep(700);
  }

  return candidates.sort((a, b) => scoreNoteCard(b, keys) - scoreNoteCard(a, keys));
}

function scoreNoteCard(element, keys) {
  const text = normalizeVisibleText(element.innerText ?? "");
  const mediaCount = element.querySelectorAll("img, video, canvas").length;
  return keys.reduce((score, key) => score + (text.includes(normalizeVisibleText(key)) ? 10 : 0), 0) +
    Math.min(mediaCount, 3);
}

function findNoteCoverClickable(card) {
  return Array.from(card.querySelectorAll("[class*='mask'], [class*='Mask'], [class*='cover'], [class*='Cover'], [class*='image'], [class*='Image'], img, video, canvas"))
    .filter(isElementVisible)
    .sort((a, b) => area(b) - area(a))[0] ?? null;
}

function area(element) {
  const rect = element.getBoundingClientRect();
  return rect.width * rect.height;
}

function pickPopupText() {
  const dialogSelectors = "[role='dialog'], [class*='modal'], [class*='Modal'], [class*='dialog'], [class*='Dialog'], [class*='drawer'], [class*='Drawer']";
  const fixedPanels = Array.from(document.querySelectorAll("body *"))
    .filter(isElementVisible)
    .filter((element) => {
      const style = getComputedStyle(element);
      return ["fixed", "sticky"].includes(style.position) && area(element) > 20000;
    });
  const dialogs = [
    ...Array.from(document.querySelectorAll(dialogSelectors)),
    ...fixedPanels
  ]
    .filter(isElementVisible)
    .sort((a, b) => area(b) - area(a));

  return dialogs
    .map((element) => element.innerText ?? "")
    .find((text) => /点赞|收藏|评论|分享|关注|曝光|阅读|互动/.test(text)) || "";
}

function parseNotePopupMetrics(text) {
  const scopedText = scopeNoteDataText(text);
  return {
    impNum: pickLabeledCount(scopedText, ["曝光量", "曝光"]),
    readNum: pickLabeledCount(scopedText, ["阅读量", "阅读"]),
    likeNum: pickLabeledCount(scopedText, ["点赞量", "点赞"]),
    collectNum: pickLabeledCount(scopedText, ["收藏量", "收藏"]),
    commentNum: pickLabeledCount(scopedText, ["评论量", "评论"]),
    shareNum: pickLabeledCount(scopedText, ["分享量", "分享", "转发量", "转发"]),
    followNum: pickLabeledCount(scopedText, ["关注量", "关注"]),
    interactionNum: pickLabeledCount(scopedText, ["总互动", "互动量", "互动"])
  };
}

function scopeNoteDataText(text) {
  const start = text.indexOf("本篇笔记数据");
  if (start < 0) {
    return text;
  }

  const tail = text.slice(start);
  const end = tail.search(/笔记组件点击率|相似博主|添加合作|评论区|精选评论|小红书官网/);
  return end > 0 ? tail.slice(0, end) : tail.slice(0, 500);
}

function pickLabeledCount(text, labels) {
  const normalized = normalizeVisibleText(text);
  for (const label of labels) {
    const safeLabel = escapeRegExp(normalizeVisibleText(label));
    const after = normalized.match(new RegExp(`${safeLabel}[:：]?([0-9,.万wW]+)`));
    if (after) {
      return parseCount(after[1]);
    }

    const before = normalized.match(new RegExp(`([0-9,.万wW]+)[:：]?${safeLabel}`));
    if (before) {
      return parseCount(before[1]);
    }
  }

  return null;
}

function hasAnyNoteMetric(metrics) {
  return Object.values(metrics ?? {}).some((value) => value !== null && value !== undefined);
}

function closePopupIfOpen() {
  const closeButton = Array.from(document.querySelectorAll("button, [role='button'], [class*='close'], [class*='Close']"))
    .filter(isElementVisible)
    .find((element) => /关闭|close|×|x/i.test(element.getAttribute("aria-label") || element.innerText || String(element.className ?? "")));

  if (closeButton) {
    closeButton.click();
    return;
  }

  document.dispatchEvent(new KeyboardEvent("keydown", {
    key: "Escape",
    code: "Escape",
    bubbles: true
  }));
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function findHeaderCellsForRow(rowElement) {
  const table = rowElement.closest("table, [class*='table'], [class*='Table']");
  const headerRow = table?.querySelector("thead tr, [class*='header'], [class*='Header']");
  const headerCells = headerRow ? collectCellTexts(headerRow) : [];

  if (headerCells.length) {
    return headerCells;
  }

  return collectCellTexts(document.body)
    .filter((text) => /预估CPM|预估cpm|预估阅读单价|传播规模/.test(text))
    .slice(0, 40);
}

function pickCellByHeader(headerCells, rowCells, headerKeywords) {
  const headerIndex = headerCells.findIndex((text) => {
    const normalized = normalizeVisibleText(text);
    return headerKeywords.some((keyword) => normalized.includes(normalizeVisibleText(keyword)));
  });

  if (headerIndex >= 0 && rowCells[headerIndex]) {
    return rowCells[headerIndex];
  }

  return rowCells.find((text) => {
    const normalized = normalizeVisibleText(text);
    return headerKeywords.some((keyword) => normalized.includes(normalizeVisibleText(keyword)));
  }) ?? null;
}

function pickMetricCellByNearbyText(rowElement, headerKeywords) {
  if (!rowElement) {
    return null;
  }

  const table = rowElement.closest("table, [class*='table'], [class*='Table']") ?? document.body;
  const keywordRegex = new RegExp(headerKeywords.join("|"), "i");
  const text = table.innerText ?? "";
  const keywordIndex = text.search(keywordRegex);
  if (keywordIndex < 0) {
    return null;
  }

  const rowText = rowElement.innerText ?? "";
  const metricLikeCells = collectCellTexts(rowElement).filter((cellText) => {
    const normalized = normalizeVisibleText(cellText);
    return /图文|视频|-|[0-9]+(?:\.[0-9]+)?/.test(normalized);
  });

  return metricLikeCells.find((cellText) => /图文|视频/.test(cellText) && /-|[0-9]+(?:\.[0-9]+)?/.test(cellText)) ??
    rowText.slice(0, 400);
}

function parseVariantMetric(text, variant) {
  if (!text) {
    return null;
  }

  const normalized = normalizeVisibleText(text);
  const label = normalizeVisibleText(variant);
  const index = normalized.indexOf(label);
  if (index < 0) {
    return null;
  }

  return parseVisibleMetricValue(normalized.slice(index + label.length, index + label.length + 40));
}

function firstPresent(...values) {
  return values.find((value) => value !== null && value !== undefined) ?? null;
}

function emptyCostMetrics() {
  return {
    pictureCpm: null,
    videoCpm: null,
    pictureReadCost: null,
    videoReadCost: null
  };
}

function buildPageCostDebug(text, normalizedText, labels, listPageResult, extra = {}) {
  const flatLabels = Object.values(labels).flat().map(normalizeVisibleText);

  return {
    url: location.href,
    title: document.title,
    hasNoteData: normalizedText.includes("笔记数据"),
    hasCostTab: normalizedText.includes("按成本"),
    hasScaleTab: normalizedText.includes("按规模"),
    detailCostMetricsSkipped: extra.detailCostMetricsSkipped ?? false,
    matchedLabels: flatLabels.filter((label) => normalizedText.includes(label)),
    costTextProbe: buildCostTextProbe(text, ["笔记数据", "按成本", "预估CPM", "预估cpm", "阅读单价"]),
    costLabelElements: inspectTextElements(["预估CPM", "预估阅读单价"]),
    recentPgyApiUrls: collectRecentPgyApiUrls(),
    detailNavigationResult: extra.detailNavigationResult ?? null,
    listPageResult: listPageResult.debug
  };
}

function inspectTextElements(targetTexts) {
  return targetTexts.flatMap((targetText) => {
    const elements = Array.from(document.querySelectorAll("body *"))
      .filter((element) => element.innerText?.trim() === targetText)
      .filter(isElementVisible)
      .slice(0, 5);

    return elements.map((element) => ({
      targetText,
      element: describeElement(element),
      ancestors: describeAncestors(element, 5)
    }));
  });
}

function describeAncestors(element, depth) {
  const ancestors = [];
  let current = element.parentElement;

  while (current && ancestors.length < depth) {
    ancestors.push(describeElement(current));
    current = current.parentElement;
  }

  return ancestors;
}

function describeElement(element) {
  const className = typeof element.className === "string" ? element.className : "";
  return {
    tagName: element.tagName,
    className: className.slice(0, 160),
    role: element.getAttribute("role"),
    ariaChecked: element.getAttribute("aria-checked"),
    text: (element.innerText ?? "").replace(/\s+/g, " ").trim().slice(0, 240)
  };
}

function collectRecentPgyApiUrls() {
  try {
    return performance.getEntriesByType("resource")
      .map((entry) => entry.name)
      .filter((url) => /pgy\.xiaohongshu\.com|edith\.xiaohongshu\.com|solar|api/.test(url))
      .filter((url) => /kol|note|search|recommend|trade|cost|price/i.test(url))
      .slice(-40);
  } catch (_error) {
    return [];
  }
}

function buildCostTextProbe(text, keywords) {
  const snippets = [];

  for (const keyword of keywords) {
    const index = text.indexOf(keyword);
    if (index < 0) {
      continue;
    }

    const start = Math.max(0, index - 120);
    const end = Math.min(text.length, index + keyword.length + 180);
    snippets.push(text.slice(start, end).replace(/\s+/g, " ").trim());
  }

  return snippets.slice(0, 6);
}

function clickTextIfVisible(targetText) {
  const candidates = Array.from(document.querySelectorAll("button, [role='tab'], [role='button'], .ant-tabs-tab, .ant-segmented-item, span, div"))
    .filter((element) => element.innerText?.trim() === targetText);
  const target = candidates.find(isElementVisible);

  if (target) {
    target.click();
  }
}

function isElementVisible(element) {
  const rect = element.getBoundingClientRect();
  const style = getComputedStyle(element);
  return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
}

function pickVisibleMetric(text, labels) {
  const normalizedText = normalizeVisibleText(text);

  for (const label of labels) {
    const value = pickMetricAfterLabel(normalizedText, normalizeVisibleText(label)) ??
      pickMetricBeforeLabel(normalizedText, normalizeVisibleText(label));

    if (value !== null) {
      return value;
    }
  }

  return null;
}

function pickMetricAfterLabel(text, label) {
  const index = text.indexOf(label);
  if (index < 0) {
    return null;
  }

  return parseVisibleMetricValue(text.slice(index + label.length, index + label.length + 80));
}

function pickMetricBeforeLabel(text, label) {
  const index = text.indexOf(label);
  if (index < 0) {
    return null;
  }

  const matches = Array.from(text.slice(Math.max(0, index - 80), index).matchAll(/(^|[^\d])(-|[0-9]+(?:\.[0-9]+)?)(?=$|[^\d])/g));
  return matches.length ? normalizeVisibleMetricValue(matches.at(-1)[2]) : null;
}

function parseVisibleMetricValue(text) {
  const match = text.match(/(^|[^\d])(-|[0-9][0-9,]*(?:\.[0-9]+)?)(?=$|[^\d])/);
  return match ? normalizeVisibleMetricValue(match[2]) : null;
}

function normalizeVisibleMetricValue(value) {
  if (value === "-") {
    return "-";
  }

  const parsed = Number(String(value).replace(/,/g, ""));
  return Number.isNaN(parsed) ? value : parsed;
}

function normalizeVisibleText(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[()]/g, (token) => (token === "(" ? "（" : "）"))
    .trim();
}

async function resolveCreator(locators = {}, options = {}) {
  const profileUserId = extractProfileUserId(locators.profileUrl);
  if (profileUserId) {
    return buildResolvedCreator(profileUserId, locators, { source: "小红书主页" });
  }

  const pgyProfileUserId = extractProfileUserId(locators.pgyProfileUrl);
  if (pgyProfileUserId) {
    return buildResolvedCreator(pgyProfileUserId, locators, { source: "蒲公英主页" });
  }

  const directCreatorId = normalizeCreatorId(locators.creatorId);
  if (isProfileUserId(directCreatorId)) {
    return buildResolvedCreator(directCreatorId, locators, { source: "达人id" });
  }

  const searched = await searchCreator(locators);
  if (searched) {
    return buildResolvedCreator(searched.userId, locators, {
      source: searched.source,
      candidate: searched.candidate
    });
  }

  if (!options.required) {
    return buildResolvedCreator("", locators, { source: "发布链接" });
  }

  if (directCreatorId) {
    throw new Error(`未能通过达人ID/小红书号「${directCreatorId}」找到唯一蒲公英达人，请补充小红书主页或蒲公英链接`);
  }

  if (locators.nickname) {
    throw new Error(`昵称「${locators.nickname}」未找到唯一精准匹配达人，请补充达人ID或主页链接`);
  }

  throw new Error("当前行缺少可用的达人id、昵称、小红书主页或蒲公英链接，暂时无法发起蒲公英抓取");
}

function buildResolvedCreator(userId, locators = {}, extra = {}) {
  const candidate = extra.candidate ?? {};
  const resolvedUserId = userId || "";
  const redId = firstNonEmpty(
    locators.creatorId,
    candidate.redId,
    candidate.red_id,
    candidate.redIdDisplay,
    candidate.xhsId,
    candidate.xhs_id
  );
  const nickname = firstNonEmpty(
    locators.nickname,
    candidate.nickName,
    candidate.nickname,
    candidate.name,
    candidate.userName
  );

  return {
    userId: resolvedUserId,
    redId,
    nickname,
    pgyProfileUrl: firstNonEmpty(locators.pgyProfileUrl, resolvedUserId ? buildPgyProfileUrl(resolvedUserId) : ""),
    xhsProfileUrl: firstNonEmpty(locators.profileUrl, resolvedUserId ? buildXhsProfileUrl(resolvedUserId) : ""),
    source: extra.source ?? "unknown",
    candidate
  };
}

async function searchCreator(locators = {}) {
  const creatorId = normalizeCreatorId(locators.creatorId);
  if (creatorId) {
    const byId = await searchCreatorByKeyword(creatorId);
    const exact = byId.filter((candidate) => creatorCandidateMatchesId(candidate, creatorId));
    if (exact.length === 1) {
      return {
        userId: extractCreatorUserId(exact[0]),
        source: "达人ID搜索",
        candidate: exact[0]
      };
    }
  }

  const nickname = normalizeVisibleText(locators.nickname);
  if (!nickname) {
    return null;
  }

  const byNickname = await searchCreatorByKeyword(locators.nickname);
  const exactNickname = byNickname.filter((candidate) => normalizeVisibleText(readCreatorNickname(candidate)) === nickname);
  const unique = uniqueCreators(exactNickname);
  if (unique.length === 1) {
    return {
      userId: extractCreatorUserId(unique[0]),
      source: "昵称精准搜索",
      candidate: unique[0]
    };
  }

  if (unique.length > 1) {
    throw new Error(`昵称「${locators.nickname}」匹配到多个达人，请补充达人ID或主页链接`);
  }

  return null;
}

async function searchCreatorByKeyword(keyword) {
  const urls = API.creatorSearch(keyword);
  for (const url of urls) {
    const payload = await fetchJsonOptional(url);
    if (payload?.success === false || payload?.error) {
      continue;
    }

    const candidates = collectCreatorCandidates(payload)
      .filter((candidate) => extractCreatorUserId(candidate));
    if (candidates.length) {
      return candidates;
    }
  }

  return [];
}

function collectCreatorCandidates(payload) {
  const collected = [];
  collectCreatorCandidatesDeep(payload?.data ?? payload, collected);
  return collected;
}

function collectCreatorCandidatesDeep(value, collected) {
  if (!value || typeof value !== "object") {
    return;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      collectCreatorCandidatesDeep(item, collected);
    }
    return;
  }

  if (extractCreatorUserId(value) && readCreatorNickname(value)) {
    collected.push(value);
    return;
  }

  for (const nested of Object.values(value)) {
    collectCreatorCandidatesDeep(nested, collected);
  }
}

function creatorCandidateMatchesId(candidate, creatorId) {
  const normalized = normalizeCreatorId(creatorId);
  const values = [
    extractCreatorUserId(candidate),
    candidate.redId,
    candidate.red_id,
    candidate.redIdDisplay,
    candidate.xhsId,
    candidate.xhs_id,
    candidate.id,
    candidate.userId,
    candidate.user_id
  ].map(normalizeCreatorId).filter(Boolean);
  return values.includes(normalized);
}

function uniqueCreators(candidates) {
  const seen = new Set();
  return candidates.filter((candidate) => {
    const userId = extractCreatorUserId(candidate);
    if (!userId || seen.has(userId)) {
      return false;
    }
    seen.add(userId);
    return true;
  });
}

function extractCreatorUserId(candidate = {}) {
  const values = [
    candidate.userId,
    candidate.user_id,
    candidate.id,
    candidate.kolId,
    candidate.kol_id,
    candidate.authorId,
    candidate.author_id,
    candidate.bloggerId,
    candidate.blogger_id
  ];
  return values.map(normalizeCreatorId).find(isProfileUserId) ?? "";
}

function readCreatorNickname(candidate = {}) {
  return firstNonEmpty(candidate.nickName, candidate.nickname, candidate.name, candidate.userName, candidate.user_name);
}

function normalizeCreatorId(value) {
  return String(value ?? "").trim();
}

function isProfileUserId(value) {
  return /^[a-f0-9]{24}$/i.test(String(value ?? "").trim());
}

function firstNonEmpty(...values) {
  return values.find((value) => value !== undefined && value !== null && String(value).trim() !== "") ?? "";
}

function buildPgyProfileUrl(userId) {
  return `https://pgy.xiaohongshu.com/solar/pre-trade/blogger-detail/${userId}`;
}

function buildXhsProfileUrl(userId) {
  return `https://www.xiaohongshu.com/user/profile/${userId}`;
}

function matchPublishedNote(bundle, publishUrl) {
  if (!publishUrl) {
    return null;
  }

  const list = collectNoteCandidates(bundle);
  const noteId = extractNoteId(publishUrl);

  if (noteId) {
    const exactMatch = list.find((note) => note.noteId === noteId);
    if (exactMatch) {
      return exactMatch;
    }
  }

  return list.find((note) => JSON.stringify(note).includes(publishUrl)) ?? null;
}

async function resolvePublishedNote({ userId, bundle, publishUrl, requestedFields = [] }) {
  const linkResult = await resolvePublishUrl(publishUrl);
  const resolvedPublishUrl = linkResult.resolvedUrl || publishUrl;
  const detailNote = await fetchPublishedNoteDetail(resolvedPublishUrl);
  const bundledNote = matchPublishedNote(bundle, resolvedPublishUrl);
  let matchedNote = mergePreferComplete({
    publishUrl,
    resolvedPublishUrl,
    shortLinkResolved: linkResult.ok
  }, mergePreferComplete(detailNote, bundledNote));
  const noteId = detailNote?.noteId || bundledNote?.noteId || extractNoteId(resolvedPublishUrl);

  if (needsNoteId(requestedFields) && isXhsShortLink(publishUrl) && !linkResult.ok) {
    throw new Error(`短链接无法展开，暂时无法抓取笔记数据：${publishUrl}`);
  }

  if (needsNoteId(requestedFields) && !noteId) {
    throw new Error(`发布链接不是可识别的小红书笔记链接：${resolvedPublishUrl}`);
  }

  if (userId && noteId && needsPagedNoteSearch(matchedNote, requestedFields)) {
    const pagedNote = await fetchPagedNoteById(userId, noteId);
    matchedNote = mergePreferComplete(matchedNote, pagedNote);
  }

  return matchedNote;
}

async function resolvePublishUrl(publishUrl) {
  const originalUrl = String(publishUrl ?? "").trim();
  if (!originalUrl) {
    return { originalUrl, resolvedUrl: "", ok: false };
  }

  if (!isXhsShortLink(originalUrl)) {
    return { originalUrl, resolvedUrl: originalUrl, ok: true };
  }

  const backgroundResult = await resolvePublishUrlInBackground(originalUrl);
  if (backgroundResult) {
    return backgroundResult;
  }

  try {
    const response = await fetch(originalUrl, {
      method: "GET",
      credentials: "omit",
      redirect: "follow"
    });
    const finalUrl = response.url || originalUrl;
    return {
      originalUrl,
      resolvedUrl: finalUrl,
      ok: finalUrl !== originalUrl && isXhsNoteUrl(finalUrl)
    };
  } catch (_error) {
    return {
      originalUrl,
      resolvedUrl: originalUrl,
      ok: false
    };
  }
}

async function resolvePublishUrlInBackground(publishUrl) {
  try {
    const response = await chrome.runtime.sendMessage({
      source: "media-data-collector",
      action: "resolve-publish-url",
      payload: { publishUrl }
    });
    return response?.ok && response.link ? response.link : null;
  } catch (_error) {
    return null;
  }
}

function isXhsShortLink(value) {
  try {
    const url = new URL(String(value ?? "").trim());
    return /(^|\.)xhslink\.com$/i.test(url.hostname);
  } catch (_error) {
    return false;
  }
}

function isXhsNoteUrl(value) {
  return Boolean(extractNoteId(value));
}

function needsNoteId(fields = []) {
  return fields.some((field) => !isLongLinkField(field));
}

function isLongLinkField(field) {
  const normalized = normalizeVisibleText(field).toLowerCase();
  return ["转长链接", "长链接", "发布长链接"].some((name) => normalizeVisibleText(name).toLowerCase() === normalized);
}

function needsPagedNoteSearch(note, requestedFields = []) {
  if (!requestedFields.length) {
    return false;
  }

  return requestedFields.some((field) => !hasNoteMetricForField(note, field));
}

function hasNoteMetricForField(note, field) {
  if (!note) {
    return false;
  }

  const normalized = normalizeVisibleText(field);
  const keyGroups = [
    { fields: ["曝光量", "曝光"], keys: ["impNum", "exposureNum", "impressionNum"] },
    { fields: ["阅读量", "阅读"], keys: ["readNum", "readUserNum", "readCount", "effectiveReadNum"] },
    { fields: ["点赞", "点赞量"], keys: ["likeNum", "likeCount", "likedCount", "likes"] },
    { fields: ["收藏", "收藏量"], keys: ["collectNum", "favNum", "favCount", "collectCount", "collectedCount", "collects"] },
    { fields: ["评论", "评论量"], keys: ["commentNum", "cmtNum", "commentCount", "comments"] },
    { fields: ["转发", "转发量", "分享", "分享量"], keys: ["shareNum", "shareCount", "shares"] },
    { fields: ["关注", "关注量"], keys: ["followNum", "followCount", "followCnt"] },
    { fields: ["总互动", "互动量"], keys: ["interactionNum", "interactCount", "engageNum"] }
  ];
  const group = keyGroups.find((item) => item.fields.some((name) => normalizeVisibleText(name) === normalized));
  if (!group) {
    return true;
  }

  return group.keys.some((key) => {
    const value = note[key];
    return value !== undefined && value !== null && value !== "" && value !== "-";
  });
}

function mergePreferComplete(base, extra) {
  if (!base && !extra) {
    return null;
  }

  const merged = { ...(base ?? {}) };
  for (const [key, value] of Object.entries(extra ?? {})) {
    if (value === undefined || value === null || value === "") {
      continue;
    }

    if (merged[key] === undefined || merged[key] === null || merged[key] === "" || merged[key] === "-") {
      merged[key] = value;
    }
  }
  return merged;
}

async function fetchPagedNoteById(userId, noteId) {
  const pageSize = 50;
  const maxPages = 20;
  for (const noteType of [4, 3]) {
    for (let pageNumber = 1; pageNumber <= maxPages; pageNumber += 1) {
      const payload = await fetchJsonOptional(API.notesDetailPage(userId, noteType, pageNumber, pageSize));
      if (payload?.success === false && payload?.error) {
        break;
      }

      const list = notesList(payload);
      const match = list.find((note) => String(note?.noteId ?? "") === String(noteId));
      if (match) {
        return match;
      }

      if (!list.length || list.length < pageSize) {
        break;
      }
    }
  }

  return null;
}

function collectNoteCandidates(bundle) {
  return [
    ...notesList(bundle.fdCooperationNotesDetail),
    ...notesList(bundle.fdNotesDetail),
    ...notesList(bundle.fdNinetyPgyRecentPerformance),
    ...notesList(bundle.fdThirtyCooperateRecentPerformance),
    ...notesList(bundle.fdRecentPerformance)
  ].reduce((acc, note) => {
    if (!note?.noteId) {
      return acc;
    }

    const existing = acc.find((item) => item.noteId === note.noteId);
    if (existing) {
      mergeDefined(existing, note);
      return acc;
    }

    acc.push({ ...note });
    return acc;
  }, []);
}

function mergeDefined(target, source) {
  for (const [key, value] of Object.entries(source)) {
    if (value !== undefined && value !== null && value !== "") {
      target[key] = value;
    }
  }
  return target;
}

function notesList(payload) {
  const data = payload?.data ?? payload ?? {};
  const direct = data.list ?? data.notes ?? data.records ?? data.items ?? [];
  if (direct.length) {
    return direct;
  }

  const collected = [];
  collectNotesDeep(data, collected);
  return collected;
}

function collectNotesDeep(value, collected) {
  if (!value || typeof value !== "object") {
    return;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      collectNotesDeep(item, collected);
    }
    return;
  }

  if (value.noteId && typeof value.noteId !== "object") {
    collected.push(value);
    return;
  }

  for (const nested of Object.values(value)) {
    collectNotesDeep(nested, collected);
  }
}

async function fetchPublicNoteMetrics(publishUrl) {
  if (!publishUrl) {
    return null;
  }

  try {
    const response = await fetch(publishUrl, {
      credentials: "include",
      headers: {
        accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      }
    });

    if (!response.ok) {
      return null;
    }

    const html = await response.text();
    return parsePublicNoteMetrics(html);
  } catch (_error) {
    return null;
  }
}

function parsePublicNoteMetrics(html) {
  const like = pickNumberFromText(html, ["likedCount", "likeCount", "likes"]);
  const collect = pickNumberFromText(html, ["collectedCount", "collectCount", "collects"]);
  const comment = pickNumberFromText(html, ["commentCount", "comments"]);
  const share = pickNumberFromText(html, ["shareCount", "shares"]);

  if ([like, collect, comment, share].every((value) => value == null)) {
    return null;
  }

  return {
    likeNum: like,
    collectNum: collect,
    commentNum: comment,
    shareNum: share
  };
}

function pickNumberFromText(text, keys) {
  for (const key of keys) {
    const match = text.match(new RegExp(`"${key}"\\s*:\\s*"?([0-9,.万wW]+)"?`, "i"));
    if (match) {
      return parseCount(match[1]);
    }
  }

  return null;
}

function parseCount(value) {
  const normalized = String(value ?? "").replace(/,/g, "").trim();
  if (!normalized) {
    return null;
  }

  if (/万|w/i.test(normalized)) {
    return Math.round(Number.parseFloat(normalized) * 10000);
  }

  const parsed = Number.parseInt(normalized, 10);
  return Number.isNaN(parsed) ? null : parsed;
}

function formatVisibleCount(value) {
  const numeric = typeof value === "number"
    ? value
    : Number(String(value ?? "").replace(/,/g, ""));
  return Number.isFinite(numeric) ? numeric.toLocaleString("en-US") : String(value ?? "");
}

function mergeNoteMetrics(pgyNote, extraMetrics) {
  if (!pgyNote && !extraMetrics) {
    return null;
  }

  const merged = { ...(pgyNote ?? {}) };
  for (const [key, value] of Object.entries(extraMetrics ?? {})) {
    if (value !== undefined && value !== null && value !== "") {
      merged[key] = value;
    }
  }

  return merged;
}

function extractProfileUserId(profileUrl) {
  if (!profileUrl) {
    return "";
  }

  try {
    const url = new URL(profileUrl);
    const segments = url.pathname.split("/").filter(Boolean);
    return segments.at(-1) ?? "";
  } catch (_error) {
    return "";
  }
}

function extractNoteId(publishUrl) {
  if (!publishUrl) {
    return "";
  }

  try {
    const url = new URL(publishUrl);
    const segments = url.pathname.split("/").filter(Boolean);
    const exploreIndex = segments.indexOf("explore");

    if (exploreIndex >= 0 && segments[exploreIndex + 1]) {
      return segments[exploreIndex + 1];
    }

    return segments.find((segment) => /^[a-f0-9]{24}$/i.test(segment)) ?? "";
  } catch (_error) {
    return "";
  }
}

const API = Object.freeze({
  bloggerDetail: (userId) => `https://pgy.xiaohongshu.com/api/solar/cooperator/user/blogger/${userId}`,
  creatorSearch: (keyword) => {
    const encoded = encodeURIComponent(String(keyword ?? "").trim());
    return [
      `https://pgy.xiaohongshu.com/api/solar/kol/search/bloggers?keyword=${encoded}&pageNumber=1&pageSize=20`,
      `https://pgy.xiaohongshu.com/api/solar/kol/search/blogger?keyword=${encoded}&pageNumber=1&pageSize=20`,
      `https://pgy.xiaohongshu.com/api/solar/kol/list?keyword=${encoded}&pageNumber=1&pageSize=20`,
      `https://pgy.xiaohongshu.com/api/solar/search/blogger?keyword=${encoded}&pageNumber=1&pageSize=20`
    ];
  },
  fansProfile: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/data/${userId}/fans_profile`,
  notesRate: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/dataV3/notesRate?userId=${userId}&business=0&noteType=3&dateType=1&advertiseSwitch=1`,
  notesRateByFilters: (userId, filters) => {
    const business = filters.business === "cooperation" ? 1 : 0;
    const noteType = filters.noteType === "picture" ? 1 : filters.noteType === "video" ? 2 : 3;
    const dateType = String(filters.dateRange) === "90" ? 2 : 1;
    const advertiseSwitch = filters.traffic === "natural" ? 0 : 1;
    const query = `userId=${userId}&business=${business}&noteType=${noteType}&dateType=${dateType}&advertiseSwitch=${advertiseSwitch}`;
    return [
      `https://pgy.xiaohongshu.com/api/solar/kol/data_v3/notes_rate?${query}`,
      `https://pgy.xiaohongshu.com/api/solar/kol/dataV3/notesRate?${query}`
    ];
  },
  notesRatePicture30: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/dataV3/notesRate?userId=${userId}&business=0&noteType=1&dateType=1&advertiseSwitch=1`,
  notesRateVideo30: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/dataV3/notesRate?userId=${userId}&business=0&noteType=2&dateType=1&advertiseSwitch=1`,
  notesRatePicture30Snake: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/data_v3/notes_rate?userId=${userId}&business=0&noteType=1&dateType=1&advertiseSwitch=1`,
  notesRateVideo30Snake: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/data_v3/notes_rate?userId=${userId}&business=0&noteType=2&dateType=1&advertiseSwitch=1`,
  fansSummary: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/dataV3/fansSummary?userId=${userId}`,
  recentPerformance: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/data_v3/notes_rate?userId=${userId}&business=1&noteType=3&dateType=2&advertiseSwitch=1`,
  bloggerNotesDetail: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/data_v2/notes_detail?advertiseSwitch=1&orderType=1&pageNumber=1&pageSize=50&userId=${userId}&noteType=4&isThirdPlatform=0`,
  cooperationNotes: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/data_v2/notes_detail?advertiseSwitch=1&orderType=1&pageNumber=1&pageSize=999&userId=${userId}&noteType=3&withComponent=false`,
  notesDetailPage: (userId, noteType, pageNumber, pageSize) => {
    const componentParam = noteType === 3 ? "&withComponent=false" : "&isThirdPlatform=0";
    return `https://pgy.xiaohongshu.com/api/solar/kol/data_v2/notes_detail?advertiseSwitch=1&orderType=1&pageNumber=${pageNumber}&pageSize=${pageSize}&userId=${userId}&noteType=${noteType}${componentParam}`;
  },
  costEffective: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/data_v2/cost_effective?userId=${userId}`,
  ninetyPersonalRecentPerformance: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/data_v3/notes_rate?userId=${userId}&business=0&noteType=3&dateType=2&advertiseSwitch=1`,
  thirtyCooperateRecentPerformance: (userId) => `https://pgy.xiaohongshu.com/api/solar/kol/data_v3/notes_rate?userId=${userId}&business=1&noteType=3&dateType=1&advertiseSwitch=1`,
  dataSummaryPersonal: (userId) => `https://pgy.xiaohongshu.com/api/pgy/kol/data/data_summary?userId=${userId}&business=0`,
  dataSummaryCooperation: (userId) => `https://pgy.xiaohongshu.com/api/pgy/kol/data/data_summary?userId=${userId}&business=1`,
  noteDetail: (noteId) => `https://pgy.xiaohongshu.com/api/solar/note/${noteId}/detail?bizCode=`
});

async function fetchPublishedNoteDetail(publishUrl) {
  const noteId = extractNoteId(publishUrl);
  if (!noteId) {
    return null;
  }

  const detail = await fetchJsonOptional(API.noteDetail(noteId));
  const data = detail?.data ?? detail;
  if (!data || data.success === false || data.error) {
    return { noteId };
  }

  return { noteId, ...data };
}

async function fetchPgyBundle(userId, collectionOptions = {}) {
  const filters = normalizePgyFilters(collectionOptions);
  const [
    basicData,
    fansReportData,
    fdRecentPerformance,
    fdDailyPicturePerformance,
    fdDailyVideoPerformance,
    fdDailyPicturePerformanceAlt,
    fdDailyVideoPerformanceAlt,
    fdFansSummary,
    fdNinetyPgyRecentPerformance,
    fdNotesDetail,
    fdCooperationNotesDetail,
    fdCostEffective,
    fdNinetyPersonalRecentPerformance,
    fdThirtyCooperateRecentPerformance,
    fdDataSummaryPersonal,
    fdDataSummaryCooperation,
    fdSelectedPerformance,
    fdSelectedCoreData
  ] = await Promise.all([
    fetchJson(API.bloggerDetail(userId)),
    fetchJson(API.fansProfile(userId)),
    fetchJson(API.notesRate(userId)),
    fetchJson(API.notesRatePicture30(userId)),
    fetchJson(API.notesRateVideo30(userId)),
    fetchJsonOptional(API.notesRatePicture30Snake(userId)),
    fetchJsonOptional(API.notesRateVideo30Snake(userId)),
    fetchJson(API.fansSummary(userId)),
    fetchJson(API.recentPerformance(userId)),
    fetchJson(API.bloggerNotesDetail(userId)),
    fetchJson(API.cooperationNotes(userId)),
    fetchJson(API.costEffective(userId)),
    fetchJson(API.ninetyPersonalRecentPerformance(userId)),
    fetchJson(API.thirtyCooperateRecentPerformance(userId)),
    fetchJsonOptional(API.dataSummaryPersonal(userId)),
    fetchJsonOptional(API.dataSummaryCooperation(userId)),
    fetchSelectedPerformance(userId, filters),
    fetchSelectedCoreData(userId, filters)
  ]);

  return {
    collectionOptions: filters,
    basicData,
    fansReportData,
    fdRecentPerformance,
    fdDailyPicturePerformance,
    fdDailyVideoPerformance,
    fdDailyPicturePerformanceAlt,
    fdDailyVideoPerformanceAlt,
    fdFansSummary,
    fdNinetyPgyRecentPerformance,
    fdNotesDetail,
    fdCooperationNotesDetail,
    fdCostEffective,
    fdNinetyPersonalRecentPerformance,
    fdThirtyCooperateRecentPerformance,
    fdDataSummaryPersonal,
    fdDataSummaryCooperation,
    fdSelectedPerformance,
    fdSelectedCoreData
  };
}

async function fetchSelectedCoreData(userId, filters) {
  const url = "https://pgy.xiaohongshu.com/api/pgy/kol/data/core_data";
  const body = {
    userId,
    business: filters.business === "cooperation" ? "1" : "0",
    noteType: filters.noteType === "picture" ? 1 : filters.noteType === "video" ? 2 : 3,
    dateType: String(filters.dateRange) === "90" ? 2 : 1,
    advertiseSwitch: filters.traffic === "natural" ? 0 : 1
  };
  return fetchJsonPost(url, body);
}

async function fetchSelectedPerformance(userId, filters) {
  const urls = API.notesRateByFilters(userId, filters);
  let firstResult = null;

  for (const url of urls) {
    const result = await fetchJsonOptional(url);
    if (!firstResult) {
      firstResult = result;
    }

    if (result?.success === false || result?.error) {
      continue;
    }

    if (hasSelectedPerformancePayload(result)) {
      return result;
    }
  }

  return firstResult;
}

function hasSelectedPerformancePayload(payload) {
  const data = payload?.data ?? payload;
  if (!data || typeof data !== "object") {
    return false;
  }

  return findSelectedPerformanceObject(data) !== null;
}

function findSelectedPerformanceObject(value, depth = 0) {
  if (!value || typeof value !== "object" || depth > 5) {
    return null;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findSelectedPerformanceObject(item, depth + 1);
      if (found) {
        return found;
      }
    }
    return null;
  }

  const metricKeys = [
    "impMedian",
    "readMedian",
    "mEngagementNum",
    "interactionMedian",
    "estimateCpm",
    "estimateReadPrice",
    "estimateEngageCost",
    "estimateStoreCost"
  ];
  if (metricKeys.some((key) => Object.prototype.hasOwnProperty.call(value, key))) {
    return value;
  }

  for (const child of Object.values(value)) {
    const found = findSelectedPerformanceObject(child, depth + 1);
    if (found) {
      return found;
    }
  }

  return null;
}

async function fetchJson(url) {
  const signature = signPgyParams(url);
  const response = await fetch(url, {
    credentials: "include",
    headers: {
      accept: "application/json, text/plain, */*",
      "x-b3-traceid": generateTraceid(),
      "x-s": signature["X-s"],
      "x-t": signature["X-t"]
    }
  });

  if (!response.ok) {
    throw new Error(`蒲公英请求失败: ${response.status}`);
  }

  return response.json();
}

async function fetchJsonOptional(url) {
  try {
    return await fetchJson(url);
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

async function fetchJsonPost(url, body) {
  const signature = signPgyParams(url, body);
  const response = await fetch(url, {
    method: "POST",
    credentials: "include",
    headers: {
      accept: "application/json, text/plain, */*",
      "content-type": "application/json",
      "x-b3-traceid": generateTraceid(),
      "x-s": signature["X-s"],
      "x-t": signature["X-t"]
    },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    throw new Error(`蒲公英请求失败: ${response.status}`);
  }

  return response.json();
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function signPgyParams(url, body = "") {
  const alphabet = "A4NjFqYu5wPHsO0XTdDgMa2r1ZQocVte9UJBvk6/7=yRnhISGKblCWi+LpfE8xzm3";
  const timestamp = Date.now();
  const parsed = new URL(url);
  const pathAndSearch = `${parsed.pathname}${parsed.search}`;
  const isObjectBody = Object.prototype.toString.call(body) === "[object Object]" ||
    Object.prototype.toString.call(body) === "[object Array]";
  const raw = [timestamp, "test", pathAndSearch, isObjectBody ? JSON.stringify(body) : ""].join("");
  const hash = md5(raw);

  return {
    "X-s": customBase64(hash, alphabet),
    "X-t": timestamp
  };
}

function customBase64(input, alphabet) {
  let output = "";
  let index = 0;
  const encoded = utf8Encode(input);

  while (index < encoded.length) {
    const first = encoded.charCodeAt(index++);
    const second = encoded.charCodeAt(index++);
    const third = encoded.charCodeAt(index++);
    const a = first >> 2;
    const b = ((first & 3) << 4) | (second >> 4);
    let c = ((second & 15) << 2) | (third >> 6);
    let d = third & 63;

    if (Number.isNaN(second)) {
      c = 64;
      d = 64;
    } else if (Number.isNaN(third)) {
      d = 64;
    }

    output += alphabet.charAt(a) + alphabet.charAt(b) + alphabet.charAt(c) + alphabet.charAt(d);
  }

  return output;
}

function utf8Encode(value) {
  const normalized = value.replace(/\r\n/g, "\n");
  let output = "";

  for (let index = 0; index < normalized.length; index += 1) {
    const code = normalized.charCodeAt(index);
    if (code < 128) {
      output += String.fromCharCode(code);
    } else if (code < 2048) {
      output += String.fromCharCode((code >> 6) | 192);
      output += String.fromCharCode((code & 63) | 128);
    } else {
      output += String.fromCharCode((code >> 12) | 224);
      output += String.fromCharCode(((code >> 6) & 63) | 128);
      output += String.fromCharCode((code & 63) | 128);
    }
  }

  return output;
}

function generateTraceid() {
  const alphabet = "abcdef0123456789";
  let traceId = "";

  for (let index = 0; index < 16; index += 1) {
    traceId += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
  }

  return traceId;
}
