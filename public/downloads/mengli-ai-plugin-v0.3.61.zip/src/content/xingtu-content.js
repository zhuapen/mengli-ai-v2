var XINGTU_CONTENT_SCRIPT_VERSION = "2026-06-15-xingtu-planting-hard-verify-v79";
var XINGTU_PING_ACTION = "xingtu-ping-v79";
var XINGTU_COLLECT_ACTION = "collect-xingtu-row-metrics-v79";
var XINGTU_TRUSTED_CLICK_TIMEOUT_MS = 900;
var XINGTU_PLANTING_PAGE_METRIC_KEYS = Object.freeze([
  "plantingDataRange",
  "afterSearchAvgCount",
  "afterSearchRate",
  "blueWordClickRate",
  "personalAfterSearchAvgCount",
  "personalAfterSearchRate",
  "personalBlueWordClickRate",
  "a3GrowthCount",
  "shopEntryCost",
  "plantingRangeVerified"
]);
var XINGTU_LEGACY_ACTIONS = Object.freeze({
  "xingtu-ping-v37": "2026-06-04-xingtu-page-filter-v37",
  "collect-xingtu-row-metrics-v37": "2026-06-04-xingtu-page-filter-v37",
  "xingtu-ping-v38": "2026-06-04-xingtu-page-filter-v38",
  "collect-xingtu-row-metrics-v38": "2026-06-04-xingtu-page-filter-v38",
  "xingtu-ping-v39": "2026-06-04-xingtu-page-filter-v39",
  "collect-xingtu-row-metrics-v39": "2026-06-04-xingtu-page-filter-v39",
  "xingtu-ping-v40": "2026-06-04-xingtu-page-filter-v40",
  "collect-xingtu-row-metrics-v40": "2026-06-04-xingtu-page-filter-v40",
  "xingtu-ping-v41": "2026-06-04-xingtu-page-filter-v41",
  "collect-xingtu-row-metrics-v41": "2026-06-04-xingtu-page-filter-v41",
  "xingtu-ping-v42": "2026-06-04-xingtu-page-filter-v42",
  "collect-xingtu-row-metrics-v42": "2026-06-04-xingtu-page-filter-v42",
  "xingtu-ping-v43": "2026-06-04-xingtu-page-filter-v43",
  "collect-xingtu-row-metrics-v43": "2026-06-04-xingtu-page-filter-v43",
  "xingtu-ping-v44": "2026-06-04-xingtu-page-filter-v44",
  "collect-xingtu-row-metrics-v44": "2026-06-04-xingtu-page-filter-v44",
  "xingtu-ping-v45": "2026-06-04-xingtu-page-filter-v45",
  "collect-xingtu-row-metrics-v45": "2026-06-04-xingtu-page-filter-v45",
  "xingtu-ping-v46": "2026-06-04-xingtu-page-filter-v46",
  "collect-xingtu-row-metrics-v46": "2026-06-04-xingtu-page-filter-v46",
  "xingtu-ping-v47": "2026-06-04-xingtu-page-filter-v47",
  "collect-xingtu-row-metrics-v47": "2026-06-04-xingtu-page-filter-v47",
  "xingtu-ping-v48": "2026-06-04-xingtu-api-filter-fallback-v48",
  "collect-xingtu-row-metrics-v48": "2026-06-04-xingtu-api-filter-fallback-v48",
  "xingtu-ping-v49": "2026-06-05-xingtu-planting-section-v49",
  "collect-xingtu-row-metrics-v49": "2026-06-05-xingtu-planting-section-v49",
  "xingtu-ping-v50": "2026-06-05-xingtu-planting-visible-v50",
  "collect-xingtu-row-metrics-v50": "2026-06-05-xingtu-planting-visible-v50",
  "xingtu-ping-v51": "2026-06-05-xingtu-visible-section-v51",
  "collect-xingtu-row-metrics-v51": "2026-06-05-xingtu-visible-section-v51",
  "xingtu-ping-v52": "2026-06-05-xingtu-section-card-v52",
  "collect-xingtu-row-metrics-v52": "2026-06-05-xingtu-section-card-v52",
  "xingtu-ping-v53": "2026-06-05-xingtu-planting-dom-v53",
  "collect-xingtu-row-metrics-v53": "2026-06-05-xingtu-planting-dom-v53",
  "xingtu-ping-v54": "2026-06-05-xingtu-planting-visible-only-v54",
  "collect-xingtu-row-metrics-v54": "2026-06-05-xingtu-planting-visible-only-v54",
  "xingtu-ping-v55": "2026-06-05-xingtu-verified-filter-v55",
  "collect-xingtu-row-metrics-v55": "2026-06-05-xingtu-verified-filter-v55",
  "xingtu-ping-v56": "2026-06-05-xingtu-api-filter-v56",
  "collect-xingtu-row-metrics-v56": "2026-06-05-xingtu-api-filter-v56",
  "xingtu-ping-v57": "2026-06-05-xingtu-api-filter-v57",
  "collect-xingtu-row-metrics-v57": "2026-06-05-xingtu-api-filter-v57",
  "xingtu-ping-v58": "2026-06-05-xingtu-api-filter-v58",
  "collect-xingtu-row-metrics-v58": "2026-06-05-xingtu-api-filter-v58",
  "xingtu-ping-v59": "2026-06-05-xingtu-api-filter-v59",
  "collect-xingtu-row-metrics-v59": "2026-06-05-xingtu-api-filter-v59",
  "xingtu-ping-v60": "2026-06-05-xingtu-page-business-v60",
  "collect-xingtu-row-metrics-v60": "2026-06-05-xingtu-page-business-v60",
  "xingtu-ping-v61": "2026-06-05-xingtu-page-business-v61",
  "collect-xingtu-row-metrics-v61": "2026-06-05-xingtu-page-business-v61",
  "xingtu-ping-v62": "2026-06-05-xingtu-page-business-v62",
  "collect-xingtu-row-metrics-v62": "2026-06-05-xingtu-page-business-v62",
  "xingtu-ping-v63": "2026-06-05-xingtu-page-business-v63",
  "collect-xingtu-row-metrics-v63": "2026-06-05-xingtu-page-business-v63",
  "xingtu-ping-v64": "2026-06-05-xingtu-page-business-v64",
  "collect-xingtu-row-metrics-v64": "2026-06-05-xingtu-page-business-v64",
  "xingtu-ping-v65": "2026-06-05-xingtu-page-business-v65",
  "collect-xingtu-row-metrics-v65": "2026-06-05-xingtu-page-business-v65",
  "xingtu-ping-v66": "2026-06-05-xingtu-window-collector-v66",
  "collect-xingtu-row-metrics-v66": "2026-06-05-xingtu-window-collector-v66",
  "xingtu-ping-v67": "2026-06-05-xingtu-api-fallback-v67",
  "collect-xingtu-row-metrics-v67": "2026-06-05-xingtu-api-fallback-v67",
  "xingtu-ping-v68": "2026-06-05-xingtu-visible-controls-v68",
  "collect-xingtu-row-metrics-v68": "2026-06-05-xingtu-visible-controls-v68",
  "xingtu-ping-v69": "2026-06-05-xingtu-anchored-dropdown-v69",
  "collect-xingtu-row-metrics-v69": "2026-06-05-xingtu-anchored-dropdown-v69",
  "xingtu-ping-v70": "2026-06-05-xingtu-trusted-click-v70",
  "collect-xingtu-row-metrics-v70": "2026-06-05-xingtu-trusted-click-v70",
  "xingtu-ping-v71": "2026-06-11-xingtu-navigation-v71",
  "collect-xingtu-row-metrics-v71": "2026-06-11-xingtu-navigation-v71",
  "xingtu-ping-v72": "2026-06-11-xingtu-visible-collector-v72",
  "collect-xingtu-row-metrics-v72": "2026-06-11-xingtu-visible-collector-v72",
  "xingtu-ping-v73": "2026-06-11-xingtu-background-collector-v73",
  "collect-xingtu-row-metrics-v73": "2026-06-11-xingtu-background-collector-v73",
  "xingtu-ping-v74": "2026-06-11-xingtu-background-tab-v74",
  "collect-xingtu-row-metrics-v74": "2026-06-11-xingtu-background-tab-v74",
  "xingtu-ping-v75": "2026-06-11-xingtu-fast-filter-v75",
  "collect-xingtu-row-metrics-v75": "2026-06-11-xingtu-fast-filter-v75",
  "xingtu-ping-v76": "2026-06-12-xingtu-business-page-v76",
  "collect-xingtu-row-metrics-v76": "2026-06-12-xingtu-business-page-v76",
  "xingtu-ping-v77": "2026-06-12-xingtu-verified-planting-v77",
  "collect-xingtu-row-metrics-v77": "2026-06-12-xingtu-verified-planting-v77",
  "xingtu-ping-v78": "2026-06-12-xingtu-planting-hard-verify-v78",
  "collect-xingtu-row-metrics-v78": "2026-06-12-xingtu-planting-hard-verify-v78"
});
var XINGTU_COLLECT_TIMEOUT_MS = 240000;

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.source !== "xingtu-data-collector") {
    return false;
  }

  if (message.action === XINGTU_PING_ACTION || message.action in XINGTU_LEGACY_ACTIONS) {
    sendResponse({
      ok: true,
      version: XINGTU_LEGACY_ACTIONS[message.action] || XINGTU_CONTENT_SCRIPT_VERSION,
      currentVersion: XINGTU_CONTENT_SCRIPT_VERSION
    });
    return false;
  }

  if (message.action === XINGTU_COLLECT_ACTION || /^collect-xingtu-row-metrics-v(37|38|39|40|41|42|43|44|45|46|47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78)$/.test(message.action)) {
    withTimeout(
      collectXingtuRowMetrics(message.payload),
      XINGTU_COLLECT_TIMEOUT_MS,
      "星图页面内部采集超时，请确认后台采集页已进入达人商业能力页"
    )
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ error: error.message || String(error) }));
    return true;
  }

  return false;
});

const API = Object.freeze({
  baseInfo: (authorId) => `https://www.xingtu.cn/gw/api/author/get_author_base_info?o_author_id=${encodeURIComponent(authorId)}&platform_source=1&platform_channel=1&recommend=true&search_session_id=&need_sec_uid=true&need_linkage_info=true`,
  spreadInfo: (authorId, options = {}) => buildUrl("https://www.xingtu.cn/gw/api/data_sp/get_author_spread_info", {
    o_author_id: authorId,
    platform_source: 1,
    platform_channel: 1,
    type: options.type,
    range: options.range,
    only_assign: options.onlyAssign,
    flow_type: options.flowType
  }),
  fansDistribution: (authorId) => `https://www.xingtu.cn/gw/api/data_sp/get_author_fans_distribution?o_author_id=${encodeURIComponent(authorId)}&platform_source=1&author_type=1`,
  marketingInfo: (authorId) => `https://www.xingtu.cn/gw/api/author/get_author_marketing_info?o_author_id=${encodeURIComponent(authorId)}&platform_source=1&platform_channel=1`,
  linkInfo: (authorId) => `https://www.xingtu.cn/gw/api/data_sp/get_author_link_info?o_author_id=${encodeURIComponent(authorId)}&platform_source=1&platform_channel=1&industy_tag=0`,
  authorShow: (authorId) => `https://www.xingtu.cn/gw/api/author/get_author_show_items_v2?o_author_id=${encodeURIComponent(authorId)}&platform_source=1&platform_channel=1&limit=200&only_assign=true&flow_type=0`,
  homepageVideos: (authorId, page = 1) => `https://www.xingtu.cn/gw/api/aggregator/get_author_homepage_videos?o_author_id=${encodeURIComponent(authorId)}&page=${encodeURIComponent(page)}&limit=100`,
  starHomepageVideos: (authorId, page = 1) => `https://www.xingtu.cn/gw/api/aggregator/get_author_homepage_videos?o_author_id=${encodeURIComponent(authorId)}&page=${encodeURIComponent(page)}&limit=100&is_star_item=1`,
  commerceSpreadInfo: (authorId) => `https://www.xingtu.cn/gw/api/aggregator/get_author_commerce_spread_info?o_author_id=${encodeURIComponent(authorId)}`,
  commerceSeedBaseInfo: (authorId, range) => buildUrl("https://www.xingtu.cn/gw/api/aggregator/get_author_commerce_seed_base_info", {
    o_author_id: authorId,
    range
  }),
  itemReportDetail: (itemId) => buildUrl("https://www.xingtu.cn/gw/api/data_sp/item_report_detail", {
    item_id: itemId
  }),
  itemReportTrend: (itemId) => buildUrl("https://www.xingtu.cn/gw/api/data_sp/item_report_trend", {
    item_id: itemId
  }),
  videoCard: (itemId) => buildUrl("https://www.xingtu.cn/gw/api/author/get_video_card", {
    item_ids: itemId,
    platform_source: 1
  }),
  douyinItemInfo: (awemeId) => `https://www.iesdouyin.com/web/api/v2/aweme/iteminfo/?item_ids=${encodeURIComponent(awemeId)}`,
  douyinAwemeDetail: (awemeId) => `https://www.douyin.com/aweme/v1/web/aweme/detail/?aweme_id=${encodeURIComponent(awemeId)}&aid=1128&version_name=23.5.0&device_platform=webapp`,
  searchAuthor: "https://www.xingtu.cn/gw/api/gsearch/search_for_author_square"
});

async function collectXingtuRowMetrics({ locators, accountFields = [], noteFields = [] }) {
  window.__XINGTU_LAST_FILTER_WARNING__ = "";
  const authorId = await runStage("解析达人", () => resolveAuthorId(locators), 12000);
  if ((accountFields.length > 0 || noteFields.length > 0) && !isOnAuthorPage(authorId)) {
    return {
      redirectUrl: buildXingtuProfileUrl(authorId),
      authorId
    };
  }
  let appliedFilters = null;
  let pageMetrics = null;
  if (accountFields.length > 0) {
    if (accountFieldsNeedBusinessAbilityPage(accountFields)) {
      let canReadBusinessPage = false;
      try {
        await runStage("进入商业能力", () => showBusinessAbilityPanel(), 45000);
        canReadBusinessPage = isBusinessAbilityDetailPage();
      } catch (error) {
        appendFilterWarning(`进入商业能力页面失败，已改用接口筛选：${error.message || String(error)}`);
      }

      if (canReadBusinessPage) {
        try {
          await runStage("应用商业能力筛选", () => applyBusinessAbilityFilters(locators), 45000);
        } catch (error) {
          appendFilterWarning(`商业能力页面筛选失败，继续读取当前页面并用接口补充：${error.message || String(error)}`);
        }
      }

      if (canReadBusinessPage) {
        try {
          pageMetrics = await runStage("读取商业能力页面", () => collectVisibleBusinessPageMetrics(accountFields, locators), 45000);
          appliedFilters = readBusinessFilterSnapshot();
        } catch (error) {
          appendFilterWarning(`读取商业能力页面失败，已改用接口筛选：${error.message || String(error)}`);
          pageMetrics = mergePageMetrics(readVisibleBasePageMetrics(authorId), stripPlantingPageMetrics(readVisiblePageMetrics("")));
          appliedFilters = readBusinessFilterSnapshot();
        }
      }

      if (!pageMetrics) {
        pageMetrics = readVisibleBasePageMetrics(authorId);
      }
      if (!appliedFilters) {
        appliedFilters = buildRequestedBusinessFilters(locators);
      }
    } else {
      pageMetrics = readVisibleBasePageMetrics(authorId);
      appliedFilters = readBusinessFilterSnapshot();
    }
  }
  const filterWarning = window.__XINGTU_LAST_FILTER_WARNING__ || "";
  const bundle = await runStage("请求星图数据接口", () => fetchXingtuBundle(authorId, {
    account: accountFields.length > 0,
    notes: noteFields.length > 0,
    locators,
    pageMetrics,
    appliedFilters,
    filterWarning
  }), 25000);
  if (accountFields.length > 0 && !hasSuccessfulResponse(bundle, ["baseInfo", "spreadInfo", "marketingInfo", "commerceSpreadInfo", "commerceSeedBaseInfo"])) {
    const error = bundle.baseInfo?.error || bundle.spreadInfo?.error || bundle.marketingInfo?.error || "请确认已登录巨量星图并有权限访问达人数据";
    throw new Error(error);
  }
  if (noteFields.length > 0 && !hasSuccessfulResponse(bundle, ["authorShow", "homepageVideos", "starHomepageVideos", "itemReportDetail", "itemReportTrend", "videoCard", "douyinItemInfo", "douyinAwemeDetail"])) {
    const error = bundle.authorShow?.error || bundle.homepageVideos?.error || bundle.starHomepageVideos?.error || bundle.itemReportDetail?.error || bundle.itemReportTrend?.error || bundle.videoCard?.error || bundle.douyinItemInfo?.error || bundle.douyinAwemeDetail?.error || "请确认已登录巨量星图并有权限访问作品数据";
    throw new Error(error);
  }
  const matchedNote = noteFields.length
    ? await runStage("匹配作品", async () => {
        const apiMatched = matchPublishedWork(bundle, locators.publishUrl);
        const pageMatched = needsPublishedWorkPageFallback(noteFields, apiMatched)
          ? await matchPublishedWorkFromCreationAbilityPage(locators.publishUrl, apiMatched)
          : null;
        const merged = mergePublishedWorkCandidates(apiMatched, pageMatched, locators.publishUrl);
        return enrichPublishedWorkCandidateWithBundle(merged, bundle, locators.publishUrl);
      }, 45000)
    : null;

  return {
    account: accountFields.length
      ? {
          status: "ok",
          locators,
          fields: accountFields,
          authorId,
          bundle
        }
      : null,
    note: noteFields.length
      ? {
          status: matchedNote ? "ok" : "not-found",
          locators,
          fields: noteFields,
          authorId,
          bundle,
          matchedNote
        }
      : null
  };
}

function accountFieldsNeedBusinessAbilityPage(accountFields = []) {
  const businessFields = [
    "播放量中位数",
    "完播率",
    "互动率",
    "发布作品",
    "平均时长",
    "平均点赞",
    "平均评论",
    "平均转发",
    "预期CPM",
    "预期CPE",
    "预期播放量",
    "爆文率",
    "商单视频平均看后搜次数",
    "商单视频看后搜率",
    "商单视频小蓝词点击率",
    "个人视频平均看后搜次数",
    "个人视频看后搜率",
    "个人视频小蓝词点击率",
    "A3增长数",
    "进店成本"
  ].map((field) => normalizeLine(field));
  const needed = new Set(businessFields);
  return accountFields.some((field) => needed.has(normalizeLine(field)));
}

async function runStage(stage, fn, timeoutMs) {
  try {
    return await withTimeout(Promise.resolve().then(fn), timeoutMs, `${stage}超时`);
  } catch (error) {
    throw new Error(`${stage}失败：${error.message || String(error)}`);
  }
}

function runStageSync(stage, fn) {
  try {
    return fn();
  } catch (error) {
    throw new Error(`${stage}失败：${error.message || String(error)}`);
  }
}

function hasSuccessfulResponse(bundle, keys) {
  return keys.some((key) => bundle[key] && bundle[key].success !== false && !bundle[key].error);
}

async function resolveAuthorId(locators = {}) {
  const directAuthorId = firstNonEmpty(
    locators.xingtuAuthorId,
    extractAuthorId(locators.xingtuProfileUrl)
  );
  if (directAuthorId && looksLikeAuthorId(directAuthorId)) {
    return directAuthorId;
  }

  const keyword = firstNonEmpty(locators.creatorId, locators.douyinId, locators.nickname);
  const profileKeyword = extractDouyinProfileKeyword(locators.profileUrl);
  const searchKeyword = firstNonEmpty(keyword, profileKeyword, locators.profileUrl);
  if (!searchKeyword) {
    throw new Error("当前行缺少达人账号ID、抖音号、星图达人ID或昵称");
  }

  const searched = await searchAuthorId(searchKeyword);
  if (searched) {
    return searched;
  }

  throw new Error(`星图未找到达人：${searchKeyword}`);
}

function isOnAuthorPage(authorId) {
  return Boolean(authorId) && location.href.includes(`/author-homepage/`) && location.href.includes(String(authorId));
}

function extractAuthorId(value) {
  if (!value) {
    return "";
  }

  const text = String(value).trim();
  const queryMatch = text.match(/[?&](?:o_author_id|author_id|id)=([^&#]+)/i);
  if (queryMatch) {
    return decodeURIComponent(queryMatch[1]);
  }

  const creatorHomepageMatch = text.match(/\/author-homepage\/[^/?#]+\/([^/?#]+)/i);
  if (creatorHomepageMatch) {
    return decodeURIComponent(creatorHomepageMatch[1]);
  }

  const pathMatch = text.match(/\/(?:author-homepage|author|creator)\/([^/?#]+)/i);
  if (pathMatch) {
    return decodeURIComponent(pathMatch[1]);
  }

  return "";
}

function extractDouyinProfileKeyword(value) {
  if (!value) {
    return "";
  }
  const text = String(value).trim();
  const userMatch = text.match(/douyin\.com\/user\/([^/?#]+)/i);
  if (userMatch) {
    return decodeURIComponent(userMatch[1]);
  }
  const queryMatch = text.match(/[?&](?:sec_uid|uid|unique_id|id)=([^&#]+)/i);
  if (queryMatch) {
    return decodeURIComponent(queryMatch[1]);
  }
  return "";
}

function looksLikeAuthorId(value) {
  return /^[A-Za-z0-9_-]{4,}$/.test(String(value ?? "").trim());
}

async function searchAuthorId(keyword) {
  const payloads = [
    { keyword: String(keyword), platform_source: 1, platform_channel: 1, limit: 10 },
    { query: String(keyword), platform_source: 1, platform_channel: 1, limit: 10 },
    { search_keyword: String(keyword), platform_source: 1, platform_channel: 1, limit: 10 }
  ];

  for (const payload of payloads) {
    const response = await fetchJsonOptional(API.searchAuthor, {
      method: "POST",
      body: JSON.stringify(payload)
    });
    const candidates = collectObjects(response).filter((item) => {
      const authorId = pickValue(item, ["o_author_id", "author_id", "id", "uid"]);
      return looksLikeAuthorId(authorId);
    });
    const exact = candidates.find((item) => {
      const names = [
        pickValue(item, ["unique_id", "short_id", "douyin_id"]),
        pickValue(item, ["sec_uid", "secUid"]),
        pickValue(item, ["nick_name", "nickname", "name"])
      ].map((value) => String(value ?? "").trim());
      return names.includes(String(keyword).trim());
    });
    const picked = exact ?? candidates[0];
    const authorId = pickValue(picked, ["o_author_id", "author_id", "id", "uid"]);
    if (authorId) {
      return String(authorId);
    }
  }

  return "";
}

async function fetchXingtuBundle(authorId, loadPlan = {}) {
  const shouldLoadAccount = loadPlan.account !== false;
  const shouldLoadNotes = loadPlan.notes === true;
  const awemeId = extractAwemeId(loadPlan.locators?.publishUrl);
  const requestedFilters = buildRequestedBusinessFilters(loadPlan.locators);
  const spreadOptions = buildSpreadInfoOptions(requestedFilters);
  const [
    baseInfo,
    spreadInfo,
    fansDistribution,
    marketingInfo,
    linkInfo,
    commerceSpreadInfo,
    commerceSeedBaseInfo,
    authorShow,
    homepageVideos1,
    homepageVideos2,
    homepageVideos3,
    homepageVideos4,
    homepageVideos5,
    starHomepageVideos1,
    starHomepageVideos2,
    starHomepageVideos3,
    itemReportDetail,
    itemReportTrend,
    videoCard,
    douyinItemInfo,
    douyinAwemeDetail
  ] = await Promise.all([
    shouldLoadAccount ? fetchJsonOptional(API.baseInfo(authorId)) : null,
    shouldLoadAccount ? fetchJsonOptional(API.spreadInfo(authorId, spreadOptions)) : null,
    shouldLoadAccount ? fetchJsonOptional(API.fansDistribution(authorId)) : null,
    shouldLoadAccount ? fetchJsonOptional(API.marketingInfo(authorId)) : null,
    shouldLoadAccount ? fetchJsonOptional(API.linkInfo(authorId)) : null,
    shouldLoadAccount ? fetchJsonOptional(API.commerceSpreadInfo(authorId)) : null,
    shouldLoadAccount ? fetchJsonOptional(API.commerceSeedBaseInfo(authorId, requestedFilters.plantingRangeParam || 2)) : null,
    shouldLoadNotes ? fetchJsonOptional(API.authorShow(authorId)) : null,
    shouldLoadNotes ? fetchJsonOptional(API.homepageVideos(authorId, 1)) : null,
    shouldLoadNotes ? fetchJsonOptional(API.homepageVideos(authorId, 2)) : null,
    shouldLoadNotes ? fetchJsonOptional(API.homepageVideos(authorId, 3)) : null,
    shouldLoadNotes ? fetchJsonOptional(API.homepageVideos(authorId, 4)) : null,
    shouldLoadNotes ? fetchJsonOptional(API.homepageVideos(authorId, 5)) : null,
    shouldLoadNotes ? fetchJsonOptional(API.starHomepageVideos(authorId, 1)) : null,
    shouldLoadNotes ? fetchJsonOptional(API.starHomepageVideos(authorId, 2)) : null,
    shouldLoadNotes ? fetchJsonOptional(API.starHomepageVideos(authorId, 3)) : null,
    shouldLoadNotes && awemeId ? fetchJsonOptionalFromAttempts([
      [API.itemReportDetail(awemeId), { method: "POST" }],
      [API.itemReportDetail(awemeId)]
    ]) : null,
    shouldLoadNotes && awemeId ? fetchJsonOptionalFromAttempts([
      [API.itemReportTrend(awemeId), { method: "POST" }],
      [API.itemReportTrend(awemeId)]
    ]) : null,
    shouldLoadNotes && awemeId ? fetchJsonOptionalFromAttempts([
      [API.videoCard(awemeId), { method: "POST" }],
      [API.videoCard(awemeId)]
    ]) : null,
    shouldLoadNotes && awemeId ? fetchJsonOptional(API.douyinItemInfo(awemeId)) : null,
    shouldLoadNotes && awemeId ? fetchJsonOptional(API.douyinAwemeDetail(awemeId)) : null
  ]);

  return {
    authorId,
    pageMetrics: loadPlan.pageMetrics ?? readVisiblePageMetrics(authorId),
    appliedFilters: Object.prototype.hasOwnProperty.call(loadPlan, "appliedFilters")
      ? loadPlan.appliedFilters
      : readBusinessFilterSnapshot(),
    baseInfo,
    spreadInfo,
    fansDistribution,
    marketingInfo,
    linkInfo,
    commerceSpreadInfo,
    commerceSeedBaseInfo,
    authorShow,
    homepageVideos: [homepageVideos1, homepageVideos2, homepageVideos3, homepageVideos4, homepageVideos5].filter(Boolean),
    starHomepageVideos: [starHomepageVideos1, starHomepageVideos2, starHomepageVideos3].filter(Boolean),
    itemReportDetail,
    itemReportTrend,
    videoCard,
    douyinItemInfo,
    douyinAwemeDetail,
    requestedFilters,
    filterWarning: loadPlan.filterWarning || window.__XINGTU_LAST_FILTER_WARNING__ || ""
  };
}

function readBusinessFilterSnapshot() {
  return {
    contentDataRange: currentDataRangeForSection("内容数据") || currentDataRangeFromText("内容数据"),
    contentVideoType: currentContentVideoTypeFromControls() ||
      currentVideoTypeFromText("内容数据"),
    onlyAssigned: currentCheckboxValue("内容数据", "只看指派"),
    contentExcludeMarketing: currentCheckboxValue("内容数据", "排除营销流量"),
    estimateVideoType: currentSelectValue(findSectionSelect("性价比/效果预估", "视频类型")) ||
      currentVideoTypeFromText("性价比/效果预估"),
    estimateExcludeMarketing: currentCheckboxValue("性价比/效果预估", "排除营销流量"),
    plantingDataRange: currentSelectValue(findPlantingDataRangeSelect()) ||
      currentDataRangeForSection("种草价值") ||
      currentDataRangeFromText("种草价值")
  };
}

function buildRequestedBusinessFilters(locators = {}) {
  const contentDataRange = normalizeDataRange(locators.contentDataRange) || "近30天";
  const plantingDataRange = normalizeDataRange(locators.plantingDataRange) || "近30天";
  const contentVideoType = normalizeContentVideoType(locators.contentVideoType) || "个人视频";
  const estimateVideoType = normalizeEstimateVideoType(locators.estimateVideoType) || "20-60s视频";
  return {
    contentDataRange,
    contentRangeDays: dataRangeToDays(contentDataRange),
    contentRangeParam: dataRangeToXingtuRangeParam(contentDataRange),
    contentVideoType,
    contentType: contentVideoType === "星图视频" ? 2 : 1,
    onlyAssigned: parseBooleanOption(locators.onlyAssigned),
    contentExcludeMarketing: parseBooleanOption(locators.contentExcludeMarketing),
    contentFlowType: parseBooleanOption(locators.contentExcludeMarketing) ? 1 : 0,
    estimateVideoType,
    estimateExcludeMarketing: parseBooleanOption(locators.estimateExcludeMarketing),
    plantingDataRange,
    plantingRangeDays: dataRangeToDays(plantingDataRange),
    plantingRangeParam: dataRangeToXingtuRangeParam(plantingDataRange)
  };
}

function buildSpreadInfoOptions(filters = {}) {
  return {
    range: filters.contentRangeParam || 2,
    type: filters.contentType || 1,
    onlyAssign: filters.onlyAssigned === null ? undefined : filters.onlyAssigned,
    flowType: filters.contentFlowType ?? 0
  };
}

function businessFilterMismatchMessage(requested = {}, applied = {}) {
  const errors = [];
  const compareValue = (label, expected, actual) => {
    if (!expected) {
      return;
    }
    if (!actual || actual !== expected) {
      errors.push(`${label}当前${actual || "未读取到"}，任务要求${expected}`);
    }
  };
  const compareBoolean = (label, expected, actual) => {
    if (expected === null || expected === undefined || actual === null || actual === undefined) {
      return;
    }
    if (actual !== expected) {
      errors.push(`${label}当前${actual ? "选中" : "未选中"}，任务要求${expected ? "选中" : "未选中"}`);
    }
  };

  compareValue("内容数据-数据范围", requested.contentDataRange, applied.contentDataRange);
  compareValue("内容数据-视频类型", requested.contentVideoType, applied.contentVideoType);
  compareBoolean("内容数据-只看指派", requested.onlyAssigned, applied.onlyAssigned);
  compareBoolean("内容数据-排除营销流量", requested.contentExcludeMarketing, applied.contentExcludeMarketing);
  compareValue("性价比/效果预估-视频类型", requested.estimateVideoType, applied.estimateVideoType);
  compareBoolean("性价比/效果预估-排除营销流量", requested.estimateExcludeMarketing, applied.estimateExcludeMarketing);
  compareValue("种草价值-数据范围", requested.plantingDataRange, applied.plantingDataRange);
  return errors.length ? `页面筛选与任务筛选不一致，已忽略页面文本：${errors.join("；")}` : "";
}

function appendFilterWarning(message) {
  const text = String(message || "").trim();
  if (!text) {
    return;
  }
  const current = String(window.__XINGTU_LAST_FILTER_WARNING__ || "").trim();
  if (!current) {
    window.__XINGTU_LAST_FILTER_WARNING__ = text;
    return;
  }
  if (current.includes(text)) {
    return;
  }
  window.__XINGTU_LAST_FILTER_WARNING__ = `${current}；${text}`;
}

function dataRangeToDays(value) {
  const normalized = normalizeDataRange(value);
  if (normalized === "近90天") return 90;
  if (normalized === "近7天") return 7;
  return 30;
}

function dataRangeToXingtuRangeParam(value) {
  const normalized = normalizeDataRange(value);
  if (normalized === "近90天") return 3;
  if (normalized === "近7天") return 1;
  return 2;
}

function buildUrl(baseUrl, params = {}) {
  const url = new URL(baseUrl);
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === "") {
      continue;
    }
    url.searchParams.set(key, String(value));
  }
  return url.toString();
}

function readVisiblePageMetrics(authorId) {
  const text = document.body?.innerText ?? "";
  if (!text || (authorId && !location.href.includes(authorId) && !text.includes(authorId))) {
    return null;
  }

  const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);
  const contentLines = sectionLines(lines, "内容数据", ["性价比/效果预估", "种草价值", "转化价值"]);
  const estimateLines = sectionLines(lines, "性价比/效果预估", ["优秀传播视频", "种草价值", "转化价值"]);
  const visiblePlantingLines = visibleSectionTextLines("种草价值");
  const plantingLines = visiblePlantingLines || [];
  const plantingMetric = visiblePlantingLines
    ? (labelText) => extractMetricFromSectionDom("种草价值", labelText) ||
      extractMetricFromStrictSectionLines(plantingLines, labelText)
    : () => null;
  return {
    authorId,
    nickname: extractVisibleNickname(lines, authorId),
    homeUrl: extractDouyinHomeUrlFromPage(),
    fansCount: extractFollowingMetric(lines, "粉丝数"),
    videoPrice1To20: extractLabeledPrice(lines, /1\s*-\s*20s?视频/i),
    videoPrice21To60: extractLabeledPrice(lines, /21\s*-\s*60s?视频/i),
    videoPrice60Plus: extractLabeledPrice(lines, /60s?以上视频/i),
    mcnName: extractFollowingValue(lines, /^(?:MCN|MCN名称)$/i),
    contentDataRange: currentDataRangeForSection("内容数据") ||
      extractSelectedDataRange(contentLines),
    contentVideoType: currentContentVideoTypeFromControls(),
    estimateVideoType: extractSelectedVideoType(estimateLines, ["1-20s视频", "20-60s视频", "60s以上视频", "图文"]),
    plantingDataRange: currentDataRangeForSection("种草价值") ||
      extractSelectedDataRange(plantingLines),
    playMedian: extractSectionMetric(contentLines, lines, "播放量中位数"),
    expectedCpm: extractSectionMetric(estimateLines, lines, "预期CPM"),
    expectedCpe: extractSectionMetric(estimateLines, lines, "预期CPE"),
    expectedPlay: extractSectionMetric(estimateLines, lines, "预期播放量"),
    expectedInteraction: extractFollowingNumber(lines, "预期互动量"),
    costPerformance: extractFollowingNumber(lines, "性价比"),
    costPerformanceIndex: extractFollowingNumber(lines, "性价比指数"),
    effectEstimate: extractFollowingNumber(lines, "效果预估"),
    estimatePlay: extractFollowingNumber(lines, "预估播放量"),
    estimateInteraction: extractFollowingNumber(lines, "预估互动量"),
    estimateLike: extractFollowingNumber(lines, "预估点赞量"),
    estimateComment: extractFollowingNumber(lines, "预估评论量"),
    estimateCollect: extractFollowingNumber(lines, "预估收藏量"),
    plantingValue: extractFollowingNumber(lines, "种草价值"),
    plantingIndex: extractFollowingNumber(lines, "种草指数"),
    plantingPlay: extractFollowingNumber(lines, "预估种草播放量"),
    gpm: extractFollowingNumber(lines, "GPM"),
    thousandPlayGmv: extractFollowingNumber(lines, "千次播放成交金额"),
    componentClickRate: extractFollowingNumber(lines, "组件点击率"),
    cartClickRate: extractFollowingNumber(lines, "购物车点击率"),
    conversionRate: extractFollowingNumber(lines, "转化率"),
    afterSearchAvgCount: plantingMetric("商单视频平均看后搜次数"),
    afterSearchRate: plantingMetric("商单视频看后搜率"),
    blueWordClickRate: plantingMetric("商单视频小蓝词点击率"),
    personalAfterSearchAvgCount: plantingMetric("个人视频平均看后搜次数"),
    personalAfterSearchRate: plantingMetric("个人视频看后搜率"),
    personalBlueWordClickRate: plantingMetric("个人视频小蓝词点击率"),
    a3GrowthCount: plantingMetric("A3增长数"),
    shopEntryCost: plantingMetric("进店成本"),
    finishRate: extractStrictSectionPercent(contentLines, "完播率"),
    interactionRate: extractSectionMetric(contentLines, lines, "互动率"),
    viralRate: extractSectionMetric(estimateLines, lines, "爆文率"),
    publishWorks: extractSectionMetric(contentLines, lines, "发布作品"),
    avgDuration: extractSectionMetric(contentLines, lines, "平均时长"),
    avgLike: extractSectionMetric(contentLines, lines, "平均点赞"),
    avgComment: extractSectionMetric(contentLines, lines, "平均评论"),
    avgShare: extractSectionMetric(contentLines, lines, "平均转发")
  };
}

function readVisibleBasePageMetrics(authorId) {
  const metrics = readVisiblePageMetrics(authorId);
  if (!metrics) {
    return null;
  }
  return {
    authorId: metrics.authorId,
    nickname: metrics.nickname,
    homeUrl: metrics.homeUrl,
    fansCount: metrics.fansCount,
    videoPrice1To20: metrics.videoPrice1To20,
    videoPrice21To60: metrics.videoPrice21To60,
    videoPrice60Plus: metrics.videoPrice60Plus,
    mcnName: metrics.mcnName
  };
}

async function collectVisibleBusinessPageMetrics(accountFields = [], locators = {}) {
  const requested = new Set(accountFields.map((field) => normalizeLine(field)));
  const needsContentOrEstimate = [
    "播放量中位数",
    "完播率",
    "互动率",
    "发布作品",
    "平均时长",
    "平均点赞",
    "平均评论",
    "平均转发",
    "预期CPM",
    "预期CPE",
    "预期播放量",
    "爆文率"
  ].some((field) => requested.has(normalizeLine(field)));
  const needsPlanting = [
    "商单视频平均看后搜次数",
    "商单视频看后搜率",
    "商单视频小蓝词点击率",
    "个人视频平均看后搜次数",
    "个人视频看后搜率",
    "个人视频小蓝词点击率",
    "A3增长数",
    "进店成本"
  ].some((field) => requested.has(normalizeLine(field)));
  const needsHomeUrl = ["达人主页链接", "主页链接"].some((field) => requested.has(normalizeLine(field)));

  let metrics = readVisiblePageMetrics("");
  if (needsPlanting) {
    metrics = stripPlantingPageMetrics(metrics);
  }
  if (needsHomeUrl && !metrics?.homeUrl) {
    metrics = mergePageMetrics(metrics, { homeUrl: await extractDouyinHomeUrlFromPopover() });
  }
  if (needsContentOrEstimate) {
    scrollToBusinessAbilityTop();
    await waitForAnyText(["播放量中位数", "预期CPM"], 5000);
    await sleep(400);
    metrics = mergePageMetrics(metrics, readVisiblePageMetrics(""), [
      "contentDataRange",
      "contentVideoType",
      "playMedian",
      "finishRate",
      "interactionRate",
      "publishWorks",
      "avgDuration",
      "avgLike",
      "avgComment",
      "avgShare",
      "expectedCpm",
      "expectedCpe",
      "expectedPlay",
      "viralRate",
      "estimateVideoType"
    ]);
  }

  if (needsPlanting) {
    scrollToBusinessSection("种草价值");
    await waitForAnyText(["商单视频看后搜率", "A3增长数", "进店成本"], 5000);
    const expectedPlantingRange = normalizeDataRange(locators.plantingDataRange);
    const beforePlantingMetrics = readStrictPlantingPageMetrics();
    const beforePlantingSignature = plantingMetricsSignature(beforePlantingMetrics);
    const beforePlantingRange = beforePlantingMetrics?.plantingDataRange || "";
    if (expectedPlantingRange) {
      await selectBusinessDataRange("种草价值", expectedPlantingRange);
      await waitForPageQuiet(5000, 700);
      await waitForPlantingRangeMetrics(expectedPlantingRange, beforePlantingSignature, beforePlantingRange);
    }
    await sleep(800);
    const plantingControlSnapshot = {
      plantingDataRange: currentSelectValue(findPlantingDataRangeSelect()) ||
        currentDataRangeForSection("种草价值")
    };
    if (expectedPlantingRange && plantingControlSnapshot.plantingDataRange !== expectedPlantingRange) {
      throw new Error(`种草价值-数据范围未切到${expectedPlantingRange}（当前${plantingControlSnapshot.plantingDataRange || "未读取到"}）`);
    }
    metrics = mergePageMetrics(metrics, mergePageMetrics(
      {
        ...mergePageMetrics(readVisiblePageMetrics(""), readStrictPlantingPageMetrics(), XINGTU_PLANTING_PAGE_METRIC_KEYS),
        plantingRangeVerified: true,
        plantingDataRange: expectedPlantingRange || plantingControlSnapshot.plantingDataRange
      },
      plantingControlSnapshot
    ), XINGTU_PLANTING_PAGE_METRIC_KEYS);
  }

  scrollToBusinessAbilityTop();
  if (needsHomeUrl && !metrics?.homeUrl) {
    metrics = mergePageMetrics(metrics, { homeUrl: await extractDouyinHomeUrlFromPopover() });
  }
  return metrics;
}

function readStrictPlantingPageMetrics() {
  const plantingLines = visibleSectionTextLines("种草价值") || [];
  const metric = (labelText) => extractMetricFromSectionDom("种草价值", labelText) ||
    extractMetricFromStrictSectionLines(plantingLines, labelText);
  return {
    plantingDataRange: currentSelectValue(findPlantingDataRangeSelect()) ||
      extractSelectedDataRange(plantingLines),
    afterSearchAvgCount: metric("商单视频平均看后搜次数"),
    afterSearchRate: metric("商单视频看后搜率"),
    blueWordClickRate: metric("商单视频小蓝词点击率"),
    personalAfterSearchAvgCount: metric("个人视频平均看后搜次数"),
    personalAfterSearchRate: metric("个人视频看后搜率"),
    personalBlueWordClickRate: metric("个人视频小蓝词点击率"),
    a3GrowthCount: metric("A3增长数"),
    shopEntryCost: metric("进店成本")
  };
}

function stripPlantingPageMetrics(metrics = null) {
  if (!metrics) {
    return metrics;
  }
  const next = { ...metrics };
  for (const key of XINGTU_PLANTING_PAGE_METRIC_KEYS) {
    if (key === "plantingRangeVerified") {
      next[key] = false;
    } else {
      next[key] = "";
    }
  }
  return next;
}

async function waitForPlantingRangeMetrics(expectedRange, beforeSignature = "", beforeRange = "") {
  const ready = await waitUntil(() => {
    const current = readStrictPlantingPageMetrics();
    if (current?.plantingDataRange !== expectedRange) {
      return false;
    }
    if (plantingSectionContainsOppositeRangeText(expectedRange)) {
      return false;
    }
    if (!beforeSignature || beforeRange === expectedRange) {
      return true;
    }
    const currentSignature = plantingMetricsSignature(current);
    return currentSignature !== beforeSignature ||
      plantingSectionContainsExpectedRangeContext(expectedRange);
  }, 8000);
  if (!ready) {
    throw new Error(`种草价值-${expectedRange}指标未刷新，停止读取当前页面种草数据`);
  }
}

function plantingMetricsSignature(metrics = null) {
  const current = metrics ?? readStrictPlantingPageMetrics();
  if (!current) {
    return "";
  }
  return [
    current.afterSearchAvgCount,
    current.afterSearchRate,
    current.blueWordClickRate,
    current.personalAfterSearchAvgCount,
    current.personalAfterSearchRate,
    current.personalBlueWordClickRate,
    current.a3GrowthCount,
    current.shopEntryCost
  ].map((value) => normalizeLine(value)).join("|");
}

function plantingSectionContainsOppositeRangeText(expectedRange) {
  const oppositeRange = expectedRange === "近90天" ? "近30天" : expectedRange === "近30天" ? "近90天" : "";
  if (!oppositeRange) {
    return false;
  }
  const sectionText = normalizedPlantingSectionText();
  return sectionText.includes(normalizeLine(oppositeRange)) ||
    sectionText.includes(normalizeLine(`${oppositeRange}无星立方订单`)) ||
    sectionText.includes(normalizeLine(`达人${oppositeRange}用户互动/转化量top视频`));
}

function plantingSectionContainsExpectedRangeContext(expectedRange) {
  const sectionText = normalizedPlantingSectionText();
  return sectionText.includes(normalizeLine(`${expectedRange}无星立方订单`)) ||
    sectionText.includes(normalizeLine(`达人${expectedRange}用户互动/转化量top视频`));
}

function normalizedPlantingSectionText() {
  const lines = visibleSectionTextLines("种草价值") || [];
  return normalizeLine(lines.join(""));
}

function mergePageMetrics(primary, fallback, overrideKeys = []) {
  if (!primary) {
    return fallback ?? null;
  }
  if (!fallback) {
    return primary;
  }
  const override = new Set(overrideKeys);
  const merged = { ...primary };
  for (const [key, value] of Object.entries(fallback)) {
    if (value !== null && value !== undefined && value !== "" &&
        (override.has(key) || merged[key] === null || merged[key] === undefined || merged[key] === "")) {
      merged[key] = value;
    }
  }
  return merged;
}

async function showBusinessAbilityPanel() {
  if (!isBusinessAbilityDetailPage()) {
    await openBusinessAbilityDetail();
  }
  if (isBusinessAbilityDetailPage()) {
    scrollToBusinessAbilityTop();
    await sleep(300);
  }
  if (!isBusinessAbilityDetailPage()) {
    throw new Error("未进入星图商业能力详情页，请确认达人主页已加载完成并有权限查看商业能力数据");
  }
}

function isBusinessAbilityDetailPage() {
  const text = document.body?.innerText ?? "";
  const normalized = normalizeLine(text);
  const hasContentSection = normalized.includes("内容数据") || normalized.includes("播放量中位数");
  const hasEstimateSection = normalized.includes("性价比/效果预估") ||
    normalized.includes("效果预估") ||
    normalized.includes("预期CPM") ||
    normalized.includes("预期CPE") ||
    normalized.includes("优秀传播视频");
  const hasSeedSection = normalized.includes("种草价值") ||
    normalized.includes("商单视频平均看后搜次数") ||
    normalized.includes("A3增长数") ||
    normalized.includes("进店成本");
  return hasContentSection && hasEstimateSection && hasSeedSection;
}

function waitForBusinessAbilityDetail(timeoutMs) {
  return waitUntil(isBusinessAbilityDetailPage, timeoutMs);
}

async function openBusinessAbilityDetail() {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    if (isBusinessAbilityDetailPage()) {
      scrollToBusinessAbilityTop();
      return true;
    }

    scrollToBusinessAbilitySummary();
    await sleep(250);
    const viewAllCandidates = findBusinessAbilityViewAllButtons();
    for (const viewAll of viewAllCandidates) {
      await clickElementTrusted(viewAll);
      if (await waitForBusinessAbilityDetail(8000)) {
        scrollToBusinessAbilityTop();
        return true;
      }
    }

    const businessTab = findBusinessAbilityTab();
    if (businessTab) {
      await clickElementTrusted(businessTab);
      if (await waitForBusinessAbilityDetail(8000)) {
        scrollToBusinessAbilityTop();
        return true;
      }
      await waitForText("查看全部", 2000).catch(() => {});
      const nextViewAllCandidates = findBusinessAbilityViewAllButtons();
      for (const nextViewAll of nextViewAllCandidates) {
        await clickElementTrusted(nextViewAll);
        if (await waitForBusinessAbilityDetail(8000)) {
          scrollToBusinessAbilityTop();
          return true;
        }
      }
    }

    await sleep(500);
  }
  return false;
}

function scrollToBusinessAbilitySummary() {
  const candidates = [
    findVisibleElementByText("商业能力"),
    findBusinessAbilityTab(),
    findVisibleElementByText("内容数据"),
    findVisibleElementByText("传播价值")
  ].filter(Boolean);
  if (!candidates.length) {
    return false;
  }
  scrollElementToScrollerOffset(candidates[0], 120);
  return true;
}

function findBusinessAbilityViewAllButton() {
  return findBusinessAbilityViewAllButtons()[0] ?? null;
}

function findBusinessAbilityViewAllButtons() {
  const normalizedText = normalizeLine("查看全部");
  const candidates = Array.from(document.querySelectorAll("button, a, div, span"))
    .filter((element) => isActuallyVisible(element) && normalizeLine(element.textContent).includes(normalizedText))
    .map((element) => {
      const clickable = element.closest("button, a, [role='button'], .xt-button, [class*='button'], [class*='Button']") ??
        nearestClickableAncestor(element) ??
        element;
      const rect = clickable.getBoundingClientRect();
      const text = normalizeLine(clickable.textContent || element.textContent);
      return {
        element: clickable,
        rect,
        text,
        score: scoreBusinessAbilityViewAllButton(clickable, rect, text)
      };
    })
    .filter(({ element }, index, items) => items.findIndex((item) => item.element === element) === index)
    .filter(({ rect, text, score }) => (
      text.includes(normalizedText) &&
      rect.top > 70 &&
      rect.top < Math.max(520, (window.innerHeight || 0) - 80) &&
      Number.isFinite(score)
    ))
    .sort((left, right) => left.score - right.score || left.rect.top - right.rect.top || right.rect.left - left.rect.left);
  const fallback = findVisibleElementByText("查看全部");
  return candidates.map((candidate) => candidate.element)
    .concat(fallback ? [fallback] : [])
    .filter((element, index, items) => element && items.indexOf(element) === index);
}

function scoreBusinessAbilityViewAllButton(element, rect, text) {
  if (!text.includes(normalizeLine("查看全部"))) {
    return Number.POSITIVE_INFINITY;
  }
  const context = closestContextText(element, 7);
  let score = 0;
  if (context.includes("商业能力")) score -= 40;
  if (context.includes("内容数据")) score -= 20;
  if (context.includes("传播价值")) score -= 12;
  if (context.includes("性价比") || context.includes("种草价值")) score -= 8;
  if (text === normalizeLine("查看全部")) score -= 6;
  score += Math.abs(rect.top - 180) / 12;
  score += rect.left > 520 ? 0 : (520 - rect.left) / 16;
  return score;
}

function closestContextText(element, maxDepth = 6) {
  let current = element;
  const lines = [];
  for (let depth = 0; current && current !== document.body && depth < maxDepth; depth += 1) {
    const text = normalizeLine(current.innerText || current.textContent || "");
    if (text && text.length <= 1200) {
      lines.push(text);
    }
    current = current.parentElement;
  }
  return lines.join(" ");
}

function scrollToBusinessAbilityTop() {
  const title = findBusinessSectionTitle("传播价值") || findBusinessSectionTitle("内容数据") || findBusinessAbilityTab();
  if (!title) {
    return;
  }
  scrollElementToScrollerOffset(title, 120);
}

function scrollToBusinessSection(sectionTitle) {
  const title = findBusinessSectionTitle(sectionTitle);
  if (!title) {
    return false;
  }
  scrollElementToScrollerOffset(title, 150);
  return true;
}

function findBusinessSectionTitle(sectionTitle) {
  const normalizedTitle = normalizeLine(sectionTitle);
  const preferredTags = new Set(["LABEL", "H2", "H3", "H4", "H5"]);
  return Array.from(document.querySelectorAll("label, h1, h2, h3, h4, h5, div, span, button"))
    .filter((element) => isActuallyVisible(element) && normalizeLine(element.textContent) === normalizedTitle)
    .map((element) => {
      const rect = element.getBoundingClientRect();
      const className = String(element.className || "");
      return {
        element,
        rect,
        score: (preferredTags.has(element.tagName) ? 0 : 20) +
          (className.includes("xt-title") ? 0 : 8) +
          (rect.width <= 180 && rect.height <= 40 ? 0 : 12) +
          (rect.left >= 300 ? 0 : 30)
      };
    })
    .sort((left, right) => left.score - right.score ||
      Math.abs(left.rect.top) - Math.abs(right.rect.top) ||
      left.rect.top - right.rect.top ||
      left.rect.left - right.rect.left)[0]?.element ?? null;
}

function scrollElementToScrollerOffset(element, offset = 150) {
  const scroller = findScrollableAncestor(element);
  const scrollerRect = scroller === document.scrollingElement || scroller === document.documentElement || scroller === document.body
    ? { top: 0, height: window.innerHeight || document.documentElement.clientHeight || 0 }
    : scroller.getBoundingClientRect();
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const rect = element.getBoundingClientRect();
    const nextTop = Math.max(0, scroller.scrollTop + rect.top - scrollerRect.top - offset);
    if (Math.abs((rect.top - scrollerRect.top) - offset) < 18) {
      break;
    }
    try {
      scroller.scrollTop = nextTop;
    } catch (_error) {
      scroller.scrollTo?.({ top: nextTop });
    }
  }
}

function findBusinessAbilityTab() {
  return findVisibleElementsByText("商业能力")
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      const leftTopWeight = leftRect.top < 220 ? 0 : 1;
      const rightTopWeight = rightRect.top < 220 ? 0 : 1;
      return leftTopWeight - rightTopWeight ||
        leftRect.top - rightRect.top ||
        leftRect.left - rightRect.left;
    })[0] ?? null;
}

async function openCreationAbilityPanel() {
  if ((document.body?.innerText ?? "").includes("全部视频") && (document.body?.innerText ?? "").includes("最新15个视频表现柱状图")) {
    return true;
  }
  const tab = findVisibleElementsByText("创作能力")
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      const leftTopWeight = leftRect.top < 220 ? 0 : 1;
      const rightTopWeight = rightRect.top < 220 ? 0 : 1;
      return leftTopWeight - rightTopWeight || leftRect.top - rightRect.top || leftRect.left - rightRect.left;
    })[0];
  if (!tab) {
    return false;
  }
  await clickElementTrusted(tab);
  return waitForText("全部视频", 8000);
}

function clickElement(element) {
  scrollElementIntoView(element);
  element.focus?.({ preventScroll: true });
  dispatchMouseSequence(element);
  if (typeof element.click === "function") {
    element.click();
  }
}

function clickElementCenter(element) {
  if (!element) {
    return;
  }
  scrollElementIntoView(element);
  const rect = element.getBoundingClientRect();
  const x = rect.left + Math.max(1, Math.min(rect.width / 2, rect.width - 1));
  const y = rect.top + Math.max(1, Math.min(rect.height / 2, rect.height - 1));
  const topTarget = document.elementFromPoint?.(x, y);
  const targets = [topTarget, element]
    .filter(Boolean)
    .filter((target, index, items) => items.indexOf(target) === index);
  for (const target of targets) {
    target.focus?.({ preventScroll: true });
    dispatchMouseSequence(target, { x, y });
  }
  if (typeof topTarget?.click === "function") {
    topTarget.click();
  } else if (typeof element.click === "function") {
    element.click();
  }
}

async function clickElementCenterTrusted(element) {
  if (!element) {
    return false;
  }
  scrollElementIntoView(element);
  await sleep(60);
  const rect = element.getBoundingClientRect();
  const x = rect.left + Math.max(1, Math.min(rect.width / 2, rect.width - 1));
  const y = rect.top + Math.max(1, Math.min(rect.height / 2, rect.height - 1));
  if (await trustedClickAt(x, y)) {
    return true;
  }
  clickElementCenter(element);
  return false;
}

async function clickElementTrusted(element) {
  if (!element) {
    return false;
  }
  return clickElementCenterTrusted(element);
}

function clickPopupOption(element) {
  const option = element?.closest?.(".xt-option, [role='option'], .xt-select-dropdown__item, .xt-select-option") ?? element;
  if (!option) {
    return;
  }
  option.focus?.({ preventScroll: true });
  const rect = option.getBoundingClientRect();
  const x = rect.left + Math.max(1, Math.min(rect.width / 2, rect.width - 1));
  const y = rect.top + Math.max(1, Math.min(rect.height / 2, rect.height - 1));
  const topTarget = document.elementFromPoint?.(x, y);
  const contentTarget = option.querySelector?.(".xt-option__content");
  const targets = [topTarget, contentTarget, option]
    .filter(Boolean)
    .filter((target, index, items) => items.indexOf(target) === index);
  for (const target of targets) {
    dispatchMouseSequence(target, { x, y });
    try {
      target.click?.();
    } catch (_error) {
    }
  }
}

async function clickPopupOptionTrusted(element) {
  const option = element?.closest?.(".xt-option, [role='option'], .xt-select-dropdown__item, .xt-select-option") ?? element;
  if (!option) {
    return false;
  }
  const rect = option.getBoundingClientRect();
  const x = rect.left + Math.max(1, Math.min(rect.width / 2, rect.width - 1));
  const y = rect.top + Math.max(1, Math.min(rect.height / 2, rect.height - 1));
  if (await trustedClickAt(x, y)) {
    return true;
  }
  clickPopupOption(option);
  return false;
}

async function trustedClickAt(x, y) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
    return false;
  }
  try {
    const response = await withTimeout(
      chrome.runtime.sendMessage({
        source: "xingtu-data-collector",
        action: "trusted-click",
        payload: { x, y }
      }),
      XINGTU_TRUSTED_CLICK_TIMEOUT_MS,
      "星图真实点击超时"
    );
    return Boolean(response?.ok && response?.clicked);
  } catch (_error) {
    return false;
  }
}

function dispatchMouseSequence(element, point = null) {
  const rect = element.getBoundingClientRect();
  const clientX = point?.x ?? rect.left + Math.max(1, Math.min(rect.width / 2, rect.width - 1));
  const clientY = point?.y ?? rect.top + Math.max(1, Math.min(rect.height / 2, rect.height - 1));
  const eventInit = {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX,
    clientY,
    button: 0,
    buttons: 1
  };
  for (const type of ["pointerover", "mouseover", "pointermove", "mousemove", "pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
    try {
      if (type.startsWith("pointer") && typeof PointerEvent === "function") {
        element.dispatchEvent(new PointerEvent(type, {
          ...eventInit,
          pointerId: 1,
          pointerType: "mouse",
          isPrimary: true
        }));
      } else {
        element.dispatchEvent(new MouseEvent(type, eventInit));
      }
    } catch (_error) {
    }
  }
}

function hoverElement(element) {
  scrollElementIntoView(element);
  const rect = element.getBoundingClientRect();
  const eventInit = {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX: rect.left + Math.max(1, Math.min(rect.width / 2, rect.width - 1)),
    clientY: rect.top + Math.max(1, Math.min(rect.height / 2, rect.height - 1)),
    button: 0,
    buttons: 0
  };
  for (const type of ["pointerover", "mouseover", "pointerenter", "mouseenter", "mousemove"]) {
    try {
      if (type.startsWith("pointer") && typeof PointerEvent === "function") {
        element.dispatchEvent(new PointerEvent(type, {
          ...eventInit,
          pointerId: 1,
          pointerType: "mouse",
          isPrimary: true
        }));
      } else {
        element.dispatchEvent(new MouseEvent(type, eventInit));
      }
    } catch (_error) {
    }
  }
}

function scrollElementIntoView(element) {
  const scroller = findScrollableAncestor(element);
  if (!scroller) {
    element.scrollIntoView?.({ block: "center", inline: "center" });
    return;
  }
  const scrollerRect = scroller === document.scrollingElement || scroller === document.documentElement || scroller === document.body
    ? { top: 0, height: window.innerHeight || document.documentElement.clientHeight || 0 }
    : scroller.getBoundingClientRect();
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const elementRect = element.getBoundingClientRect();
    const visibleTop = scrollerRect.top + 24;
    const visibleBottom = scrollerRect.top + scrollerRect.height - 24;
    if (elementRect.top >= visibleTop && elementRect.bottom <= visibleBottom) {
      return;
    }
    const nextTop = scroller.scrollTop + elementRect.top - scrollerRect.top - scrollerRect.height / 3;
    try {
      scroller.scrollTop = Math.max(0, nextTop);
    } catch (_error) {
      scroller.scrollTo?.({ top: Math.max(0, nextTop) });
    }
  }
}

function findScrollableAncestor(element) {
  const businessScroller = document.getElementById("star-layout-content-wrapper");
  if (businessScroller && (!element || businessScroller.contains(element))) {
    return businessScroller;
  }
  let current = element?.parentElement;
  while (current && current !== document.body) {
    if (current.scrollHeight > current.clientHeight + 20) {
      const style = getComputedStyle(current);
      if (/(auto|scroll|overlay)/.test(style.overflowY)) {
        return current;
      }
    }
    current = current.parentElement;
  }
  return document.scrollingElement || document.documentElement;
}

function findVisibleElementByText(text) {
  return findVisibleElementsByText(text)[0] ?? null;
}

function findVisibleElementsByText(text) {
  const candidates = Array.from(document.querySelectorAll("button, a, div, span, label, h1, h2, h3, h4, h5, p"));
  return candidates
    .filter((element) => isActuallyVisible(element) && element.textContent?.trim() === text)
    .sort(sortVisibleElementsForAction);
}

function sortVisibleElementsForAction(left, right) {
  const leftRect = left.getBoundingClientRect();
  const rightRect = right.getBoundingClientRect();
  const leftInViewport = isInViewport(left) ? 0 : 1;
  const rightInViewport = isInViewport(right) ? 0 : 1;
  return leftInViewport - rightInViewport ||
    Math.abs(leftRect.top) - Math.abs(rightRect.top) ||
    leftRect.top - rightRect.top ||
    leftRect.left - rightRect.left;
}

async function applyBusinessAbilityFilters(locators = {}) {
  let changed = false;
  const contentDataRange = normalizeDataRange(locators.contentDataRange);
  const plantingDataRange = normalizeDataRange(locators.plantingDataRange);
  const contentVideoType = normalizeContentVideoType(locators.contentVideoType);
  const estimateVideoType = normalizeEstimateVideoType(locators.estimateVideoType);
  changed = await selectBusinessDataRange("内容数据", contentDataRange) || changed;
  if (contentVideoType) {
    changed = await setBusinessContentVideoType(contentVideoType) || changed;
  }
  changed = await setCheckboxByLabelInSection("内容数据", "只看指派", parseBooleanOption(locators.onlyAssigned)) || changed;
  changed = await setCheckboxByLabelInSection("内容数据", "排除营销流量", parseBooleanOption(locators.contentExcludeMarketing)) || changed;
  changed = await selectBusinessEstimateVideoType(estimateVideoType) || changed;
  changed = await setCheckboxByLabelInSection("性价比/效果预估", "排除营销流量", parseBooleanOption(locators.estimateExcludeMarketing)) || changed;
  changed = await selectBusinessDataRange("种草价值", plantingDataRange) || changed;
  await waitForAnyText(["预期CPM", "预期CPE", "播放量中位数"], 4000).catch(() => {});
  if (changed) {
    await waitForPageQuiet(5000, 700);
    await sleep(400);
  }
  await assertBusinessFilterState({
    contentDataRange,
    contentVideoType,
    plantingDataRange,
    estimateVideoType,
    onlyAssigned: parseBooleanOption(locators.onlyAssigned),
    contentExcludeMarketing: parseBooleanOption(locators.contentExcludeMarketing),
    estimateExcludeMarketing: parseBooleanOption(locators.estimateExcludeMarketing)
  });
}

async function selectBusinessDataRange(sectionTitle, optionText) {
  if (!optionText) {
    return false;
  }
  const select = sectionTitle === "种草价值"
    ? findPlantingDataRangeSelect(optionText)
    : findContentDataRangeSelect();
  return chooseBusinessSelectOption(select, optionText);
}

async function setBusinessContentVideoType(videoType) {
  scrollToBusinessSection("内容数据");
  await sleep(200);
  const label = findSectionCheckboxButton("内容数据", videoType);
  if (!label || isControlChecked(label)) {
    return false;
  }
  await clickElementTrusted(label);
  await waitUntil(() => currentCheckboxButtonValue("内容数据", videoType) === true, 2500);
  return currentCheckboxButtonValue("内容数据", videoType) === true;
}

async function selectBusinessEstimateVideoType(optionText) {
  if (!optionText) {
    return false;
  }
  const select = findEstimateVideoTypeSelect();
  return chooseBusinessSelectOption(select, optionText);
}

async function chooseBusinessSelectOption(select, optionText) {
  if (!select) {
    return false;
  }
  const originalRect = select.getBoundingClientRect();
  const getCurrentSelect = () => select.isConnected ? select : findNearestSelect(originalRect);
  const readFreshValue = () => currentSelectValue(getCurrentSelect());
  if (readFreshValue() === optionText) {
    return false;
  }
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const currentSelect = getCurrentSelect();
    if (!currentSelect) {
      return false;
    }
    scrollElementIntoView(currentSelect);
    await sleep(120);
    const option = await openBusinessSelectDropdown(currentSelect, optionText);
    if (option) {
      await clickPopupOptionTrusted(option);
      await waitUntil(() => readFreshValue() === optionText, 2500).catch(() => {});
      await sleep(250);
      if (readFreshValue() === optionText || currentSelectValue(getCurrentSelect()) === optionText) {
        return true;
      }
    }
    await sleep(250);
  }
  return false;
}

async function openBusinessSelectDropdown(select, optionText) {
  const anchorRect = select.getBoundingClientRect();
  const targets = [
    select,
    select.querySelector?.("input.el-input__inner, input"),
    select.querySelector?.(".xt-select__selection"),
    select.querySelector?.(".xt-select__label")
  ]
    .filter(Boolean)
    .filter((target, index, items) => items.indexOf(target) === index)
    .filter((target) => isVisible(target));

  for (const target of targets) {
    clickElementCenter(target);
    await sleep(300);
    const option = findOpenDropdownOption(optionText, anchorRect);
    if (option) {
      return option;
    }
  }
  for (const target of targets) {
    await clickElementCenterTrusted(target);
    await sleep(300);
    const option = findOpenDropdownOption(optionText, anchorRect);
    if (option) {
      return option;
    }
  }
  return null;
}

function findContentDataRangeSelect() {
  scrollToBusinessSection("内容数据");
  return findPeriodSelectInSection("内容数据") ?? visiblePeriodSelects()[0] ?? null;
}

function findPlantingDataRangeSelect(optionText = "") {
  scrollToBusinessSection("种草价值");
  const sectionSelect = findPeriodSelectInSection("种草价值") ||
    findKnownValueSelectInSection("种草价值", optionText) ||
    findKnownValueSelectInSection("种草价值", "近90天") ||
    findKnownValueSelectInSection("种草价值", "近30天") ||
    findSectionSelect("种草价值", "数据范围");
  if (sectionSelect) {
    return sectionSelect;
  }
  const bounds = findSectionBounds("种草价值");
  return visiblePeriodSelects().find((select) => {
    const rect = select.getBoundingClientRect();
    if (bounds) {
      return rect.top >= bounds.top && rect.top < bounds.bottom;
    }
    const title = findBusinessSectionTitle("种草价值");
    return title && rect.top > title.getBoundingClientRect().top;
  }) ?? null;
}

function businessPeriodSelectByIndex(index) {
  const selects = visiblePeriodSelects();
  return selects[index] ?? null;
}

function findEstimateVideoTypeSelect() {
  scrollToBusinessSection("性价比/效果预估");
  const sectionSelect = findSectionSelect("性价比/效果预估", "视频类型");
  if (sectionSelect) {
    return sectionSelect;
  }
  const candidates = Array.from(document.querySelectorAll(".xt-select--small, .xt-select"))
    .filter((element) => isActuallyVisible(element) && isInViewport(element))
    .filter((element) => {
      const text = normalizeLine(element.textContent);
      return text.includes("视频类型") ||
        isEstimateVideoTypeValue(currentSelectValue(element)) ||
        /1-20s视频|20-60s视频|60s以上视频|图文/.test(text);
    })
    .sort((left, right) => {
      const leftSmall = String(left.className).includes("xt-select--small") ? 0 : 1;
      const rightSmall = String(right.className).includes("xt-select--small") ? 0 : 1;
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      return leftSmall - rightSmall || leftRect.top - rightRect.top || leftRect.left - rightRect.left;
    });
  return candidates[0] ?? findSectionSelect("性价比/效果预估", "视频类型");
}

function findPeriodSelectInSection(sectionTitle) {
  const candidates = sectionElements(sectionTitle, ".period-select, .xt-select")
    .filter((element) => String(element.className).includes("period-select") ||
      normalizeLine(element.textContent).includes("数据范围") ||
      isDataRangeValue(currentSelectValue(element)))
    .sort((left, right) => left.getBoundingClientRect().top - right.getBoundingClientRect().top ||
      left.getBoundingClientRect().left - right.getBoundingClientRect().left);
  return candidates[0] ?? null;
}

function visiblePeriodSelects() {
  return Array.from(document.querySelectorAll(".period-select"))
    .filter((element) => isActuallyVisible(element) && isInViewport(element))
    .sort((left, right) => left.getBoundingClientRect().top - right.getBoundingClientRect().top ||
      left.getBoundingClientRect().left - right.getBoundingClientRect().left);
}

function findOpenDropdownOption(optionText, anchorRect = null) {
  const exactText = normalizeLine(optionText);
  const selectors = [".xt-option", ".xt-option__content", "[role='option']", ".xt-select-dropdown__item", ".xt-select-option"];
  const candidates = selectors
    .flatMap((selector) => Array.from(document.querySelectorAll(selector)))
    .map((element) => element.closest?.(".xt-option") ?? element)
    .filter((element, index, items) => items.indexOf(element) === index)
    .filter((element) => isActuallyVisible(element) && isInViewport(element) && normalizeLine(element.textContent) === exactText);
  if (!candidates.length) {
    candidates.push(...Array.from(document.querySelectorAll("div, span, li"))
      .filter((element) => isActuallyVisible(element) && isInViewport(element) && normalizeLine(element.textContent) === exactText));
  }
  const anchored = anchorRect
    ? candidates.filter((element) => dropdownOptionBelongsToAnchor(element, anchorRect))
    : candidates;
  return (anchored.length ? anchored : candidates)
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      const leftPopup = isPopupElement(left) ? 0 : 1;
      const rightPopup = isPopupElement(right) ? 0 : 1;
      const leftDistance = anchorRect ? dropdownOptionDistance(leftRect, anchorRect) : 0;
      const rightDistance = anchorRect ? dropdownOptionDistance(rightRect, anchorRect) : 0;
      return leftPopup - rightPopup ||
        leftDistance - rightDistance ||
        leftRect.top - rightRect.top ||
        leftRect.left - rightRect.left;
    })[0] ?? null;
}

function dropdownOptionBelongsToAnchor(option, anchorRect) {
  const rect = option.getBoundingClientRect();
  const horizontalOverlap = Math.min(rect.right, anchorRect.right + 12) - Math.max(rect.left, anchorRect.left - 12);
  const horizontalNear = horizontalOverlap > Math.min(rect.width, anchorRect.width) * 0.35 ||
    Math.abs((rect.left + rect.right) / 2 - (anchorRect.left + anchorRect.right) / 2) < Math.max(anchorRect.width, rect.width);
  const verticalNear = Math.abs(rect.top - anchorRect.bottom) < 360 ||
    Math.abs(anchorRect.top - rect.bottom) < 120;
  return horizontalNear && verticalNear;
}

function dropdownOptionDistance(rect, anchorRect) {
  const rectCenterX = (rect.left + rect.right) / 2;
  const anchorCenterX = (anchorRect.left + anchorRect.right) / 2;
  const verticalGap = rect.top >= anchorRect.bottom
    ? rect.top - anchorRect.bottom
    : anchorRect.top - rect.bottom;
  return Math.abs(rectCenterX - anchorCenterX) + Math.max(0, verticalGap) * 1.5;
}

async function selectDataRangeForSection(sectionTitle, optionText) {
  if (!optionText) {
    return false;
  }
  const textChanged = await chooseValueTextInSection(sectionTitle, ["近30天", "近90天", "近7天"], optionText);
  if (textChanged || currentDataRangeFromText(sectionTitle) === optionText || currentDataRangeForSection(sectionTitle) === optionText) {
    return textChanged;
  }
  const sectionChanged = await selectOptionInSection(sectionTitle, "数据范围", optionText);
  if (sectionChanged || currentDataRangeForSection(sectionTitle) === optionText) {
    return sectionChanged;
  }
  const fallbackIndex = sectionTitle === "种草价值" ? 1 : 0;
  return selectOptionAfterLabel("数据范围：", optionText, fallbackIndex);
}

async function setCheckboxByLabel(text, expected, index = 0) {
  if (expected === null) {
    return false;
  }
  const labels = visibleLabels(text).filter((label) => label.querySelector("input"));
  const label = labels[index];
  if (!label || isControlChecked(label) === expected) {
    return false;
  }
  await clickElementTrusted(label);
  await waitUntil(() => isControlChecked(label) === expected, 1500);
  return true;
}

async function setCheckboxByLabelInSection(sectionTitle, text, expected) {
  if (expected === null) {
    return false;
  }
  const label = findSectionCheckboxControl(sectionTitle, text);
  if (!label || isControlDisabled(label.element) || isControlChecked(label.element) === expected) {
    return false;
  }
  await clickElementTrusted(label.element);
  await waitUntil(() => currentCheckboxValue(sectionTitle, text) === expected, 1500);
  return currentCheckboxValue(sectionTitle, text) === expected;
}

async function setCheckboxButton(text, expected, index = 0) {
  if (expected === null) {
    return false;
  }
  const label = visibleLabels(text).filter((item) => item.className.includes("checkbox-button"))[index];
  if (!label || isControlChecked(label) === expected) {
    return false;
  }
  await clickElementTrusted(label);
  await waitUntil(() => isControlChecked(label) === expected, 1500);
  return true;
}

async function setCheckboxButtonInSection(sectionTitle, text, expected) {
  if (expected === null) {
    return false;
  }
  const label = findSectionCheckboxButton(sectionTitle, text);
  if (!label || isControlChecked(label) === expected) {
    return false;
  }
  await clickElementTrusted(label);
  await waitUntil(() => isControlChecked(label) === expected, 1500);
  return true;
}

async function selectOptionAfterLabel(prefixText, optionText, index = 0) {
  if (!optionText) {
    return false;
  }
  const select = firstSelectAfterLabel(prefixText, index);
  return chooseSelectOption(select, optionText);
}

function firstSelectAfterLabel(prefixText, index = 0) {
  const normalizedPrefix = String(prefixText).replace(/[:：]\s*$/, "");
  return Array.from(document.querySelectorAll(".xt-select"))
    .filter((element) => isVisible(element) && String(element.textContent ?? "").replace(/\s+/g, "").includes(normalizedPrefix))[index];
}

async function selectOptionInSection(sectionTitle, labelText, optionText) {
  if (!optionText) {
    return false;
  }
  const directValues = knownValuesForLabel(labelText, optionText);
  if (directValues.length > 1) {
    const directChanged = await chooseValueTextInSection(sectionTitle, directValues, optionText);
    if (directChanged || currentSectionFilterValue(sectionTitle, labelText) === optionText) {
      return directChanged;
    }
  }
  const selects = [
    findSectionSelect(sectionTitle, labelText),
    findKnownValueSelectInSection(sectionTitle, optionText)
  ].filter(Boolean);
  for (const select of selects.filter((element, index, items) => items.indexOf(element) === index)) {
    if (await chooseSelectOption(select, optionText)) {
      return true;
    }
  }
  return chooseTextDropdownInSection(sectionTitle, labelText, optionText);
}

async function chooseValueTextInSection(sectionTitle, knownValues, optionText) {
  const currentValue = currentValueTextInSection(sectionTitle, knownValues);
  if (currentValue === optionText) {
    return false;
  }
  const trigger = findValueTextTriggerInSection(sectionTitle, knownValues);
  if (!trigger) {
    return false;
  }
  for (let attempt = 0; attempt < 4; attempt += 1) {
    clickElement(trigger);
    await sleep(300);
    const option = findDropdownOption(optionText);
    if (option) {
      clickElement(option.closest?.(".xt-option") ?? option);
      await sleep(650);
      if (currentValueTextInSection(sectionTitle, knownValues) === optionText ||
          sectionTextIncludes(sectionTitle, optionText)) {
        return true;
      }
    }
    await sleep(250);
  }
  return false;
}

function currentValueTextInSection(sectionTitle, knownValues) {
  const values = sectionElements(sectionTitle, "span, div, input")
    .map((element) => knownSelectValueFromElement(element, knownValues))
    .filter((value) => knownValues.includes(value));
  return values[0] ?? "";
}

function findValueTextTriggerInSection(sectionTitle, knownValues) {
  const valueElements = sectionElements(sectionTitle, "span, div, input")
    .filter((element) => knownValues.includes(knownSelectValueFromElement(element, knownValues)))
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      return leftRect.top - rightRect.top || rightRect.left - leftRect.left;
    });
  const valueElement = valueElements[0];
  if (!valueElement) {
    return null;
  }
  return valueElement.closest(".xt-select, [class*='select'], [class*='Select'], [class*='dropdown'], [class*='Dropdown'], [class*='trigger'], [class*='Trigger']") ??
    nearestClickableAncestor(valueElement) ??
    valueElement;
}

function knownSelectValueFromElement(element, knownValues) {
  if (!element) {
    return "";
  }
  const attrValue = element.getAttribute?.("value") || element.getAttribute?.("aria-label") || element.getAttribute?.("title") || "";
  const textValue = element.tagName === "INPUT" ? attrValue : (element.textContent || attrValue || "");
  const text = String(textValue ?? "").replace(/\s+/g, "").trim();
  if (!text || text.length > 24) {
    return "";
  }
  for (const value of knownValues) {
    const normalizedValue = normalizeLine(value);
    if (text === normalizedValue || text === `数据范围：${normalizedValue}` || text === `视频类型：${normalizedValue}`) {
      return value;
    }
  }
  return "";
}

function nearestClickableAncestor(element) {
  let current = element;
  for (let depth = 0; current && depth < 5; depth += 1) {
    const role = current.getAttribute?.("role") || "";
    const tabIndex = current.getAttribute?.("tabindex");
    if (current.tagName === "BUTTON" || current.tagName === "INPUT" || role === "button" || role === "combobox" || tabIndex !== null) {
      return current;
    }
    current = current.parentElement;
  }
  return element.parentElement;
}

function currentDataRangeForSection(sectionTitle) {
  const select = findSectionSelect(sectionTitle, "数据范围");
  return currentSelectValue(select);
}

function findSectionSelect(sectionTitle, labelText) {
  const bounds = findSectionBounds(sectionTitle);
  if (!bounds) {
    return null;
  }
  const normalizedLabel = String(labelText).replace(/[:：]\s*$/, "");
  const selects = Array.from(document.querySelectorAll(".xt-select"))
    .filter((element) => {
      const rect = element.getBoundingClientRect();
      return isActuallyVisible(element) &&
        rect.top >= bounds.top &&
        rect.top < bounds.bottom;
    })
    .sort((left, right) => left.getBoundingClientRect().top - right.getBoundingClientRect().top);
  const labeled = selects.filter((element) => (
    String(element.textContent ?? "").replace(/\s+/g, "").includes(normalizedLabel)
  ));
  const candidates = labeled.length ? labeled : selects;
  return candidates
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      const leftInViewport = isInViewport(left) ? 0 : 1;
      const rightInViewport = isInViewport(right) ? 0 : 1;
      return leftInViewport - rightInViewport ||
        Math.abs(leftRect.top - bounds.titleTop) - Math.abs(rightRect.top - bounds.titleTop) ||
        leftRect.top - rightRect.top;
    })[0] ?? null;
}

function findKnownValueSelectInSection(sectionTitle, optionText) {
  const normalizedOption = normalizeKnownSelectValue(optionText);
  if (!normalizedOption) {
    return null;
  }
  const candidates = sectionElements(sectionTitle, ".xt-select")
    .filter((element) => {
      const value = currentSelectValue(element) || normalizeKnownSelectValue(element.textContent);
      return value && value !== normalizedOption && sameSelectFamily(value, normalizedOption);
    })
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      return leftRect.top - rightRect.top || leftRect.left - rightRect.left;
    });
  return candidates[0] ?? null;
}

function findSectionCheckboxButton(sectionTitle, text) {
  return findSectionCheckboxControl(sectionTitle, text)?.element ?? null;
}

function currentCheckboxButtonValue(sectionTitle, text) {
  const label = findSectionCheckboxButton(sectionTitle, text);
  return label && !isControlDisabled(label) ? isControlChecked(label) : null;
}

function currentCheckboxValue(sectionTitle, text) {
  const label = findSectionCheckboxControl(sectionTitle, text);
  return label && !isControlDisabled(label.element) ? isControlChecked(label.element) : null;
}

function findSectionCheckboxControl(sectionTitle, text) {
  const normalizedText = normalizeLine(text);
  const controls = sectionElements(sectionTitle, "label, .xt-checkbox, .xt-checkbox-button, [role='checkbox'], input[type='checkbox']")
    .map((element) => {
      const wrapper = element.closest("label, .xt-checkbox, .xt-checkbox-button, [role='checkbox']") ?? element;
      return wrapper;
    })
    .filter((element, index, items) => items.indexOf(element) === index)
    .filter((element) => normalizeLine(element.textContent).includes(normalizedText));
  return controls[0] ? { element: controls[0] } : null;
}

async function chooseTextDropdownInSection(sectionTitle, labelText, optionText) {
  const trigger = findTextDropdownTriggerInSection(sectionTitle, labelText, optionText);
  if (!trigger) {
    return false;
  }
  const beforeValue = currentKnownValueFromTrigger(trigger);
  if (beforeValue === optionText) {
    return false;
  }

  for (let attempt = 0; attempt < 3; attempt += 1) {
    clickElement(trigger);
    await sleep(300);
    const option = findDropdownOption(optionText);
    if (option) {
      clickElement(option.closest?.(".xt-option") ?? option);
      await sleep(500);
      if (currentSectionFilterValue(sectionTitle, labelText) === optionText ||
          currentKnownValueFromTrigger(trigger) === optionText) {
        return true;
      }
    }
    await sleep(250);
  }
  return false;
}

function findTextDropdownTriggerInSection(sectionTitle, labelText, optionText) {
  const knownValues = knownValuesForLabel(labelText, optionText);
  const label = findSectionLabelElement(sectionTitle, labelText);
  const valueElements = sectionElements(sectionTitle, "div, span, input")
    .filter((element) => {
      const text = normalizeKnownSelectValue(element.textContent || element.getAttribute("value") || element.getAttribute("placeholder"));
      return text && knownValues.includes(text);
    })
    .sort((left, right) => {
      if (label) {
        const labelRect = label.getBoundingClientRect();
        const leftRect = left.getBoundingClientRect();
        const rightRect = right.getBoundingClientRect();
        return Math.abs(leftRect.top - labelRect.top) + Math.abs(leftRect.left - labelRect.left) -
          (Math.abs(rightRect.top - labelRect.top) + Math.abs(rightRect.left - labelRect.left));
      }
      return left.getBoundingClientRect().top - right.getBoundingClientRect().top;
    });
  const target = valueElements[0] ?? label;
  if (!target) {
    return null;
  }
  return target.closest(".xt-select, [class*='select'], [class*='Select'], [class*='dropdown'], [class*='Dropdown']") ??
    target.parentElement ??
    target;
}

function findSectionLabelElement(sectionTitle, labelText) {
  const normalizedLabel = normalizeLine(labelText);
  return sectionElements(sectionTitle, "div, span, label, input")
    .filter((element) => normalizeLine(element.textContent || element.getAttribute("placeholder") || "").includes(normalizedLabel))
    .sort((left, right) => left.getBoundingClientRect().top - right.getBoundingClientRect().top ||
      left.getBoundingClientRect().left - right.getBoundingClientRect().left)[0] ?? null;
}

function knownValuesForLabel(labelText, optionText) {
  if (isDataRangeValue(optionText) || normalizeLine(labelText).includes("数据范围")) {
    return ["近90天", "近30天", "近7天"];
  }
  if (isEstimateVideoTypeValue(optionText) || normalizeLine(labelText).includes("视频类型")) {
    return ["1-20s视频", "20-60s视频", "60s以上视频", "图文", "个人视频", "星图视频"];
  }
  return [optionText].filter(Boolean);
}

function currentKnownValueFromTrigger(trigger) {
  return normalizeKnownSelectValue(trigger?.textContent || trigger?.getAttribute?.("value") || "");
}

function currentSectionFilterValue(sectionTitle, labelText) {
  if (normalizeLine(labelText).includes("数据范围")) {
    return currentDataRangeForSection(sectionTitle) || currentDataRangeFromText(sectionTitle);
  }
  if (normalizeLine(labelText).includes("视频类型")) {
    return currentSelectValue(findSectionSelect(sectionTitle, labelText)) || currentVideoTypeFromText(sectionTitle);
  }
  return "";
}

function sectionElements(sectionTitle, selector) {
  const bounds = findSectionBounds(sectionTitle);
  if (!bounds) {
    return [];
  }
  return Array.from(document.querySelectorAll(selector))
    .filter((element) => {
      const rect = element.getBoundingClientRect();
      return isActuallyVisible(element) && rect.top >= bounds.top && rect.top < bounds.bottom;
    });
}

function findSectionBounds(sectionTitle) {
  const title = findBusinessSectionTitle(sectionTitle);
  if (!title) {
    return null;
  }
  const titleRect = title.getBoundingClientRect();
  const nextTop = findNextSectionTop(sectionTitle, titleRect.top);
  return {
    top: titleRect.top - 80,
    titleTop: titleRect.top,
    bottom: Number.isFinite(nextTop) ? nextTop - 8 : nextTop
  };
}

function findNextSectionTop(sectionTitle, currentTop) {
  const sectionTitles = ["内容数据", "性价比/效果预估", "种草价值", "转化价值", "传播价值"];
  const tops = sectionTitles
    .filter((title) => title !== sectionTitle)
    .map((title) => findBusinessSectionTitle(title))
    .filter(Boolean)
    .map((element) => element.getBoundingClientRect().top)
    .filter((top) => top > currentTop + 20)
    .sort((left, right) => left - right);
  return tops[0] ?? Number.POSITIVE_INFINITY;
}

function sectionTextLinesForTitle(sectionTitle) {
  const lines = (document.body?.innerText ?? "").split(/\n+/).map((line) => line.trim()).filter(Boolean);
  const stops = {
    内容数据: ["性价比/效果预估", "种草价值", "转化价值"],
    "性价比/效果预估": ["优秀传播视频", "种草价值", "转化价值"],
    种草价值: ["优秀种草视频", "转化价值"]
  };
  return sectionLines(lines, sectionTitle, stops[sectionTitle] ?? []);
}

function visibleSectionTextLines(sectionTitle) {
  const sectionCard = findVisibleSectionCard(sectionTitle);
  if (sectionCard) {
    const lines = (sectionCard.innerText || sectionCard.textContent || "")
      .split(/\n+/)
      .map((line) => line.trim())
      .filter(Boolean);
    if (lines.length) {
      return lines;
    }
  }

  const bounds = findSectionBounds(sectionTitle);
  if (!bounds) {
    return null;
  }
  const entries = Array.from(document.querySelectorAll("div, span, p, label, button, strong, b, input"))
    .map((element) => {
      const rect = element.getBoundingClientRect();
      const rawText = element.tagName === "INPUT"
        ? (element.value || element.getAttribute("value") || element.getAttribute("placeholder") || "")
        : (element.innerText || element.textContent || "");
      const text = String(rawText).split(/\n+/).map((line) => line.trim()).filter(Boolean).join("\n");
      return { element, rect, text };
    })
    .filter(({ element, rect, text }) => (
      text &&
      normalizeLine(text).length <= 80 &&
      isActuallyVisible(element) &&
      rect.top >= bounds.top &&
      rect.top < bounds.bottom
    ))
    .filter(({ element, text }) => {
      const normalizedText = normalizeLine(text);
      const visibleChildTexts = Array.from(element.children || [])
        .filter((child) => isActuallyVisible(child))
        .map((child) => normalizeLine(child.innerText || child.textContent || ""))
        .filter(Boolean);
      return !visibleChildTexts.some((childText) => childText !== normalizedText && normalizedText.includes(childText));
    })
    .sort((left, right) => {
      const topDiff = left.rect.top - right.rect.top;
      return Math.abs(topDiff) < 4 ? left.rect.left - right.rect.left : topDiff;
    });
  const lines = [];
  for (const entry of entries) {
    for (const line of entry.text.split(/\n+/).map((item) => item.trim()).filter(Boolean)) {
      if (lines[lines.length - 1] !== line) {
        lines.push(line);
      }
    }
  }
  return lines.length ? lines : null;
}

function findVisibleSectionCard(sectionTitle) {
  const normalizedTitle = normalizeLine(sectionTitle);
  const titleElements = findVisibleElementsByText(sectionTitle);
  const cards = [];
  for (const titleElement of titleElements) {
    let current = titleElement;
    while (current && current !== document.body) {
      const rect = current.getBoundingClientRect();
      const text = current.innerText || current.textContent || "";
      const className = String(current.className || "");
      const isCard = className.includes("xt-card") ||
        (rect.width >= 500 && rect.height >= 180 && normalizeLine(text).includes(normalizedTitle));
      if (isCard && rect.left > 240 && isActuallyVisible(current)) {
        cards.push(current);
        break;
      }
      current = current.parentElement;
    }
  }
  return cards
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      return leftRect.top - rightRect.top || leftRect.left - rightRect.left || (leftRect.width * leftRect.height) - (rightRect.width * rightRect.height);
    })[0] || null;
}

function currentDataRangeFromText(sectionTitle) {
  const lines = sectionTextLinesForTitle(sectionTitle);
  const index = lines.findIndex((line) => normalizeLine(line).includes("数据范围"));
  if (index < 0) {
    return "";
  }
  const sameLine = lines[index].match(/近\s*(?:30|90|7)\s*天/);
  if (sameLine) {
    return normalizeDataRange(sameLine[0]);
  }
  const nextLine = lines.slice(index + 1, index + 4).find((line) => /近\s*(?:30|90|7)\s*天/.test(line));
  return normalizeDataRange(nextLine);
}

function currentVideoTypeFromText(sectionTitle) {
  const lines = sectionTextLinesForTitle(sectionTitle);
  const index = lines.findIndex((line) => normalizeLine(line).includes("视频类型"));
  if (index < 0) {
    return "";
  }
  const nearby = lines.slice(index, index + 4).join(" ");
  const estimateVideoType = normalizeEstimateVideoType(nearby);
  if (isEstimateVideoTypeValue(estimateVideoType)) {
    return estimateVideoType;
  }
  const contentVideoType = normalizeContentVideoType(nearby);
  return isContentVideoTypeValue(contentVideoType) ? contentVideoType : "";
}

function sectionTextIncludes(sectionTitle, text) {
  if (!text) {
    return false;
  }
  return sectionTextLinesForTitle(sectionTitle).some((line) => normalizeLine(line).includes(normalizeLine(text)));
}

async function assertBusinessFilterState(filters) {
  const errors = [];
  scrollToBusinessAbilityTop();
  await sleep(250);
  const contentDataRangeSelect = findContentDataRangeSelect();
  const contentDataRange = currentSelectValue(contentDataRangeSelect);
  const contentVideoType = !filters.contentVideoType ||
    currentCheckboxButtonValue("内容数据", filters.contentVideoType) === true;
  if (filters.contentDataRange && contentDataRange !== filters.contentDataRange) {
    errors.push(`内容数据-数据范围未切到${filters.contentDataRange}（当前${contentDataRange || "未读取到"}）`);
  }
  if (filters.contentVideoType && !contentVideoType) {
    errors.push(`内容数据-视频类型未切到${filters.contentVideoType}`);
  }
  const onlyAssigned = currentCheckboxValue("内容数据", "只看指派");
  if (filters.onlyAssigned !== null && onlyAssigned !== null && onlyAssigned !== filters.onlyAssigned) {
    errors.push(`内容数据-只看指派未切到${filters.onlyAssigned ? "选中" : "未选中"}`);
  }
  const contentExcludeMarketing = currentCheckboxValue("内容数据", "排除营销流量");
  if (filters.contentExcludeMarketing !== null && contentExcludeMarketing !== null && contentExcludeMarketing !== filters.contentExcludeMarketing) {
    errors.push(`内容数据-排除营销流量未切到${filters.contentExcludeMarketing ? "选中" : "未选中"}`);
  }

  scrollToBusinessSection("性价比/效果预估");
  await sleep(200);
  const estimateVideoType = currentSelectValue(findEstimateVideoTypeSelect());
  if (filters.estimateVideoType && estimateVideoType !== filters.estimateVideoType) {
    errors.push(`性价比/效果预估-视频类型未切到${filters.estimateVideoType}（当前${estimateVideoType || "未读取到"}）`);
  }
  const estimateExcludeMarketing = currentCheckboxValue("性价比/效果预估", "排除营销流量");
  if (filters.estimateExcludeMarketing !== null && estimateExcludeMarketing !== null && estimateExcludeMarketing !== filters.estimateExcludeMarketing) {
    errors.push(`性价比/效果预估-排除营销流量未切到${filters.estimateExcludeMarketing ? "选中" : "未选中"}`);
  }

  scrollToBusinessSection("种草价值");
  await sleep(250);
  const plantingDataRange = currentSelectValue(findPlantingDataRangeSelect());
  if (filters.plantingDataRange && plantingDataRange !== filters.plantingDataRange) {
    errors.push(`种草价值-数据范围未切到${filters.plantingDataRange}（当前${plantingDataRange || "未读取到"}）`);
  }
  if (errors.length) {
    throw new Error(`星图筛选未生效：${errors.join("；")}`);
  }
  scrollToBusinessAbilityTop();
}

async function chooseSelectOption(select, optionText) {
  if (!select || currentSelectValue(select) === optionText) {
    return false;
  }
  const originalRect = select.getBoundingClientRect();
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const clickTarget = select.querySelector(".xt-select__input, .xt-select__label, input") ?? select;
    clickElement(clickTarget);
    await sleep(350);
    const option = findDropdownOption(optionText);
    if (option) {
      clickPopupOption(option.closest?.(".xt-option") ?? option);
      await waitUntil(() => {
        const currentSelect = select.isConnected ? select : findNearestSelect(originalRect);
        return currentSelectValue(currentSelect) === optionText;
      }, 2500);
      const currentSelect = select.isConnected ? select : findNearestSelect(originalRect);
      if (currentSelectValue(currentSelect) === optionText) {
        return true;
      }
    }
    await sleep(250);
  }
  return false;
}

function findNearestSelect(rect) {
  const selects = Array.from(document.querySelectorAll(".xt-select"))
    .filter((element) => isVisible(element))
    .map((element) => {
      const candidateRect = element.getBoundingClientRect();
      return {
        element,
        distance: Math.abs(candidateRect.top - rect.top) + Math.abs(candidateRect.left - rect.left)
      };
    })
    .sort((left, right) => left.distance - right.distance);
  return selects[0]?.element ?? null;
}

function findDropdownOption(optionText) {
  const preferredSelectors = [
    ".xt-option",
    ".xt-option__content",
    ".xt-select-dropdown__item",
    ".xt-select-option",
    "[role='option']",
    "li"
  ];
  const exactText = normalizeLine(optionText);
  const preferred = preferredSelectors.flatMap((selector) => Array.from(document.querySelectorAll(selector)))
    .filter((element, index, items) => items.indexOf(element) === index)
    .filter((element) => isVisible(element) && normalizeLine(element.textContent) === exactText);
  const genericPopup = Array.from(document.querySelectorAll("div, span"))
    .filter((element) => isVisible(element) && isPopupElement(element) && normalizeLine(element.textContent) === exactText);
  const options = [...preferred, ...genericPopup]
    .filter((element, index, items) => items.indexOf(element) === index);
  return options
    .sort((left, right) => {
      const leftPopup = isPopupElement(left) ? 0 : 1;
      const rightPopup = isPopupElement(right) ? 0 : 1;
      return leftPopup - rightPopup ||
        getElementDepth(left) - getElementDepth(right);
    })[0] ?? null;
}

function isPopupElement(element) {
  return Boolean(element.closest(".xt-select-dropdown, .xt-popover, [role='listbox']"));
}

function getElementDepth(element) {
  let depth = 0;
  let current = element;
  while (current?.parentElement) {
    depth += 1;
    current = current.parentElement;
  }
  return depth;
}

function isControlChecked(label) {
  if (label.classList.contains("is-checked")) {
    return true;
  }
  const input = label.querySelector("input");
  return Boolean(input?.checked);
}

function isControlDisabled(label) {
  return label.classList.contains("is-disabled") ||
    label.getAttribute("aria-disabled") === "true" ||
    Boolean(label.querySelector("input")?.disabled);
}

function currentSelectValue(select) {
  if (!select) {
    return "";
  }
  const label = Array.from(select.querySelectorAll(".xt-select__label, .xt-select__selection, .xt-select__selected"))
    .find((element) => isVisible(element) && normalizeLine(element.innerText || element.textContent));
  const input = Array.from(select.querySelectorAll("input"))
    .find((element) => isVisible(element) && (element.value || element.getAttribute("value") || element.getAttribute("placeholder")));
  const rawValue = label
    ? (label.innerText || label.textContent)
    : (input?.value || input?.getAttribute("value") || input?.getAttribute("placeholder") || "");
  return normalizeKnownSelectValue(rawValue) || normalizeKnownSelectValue(select.textContent) || String(rawValue || "").trim();
}

function currentContentVideoTypeFromControls() {
  const starButton = findSectionCheckboxButton("内容数据", "星图视频");
  if (starButton && isControlChecked(starButton)) {
    return "星图视频";
  }
  const personalButton = findSectionCheckboxButton("内容数据", "个人视频");
  if (personalButton && isControlChecked(personalButton)) {
    return "个人视频";
  }
  return "";
}

function normalizeKnownSelectValue(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return "";
  }
  const dataRange = normalizeDataRange(text);
  if (isDataRangeValue(dataRange)) {
    return dataRange;
  }
  const estimateVideoType = normalizeEstimateVideoType(text);
  if (isEstimateVideoTypeValue(estimateVideoType)) {
    return estimateVideoType;
  }
  const contentVideoType = normalizeContentVideoType(text);
  if (isContentVideoTypeValue(contentVideoType)) {
    return contentVideoType;
  }
  return "";
}

function sameSelectFamily(left, right) {
  return (isDataRangeValue(left) && isDataRangeValue(right)) ||
    (isEstimateVideoTypeValue(left) && isEstimateVideoTypeValue(right)) ||
    (isContentVideoTypeValue(left) && isContentVideoTypeValue(right));
}

function isDataRangeValue(value) {
  return ["近90天", "近30天", "近7天"].includes(value);
}

function isEstimateVideoTypeValue(value) {
  return ["1-20s视频", "20-60s视频", "60s以上视频", "图文"].includes(value);
}

function isContentVideoTypeValue(value) {
  return ["个人视频", "星图视频"].includes(value);
}

function visibleLabels(text) {
  return Array.from(document.querySelectorAll("label"))
    .filter((label) => isVisible(label) && label.textContent?.trim().replace(/\s+/g, "") === text);
}

function isVisible(element) {
  const rect = element.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function isActuallyVisible(element) {
  if (!element || !isVisible(element)) {
    return false;
  }
  let current = element;
  while (current && current !== document.body) {
    const style = getComputedStyle(current);
    if (style.display === "none" ||
        style.visibility === "hidden" ||
        Number(style.opacity) === 0 ||
        current.getAttribute("aria-hidden") === "true") {
      return false;
    }
    current = current.parentElement;
  }
  return true;
}

function isInViewport(element) {
  const rect = element.getBoundingClientRect();
  const width = window.innerWidth || document.documentElement.clientWidth || 0;
  const height = window.innerHeight || document.documentElement.clientHeight || 0;
  return rect.bottom > 0 && rect.right > 0 && rect.top < height && rect.left < width;
}

function parseBooleanOption(value) {
  if (value === null || value === undefined || String(value).trim() === "") {
    return null;
  }
  const text = String(value).trim().toLowerCase();
  if (["1", "true", "yes", "y", "是", "勾选", "选中", "开启", "打开"].includes(text)) {
    return true;
  }
  if (["0", "false", "no", "n", "否", "不勾选", "未选中", "关闭"].includes(text)) {
    return false;
  }
  return null;
}

function normalizeDataRange(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return "";
  }
  const explicit = text.match(/近\s*(90|30|7)\s*天/);
  const loose = explicit ?? text.match(/(?:^|\D)(90|30|7)(?:\D|$)/);
  if (loose?.[1]) {
    return `近${loose[1]}天`;
  }
  return text;
}

function normalizeContentVideoType(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return null;
  }
  if (/个人/.test(text)) {
    return "个人视频";
  }
  if (/星图/.test(text)) {
    return "星图视频";
  }
  return null;
}

function normalizeEstimateVideoType(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return "";
  }
  if (/1\s*[-~至到]\s*20|1-20|20s?以内/i.test(text)) {
    return "1-20s视频";
  }
  if (/21\s*[-~至到]\s*60|20\s*[-~至到]\s*60|21-60|20-60/i.test(text)) {
    return "20-60s视频";
  }
  if (/60.*以上|60\+|大于60/i.test(text)) {
    return "60s以上视频";
  }
  if (/图文/.test(text)) {
    return "图文";
  }
  return text;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function withTimeout(promise, timeoutMs, message) {
  let timeoutId;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error(message)), timeoutMs);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timeoutId));
}

function waitForText(text, timeoutMs) {
  const startedAt = Date.now();
  return new Promise((resolve) => {
    const tick = () => {
      if ((document.body?.innerText ?? "").includes(text)) {
        resolve(true);
        return;
      }
      if (Date.now() - startedAt >= timeoutMs) {
        resolve(false);
        return;
      }
      setTimeout(tick, 150);
    };
    tick();
  });
}

function waitForAnyText(texts, timeoutMs) {
  const expected = texts.filter(Boolean);
  const startedAt = Date.now();
  return new Promise((resolve) => {
    const tick = () => {
      const bodyText = document.body?.innerText ?? "";
      if (expected.some((text) => bodyText.includes(text))) {
        resolve(true);
        return;
      }
      if (Date.now() - startedAt >= timeoutMs) {
        resolve(false);
        return;
      }
      setTimeout(tick, 150);
    };
    tick();
  });
}

function waitUntil(predicate, timeoutMs) {
  const startedAt = Date.now();
  return new Promise((resolve) => {
    const tick = () => {
      if (predicate()) {
        resolve(true);
        return;
      }
      if (Date.now() - startedAt >= timeoutMs) {
        resolve(false);
        return;
      }
      setTimeout(tick, 100);
    };
    tick();
  });
}

function waitForPageQuiet(timeoutMs, quietMs) {
  return new Promise((resolve) => {
    let quietTimer = null;
    const startedAt = Date.now();
    const observer = new MutationObserver(() => {
      clearTimeout(quietTimer);
      quietTimer = setTimeout(done, quietMs);
      if (Date.now() - startedAt >= timeoutMs) {
        done();
      }
    });
    const done = () => {
      clearTimeout(quietTimer);
      observer.disconnect();
      resolve();
    };
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
    quietTimer = setTimeout(done, quietMs);
    setTimeout(done, timeoutMs);
  });
}

function extractLabeledPrice(lines, labelPattern) {
  for (let index = 0; index < lines.length; index += 1) {
    if (!labelPattern.test(lines[index])) {
      continue;
    }
    const nearby = lines.slice(Math.max(0, index - 2), Math.min(lines.length, index + 3));
    const priceLine = nearby.find((line) => /￥\s*[\d,]+/.test(line));
    if (priceLine) {
      return Number(priceLine.replace(/[^\d.]/g, ""));
    }
  }
  return null;
}

function extractFollowingValue(lines, labelPattern) {
  const index = lines.findIndex((line) => labelPattern.test(line));
  if (index < 0) {
    return null;
  }
  return lines[index + 1] || null;
}

function extractVisibleNickname(lines, authorId) {
  const idIndex = lines.findIndex((line) => (
    /星图\s*ID/i.test(line) && (!authorId || line.includes(String(authorId)))
  ));
  if (idIndex < 0) {
    return null;
  }
  const candidates = lines.slice(Math.max(0, idIndex - 5), idIndex)
    .map((line) => line.trim())
    .filter((line) => line &&
      !/主页|达人|通用|短视频|抖音|ID|看后搜|排行榜|月连接|粉丝|展开|推荐/.test(line) &&
      !/^[\d,.]+w?%?$/.test(line));
  return candidates[candidates.length - 1] ?? null;
}

function extractFollowingNumber(lines, labelText) {
  const value = extractFollowingRawValue(lines, labelText, (line) => /[<>]?\s*[\d,.]+w?|[<>]?\s*[\d,.]+%/i.test(line));
  return normalizeVisibleNumber(value);
}

function extractFollowingMetric(lines, labelText) {
  return extractFollowingRawValue(lines, labelText, (line) => {
    const text = String(line ?? "").trim();
    return text && !/^优于/.test(text);
  });
}

function extractSectionNumber(sectionLinesValue, fallbackLines, labelText) {
  const sectionValue = extractFollowingNumber(sectionLinesValue, labelText);
  return sectionValue ?? extractFollowingNumber(fallbackLines, labelText);
}

function extractSectionMetric(sectionLinesValue, fallbackLines, labelText) {
  const sectionValue = extractFollowingMetric(sectionLinesValue, labelText);
  return sectionValue ?? extractFollowingMetric(fallbackLines, labelText);
}

function extractMetricFromStrictSectionLines(sectionLinesValue, labelText) {
  const value = extractFollowingMetric(sectionLinesValue, labelText);
  if (!value) {
    return null;
  }
  const normalizedLabel = normalizeLine(labelText);
  const normalizedValue = normalizeLine(value);
  if (!normalizedValue || normalizedValue === normalizedLabel || /^优于/.test(normalizedValue) || normalizedValue === "同类型达人") {
    return null;
  }
  return value;
}

function extractMetricFromSectionDom(sectionTitle, labelText) {
  const normalizedLabel = normalizeLine(labelText);
  const labels = sectionElements(sectionTitle, "div, span, p, label")
    .filter((element) => normalizeLine(element.textContent) === normalizedLabel)
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      const leftArea = leftRect.width * leftRect.height;
      const rightArea = rightRect.width * rightRect.height;
      return leftArea - rightArea || leftRect.top - rightRect.top || leftRect.left - rightRect.left;
    });
  for (const label of labels) {
    let current = label;
    while (current && current !== document.body) {
      const rect = current.getBoundingClientRect();
      if (rect.width > 80 && rect.height > 20) {
        const lines = (current.innerText || current.textContent || "")
          .split(/\n+/)
          .map((line) => line.trim())
          .filter(Boolean);
        const value = extractFollowingMetric(lines, labelText);
        if (value && normalizeLine(value) !== normalizedLabel && !/^优于/.test(value)) {
          return value;
        }
      }
      const parent = current.parentElement;
      if (!parent) {
        break;
      }
      const parentRect = parent.getBoundingClientRect();
      if (parentRect.height > 260 || parentRect.width > 900) {
        break;
      }
      current = parent;
    }
  }
  return null;
}

function extractSelectedDataRange(sectionLinesValue) {
  const range = extractFollowingRawValue(sectionLinesValue, "数据范围：", isDataRangeValue);
  return range || sectionLinesValue.find(isDataRangeValue) || "";
}

function extractSelectedVideoType(sectionLinesValue, values) {
  const knownValues = values.map(normalizeLine);
  const byLabel = extractFollowingRawValue(sectionLinesValue, "视频类型：", (line) => knownValues.includes(normalizeLine(line)));
  if (byLabel) {
    return byLabel;
  }
  return sectionLinesValue.find((line) => knownValues.includes(normalizeLine(line))) || "";
}

function extractStrictSectionPercent(sectionLinesValue, labelText) {
  return extractFollowingRawValue(sectionLinesValue, labelText, (line) => {
    const text = String(line ?? "").trim();
    return /%/.test(text) && !/^优于/.test(text);
  });
}

function sectionLines(lines, sectionTitle, stopTitles) {
  const startIndex = lines.findIndex((line) => normalizeLine(line) === normalizeLine(sectionTitle));
  if (startIndex < 0) {
    return [];
  }
  const normalizedStops = stopTitles.map(normalizeLine);
  const stopIndex = lines.findIndex((line, index) => (
    index > startIndex && normalizedStops.includes(normalizeLine(line))
  ));
  return lines.slice(startIndex, stopIndex < 0 ? undefined : stopIndex);
}

function extractFollowingRawValue(lines, labelText, predicate) {
  const normalizedLabel = normalizeLine(labelText);
  let index = lines.findIndex((line) => normalizeLine(line) === normalizedLabel);
  if (index < 0) {
    index = lines.findIndex((line) => {
      const sameLine = stripMetricLabel(line, labelText);
      return sameLine !== String(line ?? "").trim() && sameLine && predicate(sameLine);
    });
  }
  if (index < 0) {
    return null;
  }

  const sameLine = stripMetricLabel(lines[index], labelText);
  if (sameLine && predicate(sameLine)) {
    return sameLine;
  }

  const value = lines.slice(index + 1, index + 8).find(predicate);
  return value ?? null;
}

function stripMetricLabel(line, labelText) {
  const escapedLabel = escapeRegExp(labelText);
  return String(line ?? "").replace(new RegExp(`^\\s*${escapedLabel}\\s*[:：]?\\s*`, "i"), "").trim();
}

function normalizeLine(value) {
  return String(value ?? "").replace(/\s+/g, "").trim().toLowerCase();
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function normalizeVisibleNumber(value) {
  if (!value) {
    return null;
  }
  const text = String(value).replace(/,/g, "").trim();
  const match = text.match(/[\d.]+/);
  if (!match) {
    return null;
  }
  const number = Number(match[0]);
  if (!Number.isFinite(number)) {
    return null;
  }
  if (/w/i.test(text)) {
    return number * 10000;
  }
  if (text.includes("%")) {
    return `${number}%`;
  }
  return number;
}

const PUBLISHED_WORK_ID_KEYS = [
  "aweme_id",
  "aweme_id_str",
  "awemeId",
  "awemeIdStr",
  "item_id",
  "item_id_str",
  "itemId",
  "itemIdStr",
  "video_id",
  "video_id_str",
  "videoId",
  "videoIdStr",
  "group_id",
  "group_id_str",
  "groupId",
  "groupIdStr",
  "object_id",
  "object_id_str",
  "id",
  "id_str"
];

const PUBLISHED_WORK_URL_KEYS = [
  "share_url",
  "shareUrl",
  "video_url",
  "videoUrl",
  "item_url",
  "itemUrl",
  "aweme_url",
  "awemeUrl",
  "detail_url",
  "detailUrl",
  "url",
  "href"
];

const PUBLISHED_WORK_PLAY_KEYS = [
  "play_count",
  "playCount",
  "play_count_str",
  "play_cnt",
  "playCnt",
  "play_cnt_str",
  "play_num",
  "playNum",
  "play_num_str",
  "playNumStr",
  "vv",
  "vv_count",
  "vvCount",
  "vv_cnt",
  "vvCnt",
  "vv_num",
  "vvNum",
  "video_play_count",
  "videoPlayCount",
  "video_play_cnt",
  "videoPlayCnt",
  "item_play_count",
  "itemPlayCount",
  "item_play_cnt",
  "itemPlayCnt",
  "aweme_play_count",
  "awemePlayCount",
  "aweme_play_cnt",
  "awemePlayCnt",
  "watch_cnt",
  "watchCnt",
  "watch_count",
  "watchCount",
  "view_count",
  "viewCount",
  "view_cnt",
  "viewCnt",
  "view_num",
  "viewNum",
  "read_count",
  "readCount",
  "read_cnt",
  "readCnt",
  "read_num",
  "readNum",
  "show_count",
  "showCount",
  "show_cnt",
  "showCnt",
  "show_num",
  "showNum",
  "display_count",
  "displayCount",
  "display_cnt",
  "displayCnt"
];

const PUBLISHED_WORK_LIKE_KEYS = [
  "digg_count",
  "diggCount",
  "digg_count_str",
  "digg_cnt",
  "diggCnt",
  "like_count",
  "likeCount",
  "like_count_str",
  "like_cnt",
  "likeCnt",
  "praise_count",
  "praiseCount",
  "praise_cnt",
  "praiseCnt",
  "digg",
  "like",
  "likes"
];

const PUBLISHED_WORK_COMMENT_KEYS = [
  "comment_count",
  "commentCount",
  "comment_count_str",
  "comment_cnt",
  "commentCnt",
  "comments_count",
  "commentsCount",
  "comment",
  "comments"
];

const PUBLISHED_WORK_SHARE_KEYS = [
  "share_count",
  "shareCount",
  "share_count_str",
  "share_count_all",
  "shareCountAll",
  "share_cnt",
  "shareCnt",
  "share_cnt_td",
  "shareCntTd",
  "share_cnt_all",
  "shareCntAll",
  "share_cnt_total",
  "shareCntTotal",
  "total_share_cnt",
  "totalShareCnt",
  "repost_count",
  "repostCount",
  "repost_count_all",
  "repostCountAll",
  "forward_count",
  "forwardCount",
  "forward_count_all",
  "forwardCountAll",
  "forward_cnt",
  "forwardCnt",
  "forward_cnt_all",
  "forwardCntAll",
  "share",
  "shares"
];

const PUBLISHED_WORK_TITLE_KEYS = [
  "title",
  "item_title",
  "itemTitle",
  "desc",
  "description",
  "text"
];

function matchPublishedWork(bundle, publishUrl) {
  const awemeId = extractAwemeId(publishUrl);
  if (!awemeId) {
    return null;
  }

  const candidates = [
    ...collectObjects(bundle.authorShow),
    ...collectObjects(bundle.homepageVideos),
    ...collectObjects(bundle.starHomepageVideos),
    ...collectObjects(bundle.itemReportDetail),
    ...collectObjects(bundle.itemReportTrend),
    ...collectObjects(bundle.videoCard),
    ...collectObjects(bundle.douyinItemInfo),
    ...collectObjects(bundle.douyinAwemeDetail)
  ].filter((item) => isPublishedWorkMatch(item, awemeId));

  const ranked = candidates
    .map((item) => normalizePublishedWorkCandidate(item, awemeId))
    .sort((left, right) => scorePublishedWorkCandidate(right) - scorePublishedWorkCandidate(left));

  return ranked[0] ?? null;
}

function enrichPublishedWorkCandidateWithBundle(note, bundle, publishUrl) {
  const awemeId = extractAwemeId(publishUrl) || note?.awemeId || "";
  const enrichedSource = {
    ...(note ?? {}),
    xingtuItemReportDetail: bundle?.itemReportDetail,
    xingtuItemReportTrend: bundle?.itemReportTrend,
    xingtuVideoCard: bundle?.videoCard
  };
  if (!awemeId) {
    return note;
  }
  const normalized = normalizePublishedWorkCandidate(enrichedSource, awemeId);
  return hasPublishedWorkStats(normalized) ? normalized : note;
}

function needsPublishedWorkPageFallback(noteFields = [], note = null) {
  const requestedMetricGroups = noteFields
    .map((field) => {
      const normalized = normalizeLine(field);
      if (["播放量", "阅读量", "曝光量"].some((name) => normalized === normalizeLine(name))) {
        return PUBLISHED_WORK_PLAY_KEYS;
      }
      if (["点赞", "点赞量"].some((name) => normalized === normalizeLine(name))) {
        return PUBLISHED_WORK_LIKE_KEYS;
      }
      if (["评论", "评论量"].some((name) => normalized === normalizeLine(name))) {
        return PUBLISHED_WORK_COMMENT_KEYS;
      }
      if (["分享", "分享量", "转发", "转发量"].some((name) => normalized === normalizeLine(name))) {
        return PUBLISHED_WORK_SHARE_KEYS;
      }
      return null;
    })
    .filter(Boolean);
  return requestedMetricGroups.some((keys) => !hasUsefulPublishedWorkValue(note, keys));
}

function hasUsefulPublishedWorkValue(item, keys) {
  const value = pickDeepValue(item, keys);
  return value !== null && value !== undefined && String(value).trim() !== "";
}

function mergePublishedWorkCandidates(primary, fallback, publishUrl) {
  const awemeId = extractAwemeId(publishUrl) || primary?.awemeId || fallback?.awemeId || "";
  if (!primary && !fallback) {
    return null;
  }
  if (!primary) {
    return normalizePublishedWorkCandidate(fallback, awemeId);
  }
  if (!fallback) {
    return normalizePublishedWorkCandidate(primary, awemeId);
  }
  const merged = {
    ...fallback,
    ...primary
  };
  const playCount = firstNonEmpty(
    pickDeepValue(primary, PUBLISHED_WORK_PLAY_KEYS),
    pickDeepValue(fallback, PUBLISHED_WORK_PLAY_KEYS)
  );
  const likeCount = firstNonEmpty(
    pickDeepValue(primary, PUBLISHED_WORK_LIKE_KEYS),
    pickDeepValue(fallback, PUBLISHED_WORK_LIKE_KEYS)
  );
  const commentCount = firstNonEmpty(
    pickDeepValue(primary, PUBLISHED_WORK_COMMENT_KEYS),
    pickDeepValue(fallback, PUBLISHED_WORK_COMMENT_KEYS)
  );
  const shareCount = firstNonEmpty(
    pickDeepValue(primary, PUBLISHED_WORK_SHARE_KEYS),
    pickDeepValue(fallback, PUBLISHED_WORK_SHARE_KEYS)
  );
  return normalizePublishedWorkCandidate({
    ...merged,
    play_count: playCount,
    watch_cnt: playCount,
    digg_count: likeCount,
    like_cnt: likeCount,
    comment_count: commentCount,
    comment_cnt: commentCount,
    share_count: shareCount,
    share_cnt: shareCount
  }, awemeId);
}

function isPublishedWorkMatch(item, awemeId) {
  if (!item || typeof item !== "object") {
    return false;
  }
  if (directPublishedWorkIdentityMatches(item, awemeId)) {
    return true;
  }
  if (isLikelyCollectionObject(item)) {
    return false;
  }
  return deepPublishedWorkIdentityMatches(item, awemeId) && hasPublishedWorkStats(item);
}

function directPublishedWorkIdentityMatches(item, awemeId) {
  const directId = pickValue(item, PUBLISHED_WORK_ID_KEYS);
  if (String(directId ?? "") === awemeId) {
    return true;
  }
  const directUrl = pickValue(item, PUBLISHED_WORK_URL_KEYS);
  return urlContainsAwemeId(directUrl, awemeId);
}

function deepPublishedWorkIdentityMatches(item, awemeId) {
  const deepId = pickDeepValue(item, PUBLISHED_WORK_ID_KEYS);
  if (String(deepId ?? "") === awemeId) {
    return true;
  }
  const deepUrl = pickDeepValue(item, PUBLISHED_WORK_URL_KEYS);
  return urlContainsAwemeId(deepUrl, awemeId);
}

function urlContainsAwemeId(value, awemeId) {
  return Boolean(value && awemeId && String(value).includes(String(awemeId)));
}

function isLikelyCollectionObject(item) {
  return Object.values(item).some((value) => (
    Array.isArray(value) &&
    value.length > 1 &&
    value.some((child) => child && typeof child === "object")
  ));
}

function hasPublishedWorkStats(item) {
  return Boolean(
    pickDeepValue(item, PUBLISHED_WORK_PLAY_KEYS) ||
    pickDeepValue(item, PUBLISHED_WORK_LIKE_KEYS) ||
    pickDeepValue(item, PUBLISHED_WORK_COMMENT_KEYS) ||
    pickDeepValue(item, PUBLISHED_WORK_SHARE_KEYS)
  );
}

function normalizePublishedWorkCandidate(item, awemeId) {
  const matchedId = firstNonEmpty(
    pickDeepValue(item, PUBLISHED_WORK_ID_KEYS),
    awemeId
  );
  const matchedUrl = firstNonEmpty(
    pickDeepValue(item, PUBLISHED_WORK_URL_KEYS),
    buildDouyinVideoUrl(awemeId)
  );
  const playCount = pickDeepValue(item, PUBLISHED_WORK_PLAY_KEYS);
  const likeCount = pickDeepValue(item, PUBLISHED_WORK_LIKE_KEYS);
  const commentCount = pickDeepValue(item, PUBLISHED_WORK_COMMENT_KEYS);
  const shareCount = pickDeepValue(item, PUBLISHED_WORK_SHARE_KEYS);

  return {
    ...item,
    awemeId,
    aweme_id: matchedId,
    item_id: firstNonEmpty(pickDeepValue(item, ["item_id", "item_id_str", "itemId", "itemIdStr"]), matchedId),
    video_id: firstNonEmpty(pickDeepValue(item, ["video_id", "video_id_str", "videoId", "videoIdStr"]), matchedId),
    share_url: matchedUrl,
    url: matchedUrl,
    title: firstNonEmpty(pickDeepValue(item, PUBLISHED_WORK_TITLE_KEYS), item.title),
    play_count: playCount,
    watch_cnt: playCount,
    digg_count: likeCount,
    like_cnt: likeCount,
    comment_count: commentCount,
    comment_cnt: commentCount,
    share_count: shareCount,
    share_cnt: shareCount,
    matchConfidence: directPublishedWorkIdentityMatches(item, awemeId) ? 1 : 0.85
  };
}

function scorePublishedWorkCandidate(item) {
  let score = 0;
  if (directPublishedWorkIdentityMatches(item, item.awemeId)) {
    score += 20;
  }
  if (pickDeepValue(item, PUBLISHED_WORK_PLAY_KEYS)) {
    score += 10;
  }
  if (pickDeepValue(item, PUBLISHED_WORK_LIKE_KEYS)) {
    score += 6;
  }
  if (pickDeepValue(item, PUBLISHED_WORK_COMMENT_KEYS)) {
    score += 4;
  }
  if (pickDeepValue(item, PUBLISHED_WORK_SHARE_KEYS)) {
    score += 3;
  }
  if (pickDeepValue(item, PUBLISHED_WORK_TITLE_KEYS)) {
    score += 2;
  }
  if (pickDeepValue(item, PUBLISHED_WORK_URL_KEYS)) {
    score += 1;
  }
  return score;
}

async function matchPublishedWorkFromCreationAbilityPage(publishUrl, knownNote = null) {
  const awemeId = extractAwemeId(publishUrl);
  if (!awemeId) {
    return null;
  }
  const titleHint = normalizePublishedWorkTitle(firstNonEmpty(
    knownNote?.title,
    pickDeepValue(knownNote, PUBLISHED_WORK_TITLE_KEYS)
  ));
  const metricHint = buildPublishedWorkMetricHint(knownNote);
  if (!await openCreationAbilityPanel()) {
    return null;
  }

  for (let page = 0; page < 10; page += 1) {
    await waitForText("播放量", 3000);
    const matched = collectVisibleCreationWorks(awemeId, titleHint, metricHint)[0];
    if (matched) {
      return matched;
    }
    const next = findCreationNextPageButton();
    if (!next || isControlDisabled(next)) {
      break;
    }
    await clickElementTrusted(next);
    await waitForPageQuiet(5000, 800);
  }
  return null;
}

function collectVisibleCreationWorks(awemeId, titleHint = "", metricHint = {}) {
  const roots = Array.from(document.querySelectorAll("a, div, li, section, article"))
    .filter((element) => isVisible(element))
    .filter((element) => {
      const text = element.innerText || element.textContent || "";
      return text.includes("播放量") && text.includes("点赞量") && text.includes("评论量") &&
        !text.includes("结果概览") && elementMatchesPublishedWork(element, awemeId, titleHint, metricHint);
    })
    .sort((left, right) => {
      const leftArea = left.getBoundingClientRect().width * left.getBoundingClientRect().height;
      const rightArea = right.getBoundingClientRect().width * right.getBoundingClientRect().height;
      return leftArea - rightArea;
    });

  return roots.map((root) => {
    const text = root.innerText || root.textContent || "";
    return {
      awemeId,
      matchConfidence: 1,
      title: extractCreationTitle(text),
      share_url: findElementHrefWithText(root, awemeId) || buildDouyinVideoUrl(awemeId),
      play_count: normalizeVisibleNumber(extractMetricText(text, "播放量")),
      digg_count: normalizeVisibleNumber(extractMetricText(text, "点赞量")),
      comment_count: normalizeVisibleNumber(extractMetricText(text, "评论量")),
      share_count: normalizeVisibleNumber(extractMetricText(text, "转发量") || extractMetricText(text, "分享量"))
    };
  });
}

function elementMatchesPublishedWork(element, awemeId, titleHint = "", metricHint = {}) {
  if (elementContainsTextOrAttr(element, awemeId)) {
    return true;
  }
  if (titleHint) {
    const text = normalizePublishedWorkTitle(element.innerText || element.textContent || "");
    if (text.includes(titleHint) || titleHint.includes(text.slice(0, Math.min(18, text.length)))) {
      return true;
    }
  }
  return elementMatchesPublishedWorkMetrics(element, metricHint);
}

function buildPublishedWorkMetricHint(item = null) {
  if (!item || typeof item !== "object") {
    return {};
  }
  return {
    like: normalizeVisibleNumber(pickDeepValue(item, PUBLISHED_WORK_LIKE_KEYS)),
    comment: normalizeVisibleNumber(pickDeepValue(item, PUBLISHED_WORK_COMMENT_KEYS)),
    share: normalizeVisibleNumber(pickDeepValue(item, PUBLISHED_WORK_SHARE_KEYS))
  };
}

function elementMatchesPublishedWorkMetrics(element, metricHint = {}) {
  const hints = [
    ["点赞量", metricHint.like],
    ["评论量", metricHint.comment],
    ["转发量", metricHint.share],
    ["分享量", metricHint.share]
  ].filter(([, value]) => value !== null && value !== undefined && value !== "");
  if (new Set(hints.map(([, value]) => value)).size < 2) {
    return false;
  }

  const text = element.innerText || element.textContent || "";
  const comparisons = [
    [normalizeVisibleNumber(extractMetricText(text, "点赞量")), metricHint.like],
    [normalizeVisibleNumber(extractMetricText(text, "评论量")), metricHint.comment],
    [normalizeVisibleNumber(extractMetricText(text, "转发量") || extractMetricText(text, "分享量")), metricHint.share]
  ].filter(([, expected]) => expected !== null && expected !== undefined && expected !== "");

  return comparisons.filter(([actual, expected]) => metricNumbersClose(actual, expected)).length >= 2;
}

function metricNumbersClose(actual, expected) {
  const left = Number(actual);
  const right = Number(expected);
  if (!Number.isFinite(left) || !Number.isFinite(right)) {
    return false;
  }
  if (left === right) {
    return true;
  }
  const tolerance = Math.max(10, Math.abs(right) * 0.12);
  return Math.abs(left - right) <= tolerance;
}

function elementContainsTextOrAttr(element, needle) {
  if (!needle) {
    return false;
  }
  if ((element.textContent || "").includes(needle)) {
    return true;
  }
  const walker = document.createTreeWalker(element, NodeFilter.SHOW_ELEMENT);
  let current = element;
  while (current) {
    for (const attr of Array.from(current.attributes || [])) {
      if (String(attr.value || "").includes(needle)) {
        return true;
      }
    }
    current = walker.nextNode();
  }
  return false;
}

function findElementHrefWithText(element, text) {
  const link = Array.from(element.querySelectorAll("a[href]")).find((anchor) => anchor.href.includes(text));
  return link?.href ?? "";
}

function extractCreationTitle(text) {
  const lines = String(text ?? "").split(/\n+/).map((line) => line.trim()).filter(Boolean);
  return lines.find((line) => !/播放量|点赞量|评论量|转发量|分享量/.test(line)) ?? "";
}

function normalizePublishedWorkTitle(value) {
  return String(value ?? "")
    .replace(/#[^\s#]+/g, "")
    .replace(/[^\p{L}\p{N}]+/gu, "")
    .trim();
}

function extractMetricText(text, label) {
  const compact = String(text ?? "").replace(/\s+/g, " ");
  const match = compact.match(new RegExp(`${escapeRegExp(label)}\\s*([<>]?[\\d,.]+\\s*w?|[<>]?[\\d,.]+)`, "i"));
  return match?.[1] ?? "";
}

function findCreationNextPageButton() {
  const buttons = Array.from(document.querySelectorAll("button, .xt-pagination-next, [class*='pagination'] [class*='next']"))
    .filter((element) => isVisible(element));
  return buttons.find((element) => /|next|下一页/i.test(element.textContent || element.getAttribute("aria-label") || element.className || "")) ?? null;
}

function extractAwemeId(value) {
  if (!value) {
    return "";
  }

  const text = String(value);
  const patterns = [
    /\/video\/(\d+)/i,
    /\/note\/(\d+)/i,
    /[?&](?:modal_id|aweme_id|item_id|group_id)=([^&#]+)/i
  ];
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      return decodeURIComponent(match[1]);
    }
  }

  const numeric = text.match(/\b\d{12,24}\b/);
  return numeric?.[0] ?? "";
}

function extractDouyinHomeUrlFromPage() {
  const links = Array.from(document.querySelectorAll("a[href]"));
  const exact = links.find((link) => link.textContent?.trim().includes("去达人PC版抖音主页"));
  const douyin = exact ?? links.find((link) => /douyin\.com\/user\//i.test(link.href));
  return douyin?.href ?? "";
}

async function extractDouyinHomeUrlFromPopover() {
  const existing = extractDouyinHomeUrlFromPage();
  if (existing) {
    return existing;
  }

  const triggers = [
    ...Array.from(document.querySelectorAll(".author-qrcode-icon, .author-qrcode-icon *")),
    ...findVisibleElementsByText("通用短视频主页")
  ]
    .map((element) => element.closest?.(".author-qrcode-icon, .author-page-select, .xt-dropdown, .el-popover__reference, .el-dropdown") ?? element)
    .filter((element, index, items) => element && isVisible(element) && items.indexOf(element) === index)
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      return leftRect.top - rightRect.top || leftRect.left - rightRect.left;
    });

  for (const trigger of triggers) {
    hoverElement(trigger);
    await sleep(600);
    const hovered = extractDouyinHomeUrlFromPage();
    if (hovered) {
      return hovered;
    }
    clickElement(trigger);
    await sleep(600);
    const clicked = extractDouyinHomeUrlFromPage();
    if (clicked) {
      return clicked;
    }
  }
  return "";
}

function buildXingtuProfileUrl(authorId) {
  if (!authorId) {
    return "";
  }
  return `https://www.xingtu.cn/ad/creator/author-homepage/douyin-video/${encodeURIComponent(authorId)}`;
}

function buildDouyinVideoUrl(awemeId) {
  if (!awemeId) {
    return "";
  }
  return `https://www.douyin.com/video/${encodeURIComponent(awemeId)}`;
}

async function fetchJson(url, options = {}) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), options.timeoutMs ?? 8000);
  const response = await fetch(url, {
    credentials: "include",
    ...options,
    signal: controller.signal,
    headers: {
      accept: "application/json, text/plain, */*",
      "content-type": "application/json",
      ...(options.headers ?? {})
    }
  }).finally(() => clearTimeout(timeoutId));

  if (!response.ok) {
    throw new Error(`星图请求失败: ${response.status}`);
  }

  const data = await response.json();
  if (data?.status_code && Number(data.status_code) !== 0) {
    throw new Error(data.status_msg || data.message || `星图接口返回异常: ${data.status_code}`);
  }
  if (data?.code && ![0, 200].includes(Number(data.code))) {
    throw new Error(data.msg || data.message || `星图接口返回异常: ${data.code}`);
  }

  return data;
}

async function fetchJsonOptional(url, options = {}) {
  try {
    return await fetchJson(url, options);
  } catch (error) {
    return {
      success: false,
      error: error.message || String(error)
    };
  }
}

async function fetchJsonOptionalFromAttempts(attempts = []) {
  let lastFailure = null;
  for (const [url, options] of attempts) {
    const response = await fetchJsonOptional(url, options);
    if (response && response.success !== false && !response.error) {
      return response;
    }
    lastFailure = response;
  }
  return lastFailure ?? {
    success: false,
    error: "星图接口无可用返回"
  };
}

function collectObjects(value, acc = []) {
  if (!value || acc.length > 1000) {
    return acc;
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      collectObjects(item, acc);
    }
    return acc;
  }
  if (typeof value === "object") {
    acc.push(value);
    for (const item of Object.values(value)) {
      if (item && typeof item === "object") {
        collectObjects(item, acc);
      }
    }
  }
  return acc;
}

function pickValue(source, keys) {
  if (!source || typeof source !== "object") {
    return null;
  }
  for (const key of keys) {
    if (source[key] !== undefined && source[key] !== null && String(source[key]).trim() !== "") {
      return source[key];
    }
  }
  return null;
}

function pickDeepValue(source, keys, seen = new Set()) {
  if (!source || typeof source !== "object" || seen.has(source)) {
    return null;
  }
  seen.add(source);
  const direct = pickValue(source, keys);
  if (direct !== null && direct !== undefined && direct !== "") {
    return direct;
  }
  for (const value of Object.values(source)) {
    if (value && typeof value === "object") {
      const nested = pickDeepValue(value, keys, seen);
      if (nested !== null && nested !== undefined && String(nested).trim() !== "") {
        return nested;
      }
    }
  }
  return null;
}

function firstNonEmpty(...values) {
  return values.find((value) => value !== undefined && value !== null && String(value).trim() !== "") ?? "";
}
