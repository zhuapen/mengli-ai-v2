const HUXUAN_CONTENT_SCRIPT_VERSION = "2026-06-15-huxuan-note-debug-v34";
const HUXUAN_VISIBLE_WORK_FALLBACK_ENABLED = false;

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.source !== "huxuan-data-collector") {
    return false;
  }

  if (message.action === "huxuan-ping") {
    sendResponse({ ok: true, version: HUXUAN_CONTENT_SCRIPT_VERSION });
    return false;
  }

  if (message.action === "collect-huxuan-row-metrics" || message.action === "collect-huxuan-row-metrics-v2") {
    collectHuxuanRowMetrics(message.payload)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ error: error.message || String(error) }));
    return true;
  }

  return false;
});

const API = Object.freeze({
  userInfo: "https://huxuan.qq.com/cgi-bin/advertiser/get_user_info",
  search: "https://huxuan.qq.com/cgi-bin/advertiser/finder_publisher/search",
  detail: (appid) => `https://huxuan.qq.com/cgi-bin/advertiser/finder_publisher/detail?appid=${encodeURIComponent(appid)}`,
  detailV2: (appid) => `https://huxuan.qq.com/cgi-bin/advertiser/finder_publisher/detail?appid=${encodeURIComponent(appid)}&inner_from=finder_trade_detail`,
  nearVideos: (appid, query) => `https://huxuan.qq.com/cgi-bin/advertiser/finder_publisher/near_videos?appid=${encodeURIComponent(appid)}&${query}`,
  videoList: (appid, query) => `https://huxuan.qq.com/cgi-bin/advertiser/finder_publisher/get_finder_video_show?appid=${encodeURIComponent(appid)}&${query}`,
  shareUrls: (exportId) => {
    const encodedExportId = encodeURIComponent(exportId);
    return [
      `https://huxuan.qq.com/cgi-bin/advertiser/finder_publisher/get_share_url?export_id=${encodedExportId}`,
      `https://huxuan.qq.com/advertiser/finder_publisher/get_share_url?export_id=${encodedExportId}`
    ];
  }
});

const shareUrlCache = new Map();
const visibleShareUrlCache = new Map();

async function collectHuxuanRowMetrics({ locators, accountFields = [], noteFields = [], chartProfiles = {} }) {
  const appid = await resolveAppid(locators);
  if (accountFields.length > 0) {
    await waitForVisibleCreator(appid);
  }
  const bundle = await fetchHuxuanBundle(appid, {
    account: accountFields.length > 0,
    accountFields,
    notes: noteFields.length > 0,
    locators,
    chartProfiles
  });
  if (accountFields.length > 0 && !hasSuccessfulResponse(bundle, ["detail", "searchResult"]) && !bundle.pageMetrics) {
    const error = bundle.detail?.error || bundle.searchResult?.error || "请确认已登录腾讯互选并有权限访问达人数据";
    throw new Error(error);
  }
  if (noteFields.length > 0 && !hasSuccessfulResponse(bundle, ["nearVideos", "videoList"])) {
    const error = bundle.nearVideos?.error || bundle.videoList?.error || "请确认已登录腾讯互选并有权限访问作品数据";
    throw new Error(error);
  }

  const matchedNote = noteFields.length
    ? await withStageTimeout(
        matchPublishedWork(bundle, locators.publishUrl, locators),
        65000,
        "作品链接匹配",
        null,
        bundle.collection_errors ?? []
      )
    : null;

  return {
    account: accountFields.length
      ? {
          status: "ok",
          locators,
          fields: accountFields,
          appid,
          bundle
        }
      : null,
    note: noteFields.length
      ? {
          status: matchedNote ? "ok" : "not-found",
          locators,
          fields: noteFields,
          appid,
          bundle,
          matchedNote
        }
      : null
  };
}

async function waitForVisibleCreator(appid) {
  const deadline = Date.now() + 10000;
  while (Date.now() < deadline) {
    const text = document.body?.innerText ?? "";
    if (!appid || text.includes(appid)) {
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 300));
  }
}

function hasSuccessfulResponse(bundle, keys) {
  return keys.some((key) => bundle[key] && bundle[key].success !== false && !bundle[key].error);
}

async function resolveAppid(locators = {}) {
  const directAppid = firstNonEmpty(
    locators.appid,
    extractAppid(locators.huxuanProfileUrl),
    extractAppid(location.href)
  );
  if (directAppid) {
    return directAppid;
  }

  const keyword = firstNonEmpty(locators.finderId, locators.nickname);
  if (!keyword) {
    throw new Error("当前行缺少达人ID、互选ID、视频号ID或视频号昵称");
  }

  const searched = await searchAppid(keyword);
  if (searched) {
    return searched;
  }

  throw new Error(`腾讯互选未找到视频号达人：${keyword}`);
}

async function searchAppid(keyword) {
  const response = await searchPublisher(keyword);
  const candidates = collectObjects(response).filter((item) => pickValue(item, ["appid", "app_id", "finder_appid"]));
  const exact = candidates.find((item) => {
    const names = [
      pickValue(item, ["finder_id", "finderId", "uniq_id", "username", "alias"]),
      pickValue(item, ["nickname", "nick_name", "finder_nickname", "name"])
    ].map((value) => String(value ?? "").trim());
    return names.includes(String(keyword).trim());
  });
  const picked = exact ?? candidates[0];
  const appid = pickValue(picked, ["appid", "app_id", "finder_appid"]);
  return appid ? String(appid) : "";
}

async function searchPublisher(keyword) {
  const payloads = [
    { keyword: String(keyword), page: 1, page_size: 10 },
    { query: String(keyword), page: 1, page_size: 10 },
    { nick_name: String(keyword), page: 1, page_size: 10 }
  ];

  const responses = await Promise.all(payloads.map((payload) => fetchJsonOptional(API.search, {
      method: "POST",
      body: JSON.stringify(payload),
      timeoutMs: 8000
    })));

  for (const response of responses) {
    const candidates = collectObjects(response).filter((item) => pickValue(item, ["appid", "app_id", "finder_appid"]));
    if (candidates.length) {
      return response;
    }
  }
  return responses.find((response) => response && !response.error && response.success !== false) ?? responses[0] ?? null;
}

async function fetchHuxuanBundle(appid, loadPlan = {}) {
  const shouldLoadAccount = loadPlan.account !== false;
  const shouldLoadNotes = loadPlan.notes === true;
  const performanceScope = normalizePerformanceScope(loadPlan.locators?.performanceScope);
  const audienceScope = normalizeAudienceScope(loadPlan.locators?.audienceScope);
  const videoQuery = buildVideoQuery(performanceScope);
  const collectionErrors = [];
  const timeoutFallback = (label) => ({ success: false, error: `${label}超时` });
  const [userInfo, detail, nearVideos] = await Promise.all([
    withStageTimeout(fetchJsonOptional(API.userInfo, { timeoutMs: 8000 }), 9000, "登录信息", timeoutFallback("登录信息"), collectionErrors),
    shouldLoadAccount ? withStageTimeout(fetchBestDetail(appid), 16000, "达人详情", timeoutFallback("达人详情"), collectionErrors) : null,
    shouldLoadNotes ? withStageTimeout(fetchJsonOptional(API.nearVideos(appid, videoQuery), { timeoutMs: 8000 }), 9000, "近期作品", timeoutFallback("近期作品"), collectionErrors) : null
  ]);
  const searchResult = shouldLoadAccount
    ? await withStageTimeout(searchPublisher(appid), 9000, "达人搜索", timeoutFallback("达人搜索"), collectionErrors)
    : null;
  const videoList = shouldLoadNotes
    ? await withStageTimeout(fetchVideoListPages(appid, videoQuery), 18000, "作品列表", timeoutFallback("作品列表"), collectionErrors)
    : null;
  const shouldLoadVisiblePage = shouldLoadAccount || (shouldLoadNotes && HUXUAN_VISIBLE_WORK_FALLBACK_ENABLED);
  const pageMetrics = shouldLoadVisiblePage
    ? await withStageTimeout(
        readVisiblePageMetrics(appid, loadPlan.chartProfiles, performanceScope, {
          accountFields: loadPlan.accountFields,
          includePageVideos: shouldLoadNotes && HUXUAN_VISIBLE_WORK_FALLBACK_ENABLED
        }),
        36000,
        "页面可见数据",
        loadPlan.chartProfiles || null,
        collectionErrors
      )
    : null;
  if (pageMetrics && collectionErrors.length) {
    pageMetrics.chart_error = [pageMetrics.chart_error, ...collectionErrors].filter(Boolean).join("；");
  }

  return {
    appid,
    filters: {
      performanceScope,
      audienceScope
    },
    userInfo,
    detail,
    searchResult,
    nearVideos,
    videoList,
    pageMetrics: pageMetrics || loadPlan.chartProfiles || null,
    collection_errors: collectionErrors
  };
}

async function withStageTimeout(promise, timeoutMs, label, fallback, errors = []) {
  let timerId;
  try {
    return await Promise.race([
      promise,
      new Promise((resolve) => {
        timerId = setTimeout(() => {
          const error = `${label}超时`;
          errors.push(error);
          resolve(typeof fallback === "function" ? fallback(error) : fallback);
        }, timeoutMs);
      })
    ]);
  } catch (error) {
    const message = `${label}失败：${error.message || String(error)}`;
    errors.push(message);
    return typeof fallback === "function" ? fallback(message) : fallback;
  } finally {
    clearTimeout(timerId);
  }
}

async function fetchBestDetail(appid) {
  const [pageDetail, legacyDetail] = await Promise.all([
    fetchJsonOptional(API.detailV2(appid)),
    fetchJsonOptional(API.detail(appid))
  ]);
  if (pageDetail && !pageDetail.error && pageDetail.success !== false) {
    return mergeDetailResponses(pageDetail, legacyDetail);
  }
  if (legacyDetail && !legacyDetail.error && legacyDetail.success !== false) {
    return legacyDetail;
  }
  return pageDetail?.error ? pageDetail : legacyDetail;
}

function mergeDetailResponses(primary, fallback) {
  if (!primary || !fallback || fallback.error || fallback.success === false) {
    return primary;
  }
  return {
    ...fallback,
    ...primary,
    data: {
      ...(fallback.data ?? {}),
      ...(primary.data ?? {})
    }
  };
}

function normalizePerformanceScope(value) {
  const text = String(value ?? "").trim();
  if (/互选|商单|合作/.test(text)) {
    return "互选商单";
  }
  return "全部视频";
}

function normalizeAudienceScope(value) {
  const text = String(value ?? "").trim();
  if (/观众/.test(text)) {
    return "观众画像";
  }
  return "粉丝画像";
}

function buildVideoQuery(performanceScope) {
  const params = new URLSearchParams({
    show_type: performanceScope === "互选商单" ? "1" : "0",
    video_type: "0",
    version: "2"
  });
  return params.toString();
}

async function fetchVideoListPages(appid, baseQuery) {
  const first = await fetchJsonOptional(API.videoList(appid, `${baseQuery}&page_index=0&page_size=8`));
  if (first?.success === false || first?.error) {
    return first;
  }

  const total = Number(first?.data?.total_cnt ?? 0);
  const pageSize = 8;
  const pageCount = Math.min(30, Math.ceil(total / pageSize) || 1);
  const videoList = [...(first?.data?.video_list ?? [])];
  const nextPages = await Promise.all(
    Array.from({ length: Math.max(0, pageCount - 1) }, (_, index) => {
      const page = index + 1;
      return fetchJsonOptional(API.videoList(appid, `${baseQuery}&page_index=${page}&page_size=${pageSize}`), { timeoutMs: 10000 });
    })
  );
  for (const next of nextPages) {
    if (next?.success === false || next?.error) {
      continue;
    }
    videoList.push(...(next?.data?.video_list ?? []));
  }
  return {
    ...first,
    data: {
      ...(first.data ?? {}),
      video_list: dedupeVideos(videoList)
    }
  };
}

async function readVisiblePageMetrics(appid, preloadedChartProfiles = {}, performanceScope = "全部视频", options = {}) {
  const accountFields = Array.isArray(options) ? options : (options.accountFields ?? []);
  const includePageVideos = Array.isArray(options) ? true : options.includePageVideos !== false;
  const pageErrors = [];
  const accountCard = await readVisibleAccountCardMetrics(appid);
  const wechatContact = needsWechatContact(accountFields)
    ? await withStageTimeout(readVisibleWechatContact(), 15000, "微信联系方式", { value: "", error: "微信联系方式超时" }, pageErrors)
    : null;
  const normalizedPerformanceScope = normalizePerformanceScope(performanceScope);
  await ensureVisiblePerformanceScope(normalizedPerformanceScope);
  await waitForPerformanceMetrics(normalizedPerformanceScope, 9000);
  const text = document.body?.innerText ?? "";
  const mergedText = [accountCard.text, text].filter(Boolean).join("\n");
  if (!mergedText || (appid && !location.href.includes(appid) && !mergedText.includes(appid))) {
    return null;
  }
  const performanceText = findPerformanceSectionRoot(normalizedPerformanceScope)?.innerText || findPerformanceSectionRoot()?.innerText || text;
  const lines = splitVisibleLines(mergedText);
  const performanceLines = splitVisibleLines(performanceText);
  const wechatContactValue = typeof wechatContact === "string" ? wechatContact : (wechatContact?.value || "");
  const fallbackWechatContact = extractWechatContactFromText(mergedText);
  const chartProfiles = hasGenderProfile(preloadedChartProfiles)
    ? preloadedChartProfiles
    : await withStageTimeout(readAudienceGenderProfiles(), 14000, "受众画像", {}, pageErrors);
  const fansGenderProfile = extractGenderProfile(mergedText, "粉丝画像") ?? chartProfiles.fans_gender_profile ?? null;
  const audienceGenderProfile = extractGenderProfile(mergedText, "观众画像") ?? chartProfiles.audience_gender_profile ?? null;
  const pageVideos = includePageVideos
    ? await withStageTimeout(
        readVisiblePublishedVideosAcrossPages(normalizedPerformanceScope),
        18000,
        "页面作品翻页",
        [],
        pageErrors
      )
    : [];
  const chartError = [
    fansGenderProfile ? "" : "粉丝画像性别分布未识别",
    audienceGenderProfile ? "" : "观众画像性别分布未识别",
    ...pageErrors
  ].filter(Boolean).join("；");
  return {
    success: true,
    nickname: accountCard.nickname ?? extractNickname(lines, appid),
    finder_id: appid,
    fans_count: accountCard.fans_count ?? extractMetricAfterLabel(lines, "粉丝量"),
    short_video_price: accountCard.short_video_price ?? extractMetricAfterLabel(lines, "1~60s视频") ?? extractMetricAfterLabel(lines, "1-60s视频") ?? extractMetricAfterLabel(lines, "1 至 60 秒"),
    long_video_price: accountCard.long_video_price ?? extractMetricAfterLabel(lines, "60s以上视频") ?? extractMetricAfterLabel(lines, "60 秒以上"),
    category_name: accountCard.category_name ?? extractInlineText(mergedText, /达人类型\s*([^\s]+)\s+适合行业/),
    tags: extractTags(lines),
    wechat_contact: wechatContactValue || fallbackWechatContact,
    wechat_contact_error: typeof wechatContact === "object" ? (wechatContact.error || "") : "",
    description: accountCard.description ?? extractInlineText(mergedText, /个人简介\s*([\s\S]*?)(?:\s*展开|\s*1~60s视频|\s*1-60s视频|\s*账号指数)/),
    average_play_count: extractMetricAfterLabel(performanceLines, "平均播放量"),
    play_median: extractMetricAfterLabel(performanceLines, "播放中位数"),
    expected_cpm: extractMetricAfterLabel(performanceLines, "预期CPM"),
    finish_rate: extractMetricAfterLabel(performanceLines, "完播率"),
    interaction_rate: extractMetricAfterLabel(performanceLines, "互动率"),
    expected_cpe: extractMetricAfterLabel(performanceLines, "预期 CPE"),
    thumb_like_average: extractMetricAfterLabel(performanceLines, "平均拇指赞量"),
    forward_average: extractMetricAfterLabel(performanceLines, "平均转发量"),
    love_like_average: extractMetricAfterLabel(performanceLines, "平均爱心赞量"),
    comment_average: extractMetricAfterLabel(performanceLines, "平均评论量"),
    fans_gender_profile: fansGenderProfile,
    audience_gender_profile: audienceGenderProfile,
    chart_error: chartProfiles.chart_error ?? chartError,
    page_visible_error: pageErrors.join("；"),
    page_videos: pageVideos.length ? pageVideos : extractVisiblePublishedVideos(lines)
  };
}

async function readVisibleAccountCardMetrics(appid) {
  window.scrollTo({ top: 0, left: 0, behavior: "instant" });
  await sleep(300);
  if (appid) {
    scrollToVisibleText(appid);
    await sleep(200);
  }
  const text = document.body?.innerText ?? "";
  const lines = splitVisibleLines(text);
  return {
    text,
    nickname: extractNickname(lines, appid),
    fans_count: extractMetricAfterLabel(lines, "粉丝量"),
    short_video_price: extractMetricAfterLabel(lines, "1~60s视频") ?? extractMetricAfterLabel(lines, "1-60s视频") ?? extractMetricAfterLabel(lines, "1 至 60 秒"),
    long_video_price: extractMetricAfterLabel(lines, "60s以上视频") ?? extractMetricAfterLabel(lines, "60 秒以上"),
    category_name: extractInlineText(text, /达人类型\s*([^\s]+)\s+适合行业/),
    description: extractInlineText(text, /个人简介\s*([\s\S]*?)(?:\s*展开|\s*1~60s视频|\s*1-60s视频|\s*账号指数)/)
  };
}

function needsWechatContact(fields = []) {
  return fields.some((field) => /(?:联系方式|联系微信|微信联系方式|微信号|wechat)/i.test(String(field ?? "")));
}

async function readVisibleWechatContact() {
  const alreadyOpenValue = extractWechatContactFromModal();
  if (alreadyOpenValue) {
    await closeWechatContactModal();
    return alreadyOpenValue;
  }

  normalizeAccountDetailViewport();
  await sleep(150);
  const contactButton = findAccountContactButton();
  if (!contactButton) {
    return { value: "", error: "未找到联系按钮" };
  }
  await dispatchAccountTrustedClick(contactButton);
  if (!await waitForVisibleText("添加微信", 5000)) {
    return { value: "", error: "联系菜单未出现添加微信" };
  }
  const addWechatButton = findClickableTextElement("添加微信");
  if (!addWechatButton) {
    return { value: "", error: "未找到添加微信按钮" };
  }
  await dispatchAccountTrustedClick(addWechatButton);
  if (!await waitForWechatContactModal(5000)) {
    return { value: "", error: "微信号弹窗未出现" };
  }
  const value = extractWechatContactFromModal();
  await closeWechatContactModal();
  return value || { value: "", error: "微信号弹窗未识别到联系方式" };
}

function normalizeAccountDetailViewport() {
  window.scrollTo({ top: 0, left: 0, behavior: "instant" });
}

function findAccountContactButton() {
  const roots = [
    ...document.querySelectorAll(".trade_publisher__detail-order-btn"),
    ...document.querySelectorAll(".free-trade__detail-price"),
    ...document.querySelectorAll(".trade-publisher-detail-info, .selection-detail__left")
  ];
  const root = roots.find((element) => {
    const text = String(element.innerText ?? "");
    return text.includes("立即下单") && text.includes("联系");
  }) ?? roots.find((element) => String(element.innerText ?? "").includes("联系"));
  return root ? findAccountCardTextButton("联系", root) : findAccountCardTextButton("联系");
}

async function waitForVisibleText(label, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const element = findVisibleTextElement(label);
    if (element) {
      const rect = element.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        return true;
      }
    }
    await sleep(200);
  }
  return false;
}

async function waitForWechatContactModal(timeoutMs = 4000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (findWechatContactModal()) {
      await sleep(200);
      return true;
    }
    await sleep(200);
  }
  return false;
}

function findWechatContactModal() {
  const selectors = ".spaui-dialog, .spaui-dialog-content, .spaui-dialog-inner, [role='dialog'], [class*='dialog'], [class*='modal']";
  return pickSmallestTextRoot([...document.querySelectorAll(selectors)], (text) => {
    return text.includes("微信号") && text.includes("一键复制");
  });
}

function extractWechatContactFromModal() {
  const modal = findWechatContactModal();
  if (!modal) {
    return "";
  }
  const lines = splitVisibleLines(modal.innerText);
  const candidates = lines
    .map((line) => line.trim())
    .filter((line) => line && !/微信号|一键复制|关闭/.test(line))
    .filter((line) => /[A-Za-z0-9_-]{4,}/.test(line));
  return candidates[0] || "";
}

function extractWechatContactFromText(text) {
  const source = String(text ?? "");
  const lines = splitVisibleLines(source);
  const labelPattern = /(商务合作|合作微信|微信号|微信|联系方式|联系微信|vx|wechat)/i;
  const candidates = [];
  for (const line of lines) {
    if (!labelPattern.test(line)) {
      continue;
    }
    const normalized = line.replace(/[：:]/g, " ");
    const match = normalized.match(/[A-Za-z][A-Za-z0-9_-]{3,}/);
    if (match) {
      candidates.push(match[0]);
    }
  }
  return candidates.find((value) => !/^(?:wechat|weixin|mcn|id|vx)$/i.test(value)) || "";
}

async function dispatchAccountUiClick(element) {
  if (!element) {
    return false;
  }
  dispatchPublishedVideoControlClick(element);
  await sleep(150);
  return true;
}

async function dispatchAccountTrustedClick(element) {
  if (!element) {
    return false;
  }
  await dispatchPublishedVideoTrustedClick(element);
  await sleep(250);
  return true;
}

async function closeWechatContactModal() {
  const modal = findWechatContactModal();
  if (!modal) {
    return true;
  }
  const closeButton = findClickableTextElement("关闭", modal) ||
    modal.querySelector(".spaui-dialog-close, [aria-label*='关闭'], [aria-label*='close']");
  if (closeButton) {
    await dispatchAccountUiClick(closeButton);
  } else {
    dispatchEscapeKey();
  }
  const deadline = Date.now() + 1600;
  while (Date.now() < deadline) {
    await sleep(200);
    if (!findWechatContactModal()) {
      return true;
    }
  }
  return !findWechatContactModal();
}

async function ensureVisiblePerformanceScope(performanceScope) {
  const normalizedScope = /互选|商单|合作/.test(String(performanceScope ?? ""))
    ? "互选商单"
    : "全部视频";
  await waitForBodyText("数据表现", 8000);
  scrollToVisibleText("数据表现");
  await sleep(200);
  if (!isPerformanceScopeSelected(normalizedScope)) {
    clickPerformanceScope(normalizedScope);
  }
  await waitForPerformanceScope(normalizedScope, 6000);
}

function clickPerformanceScope(label) {
  const root = findPerformanceSectionRoot(label);
  const target = root ? findClickableTextElement(label, root) : findClickableTextElement(label);
  if (!target) {
    return false;
  }
  target.scrollIntoView({ block: "center", inline: "nearest" });
  target.click();
  return true;
}

async function waitForPerformanceScope(label, timeoutMs = 6000) {
  const deadline = Date.now() + timeoutMs;
  let lastText = "";
  let stableCount = 0;
  while (Date.now() < deadline) {
    const root = findPerformanceSectionRoot(label);
    const text = String(root?.innerText ?? "");
    const hasMetrics = text.includes("平均播放量") && text.includes("完播率");
    if (isPerformanceScopeSelected(label) && hasMetrics) {
      return true;
    }
    if (hasMetrics && text === lastText) {
      stableCount += 1;
      if (stableCount >= 4) {
        return true;
      }
    } else {
      lastText = text;
      stableCount = 0;
    }
    await sleep(300);
  }
  return false;
}

async function waitForPerformanceMetrics(label, timeoutMs = 9000) {
  const deadline = Date.now() + timeoutMs;
  let lastText = "";
  let stableCount = 0;
  while (Date.now() < deadline) {
    const root = findPerformanceSectionRoot(label) ?? findPerformanceSectionRoot();
    const text = String(root?.innerText ?? "");
    const lines = splitVisibleLines(text);
    const hasCoreMetrics = [
      "平均播放量",
      "播放中位数",
      "完播率",
      "互动率"
    ].every((metric) => extractMetricAfterLabel(lines, metric));
    if (hasCoreMetrics && text === lastText) {
      stableCount += 1;
      if (stableCount >= 3) {
        return true;
      }
    } else {
      lastText = text;
      stableCount = hasCoreMetrics ? 1 : 0;
    }
    await sleep(350);
  }
  return false;
}

function isPerformanceScopeSelected(label) {
  const root = findPerformanceSectionRoot(label);
  const target = root ? findVisibleTextElement(label, root) : findVisibleTextElement(label);
  return isScopeElementSelected(target);
}

function isAudienceScopeSelected(label) {
  const root = findAudienceSectionRoot();
  const target = root ? findVisibleTextElement(label, root) : findVisibleTextElement(label);
  return isScopeElementSelected(target);
}

function isScopeElementSelected(element) {
  let current = element;
  for (let depth = 0; current && depth < 6; depth += 1) {
    const className = String(current.className ?? "");
    const ariaSelected = current.getAttribute?.("aria-selected");
    const ariaChecked = current.getAttribute?.("aria-checked");
    if (
      ariaSelected === "true" ||
      ariaChecked === "true" ||
      current.getAttribute?.("data-selected") === "true" ||
      current.getAttribute?.("data-checked") === "true" ||
      /\b(?:active|selected|checked|current|is-active|is-selected|ant-tabs-tab-active|ant-radio-button-wrapper-checked)\b/i.test(className)
    ) {
      return true;
    }
    current = current.parentElement;
  }
  return false;
}

function clickExactVisibleText(label) {
  const target = findClickableTextElement(label);
  if (!target) {
    return false;
  }
  target.scrollIntoView({ block: "center", inline: "nearest" });
  target.click();
  return true;
}

function scrollToVisibleText(label) {
  const target = findVisibleTextElement(label);
  if (!target) {
    return false;
  }
  target.scrollIntoView({ block: "center", inline: "nearest" });
  return true;
}

function findAccountCardTextButton(label, root = document) {
  const expected = String(label ?? "").trim();
  if (!expected) {
    return null;
  }
  const exactButtons = [...root.querySelectorAll("button, [role='button']")]
    .filter((element) => String(element.textContent ?? "").trim() === expected);
  const visibleButton = exactButtons.find((element) => {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  });
  return visibleButton ?? findClickableTextElement(label, root);
}

function findClickableTextElement(label, root = document) {
  const textElement = findVisibleTextElement(label, root);
  if (!textElement) {
    return null;
  }
  let current = textElement;
  for (let depth = 0; current && depth < 5; depth += 1) {
    const role = String(current.getAttribute?.("role") ?? "");
    const cursor = window.getComputedStyle?.(current).cursor;
    if (
      current.tagName === "BUTTON" ||
      current.tagName === "A" ||
      role === "tab" ||
      role === "button" ||
      typeof current.onclick === "function" ||
      cursor === "pointer"
    ) {
      return current;
    }
    current = current.parentElement;
  }
  return textElement.parentElement ?? textElement;
}

function findVisibleTextElement(label, root = document) {
  const expected = String(label ?? "").trim();
  if (!expected) {
    return null;
  }
  const candidates = [...root.querySelectorAll("button, [role='tab'], a, h1, h2, h3, h4, div, span")]
    .filter((element) => String(element.textContent ?? "").trim() === expected);
  return candidates.find((element) => {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }) ?? candidates[0] ?? null;
}

function findPerformanceSectionRoot(requiredScope = "") {
  const headings = [...document.querySelectorAll("h1, h2, h3, h4, div, span")]
    .filter((element) => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && String(element.textContent ?? "").trim() === "传播表现";
    });
  const required = String(requiredScope || "").trim();
  const acceptsText = (text) => {
    return text.includes("传播表现") &&
      text.includes("平均播放量") &&
      (!required || text.includes(required));
  };
  for (const heading of headings) {
    let current = heading;
    for (let depth = 0; current && depth < 8; depth += 1) {
      const text = String(current.innerText ?? "");
      if (acceptsText(text)) {
        return current;
      }
      current = current.parentElement;
    }
  }
  return pickSmallestTextRoot([...document.querySelectorAll("section, main, article, div")], acceptsText);
}

function findAudienceSectionRoot() {
  const headings = [...document.querySelectorAll("h1, h2, h3, h4, div, span")]
    .filter((element) => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && String(element.textContent ?? "").trim() === "受众画像";
    });
  const acceptsText = (text) => text.includes("受众画像") && text.includes("性别分布");
  for (const heading of headings) {
    let current = heading;
    for (let depth = 0; current && depth < 8; depth += 1) {
      const text = String(current.innerText ?? "");
      if (acceptsText(text)) {
        return current;
      }
      current = current.parentElement;
    }
  }
  return pickSmallestTextRoot([...document.querySelectorAll("section, main, article, div")], acceptsText);
}

function pickSmallestTextRoot(elements, acceptsText) {
  let best = null;
  let bestArea = Infinity;
  for (const element of elements) {
    const rect = element.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) {
      continue;
    }
    const text = String(element.innerText ?? "");
    if (!acceptsText(text)) {
      continue;
    }
    const area = rect.width * rect.height;
    if (area < bestArea) {
      best = element;
      bestArea = area;
    }
  }
  return best;
}

async function waitForBodyText(label, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (String(document.body?.innerText ?? "").includes(label)) {
      return true;
    }
    await sleep(250);
  }
  return false;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function hasGenderProfile(value = {}) {
  return Boolean(value?.fans_gender_profile || value?.audience_gender_profile);
}

async function readAudienceGenderProfiles() {
  const result = {};
  if (!await waitForBodyText("受众画像", 8000)) {
    return result;
  }

  for (const [scopeLabel, key] of [
    ["粉丝画像", "fans_gender_profile"],
    ["观众画像", "audience_gender_profile"]
  ]) {
    scrollToVisibleText("受众画像");
    await sleep(300);
    if (!isAudienceScopeSelected(scopeLabel)) {
      clickAudienceScope(scopeLabel);
    }
    await waitForAudienceScope(scopeLabel, 5000);

    const text = document.body?.innerText ?? "";
    const visibleProfile = extractGenderProfile(text, scopeLabel);
    const chartProfile = await readPageChartProfiles(scopeLabel);
    result[key] = visibleProfile ?? chartProfile[key] ?? chartProfile.gender_profile ?? null;
  }

  const missing = [
    result.fans_gender_profile ? "" : "粉丝画像性别分布未识别",
    result.audience_gender_profile ? "" : "观众画像性别分布未识别"
  ].filter(Boolean);
  if (missing.length) {
    result.chart_error = missing.join("；");
  }
  return result;
}

async function waitForAudienceScope(label, timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs;
  let lastText = "";
  let stableCount = 0;
  while (Date.now() < deadline) {
    const root = findAudienceSectionRoot();
    const text = String(root?.innerText ?? "");
    if (isAudienceScopeSelected(label) && text.includes("性别分布")) {
      return true;
    }
    if (text.includes("性别分布") && text === lastText) {
      stableCount += 1;
      if (stableCount >= 4) {
        return true;
      }
    } else {
      lastText = text;
      stableCount = 0;
    }
    await sleep(250);
  }
  return false;
}

function clickAudienceScope(label) {
  const root = findAudienceSectionRoot();
  const target = root ? findClickableTextElement(label, root) : findClickableTextElement(label);
  if (!target) {
    return false;
  }
  target.scrollIntoView({ block: "center", inline: "nearest" });
  target.click();
  return true;
}

async function matchPublishedWork(bundle, publishUrl, locators = {}) {
  const target = normalizeUrl(publishUrl);
  const targetTokens = extractUrlTokens(publishUrl);
  const title = String(locators.title ?? "").trim();
  const publishedAt = String(locators.publishedAt ?? "").trim();
  const hasExplicitPublishUrl = Boolean(target || targetTokens.length);
  const hasExplicitWorkLocator = Boolean(target || targetTokens.length || title || publishedAt);
  const isTradeScope = /互选|商单|合作/.test(String(bundle?.filters?.performanceScope ?? ""));
  const apiCandidates = [
    ...collectVideoObjects(bundle.nearVideos),
    ...collectVideoObjects(bundle.videoList)
  ];
  const visibleCandidates = collectVideoObjects(bundle.pageMetrics?.page_videos);
  const matchDebug = {
    target,
    targetTokens,
    apiCandidateCount: apiCandidates.length,
    visibleCandidateCount: visibleCandidates.length,
    reason: "",
    share: null
  };
  bundle.work_match_debug = matchDebug;
  const candidates = [
    ...apiCandidates,
    ...(isTradeScope ? [] : visibleCandidates)
  ];
  if (!candidates.length) {
    matchDebug.reason = "no-candidates";
    return null;
  }

  const withScore = candidates.map((item) => {
    const urls = [
      pickValue(item, ["url", "share_url", "video_url", "publish_url", "link"]),
      pickValue(item, ["feed_url", "finder_url"])
    ].map(normalizeUrl).filter(Boolean);
    const urlMatched = Boolean(target && urls.some((url) => url === target || url.includes(target) || target.includes(url)));
    const tokenMatched = Boolean(targetTokens.length && hasMatchingVideoToken(item, targetTokens));
    const candidateTitle = firstNonEmpty(
      pickValue(item, ["title", "desc", "description", "video_title"]),
      ""
    );
    const titleScore = title ? titleMatchScore(title, candidateTitle) : 0;
    const timeMatched = Boolean(publishedAt && sameMinute(firstNonEmpty(
      pickValue(item, ["publish_time", "publishTime", "create_time", "createTime", "time", "release_time"]),
      ""
    ), publishedAt));
    const score = (urlMatched ? 2 : 0)
      + (tokenMatched ? 2 : 0)
      + titleScore
      + (timeMatched ? 0.75 : 0);
    const eligible = hasExplicitPublishUrl
      ? (urlMatched || tokenMatched || titleScore >= 0.85 || (titleScore >= 0.45 && timeMatched))
      : score > 0;
    return { item, score, urlMatched, tokenMatched, titleScore, timeMatched, eligible };
  })
    .filter((candidate) => candidate.eligible)
    .sort((left, right) => right.score - left.score);

  const directBest = withScore.find((candidate) => candidate.urlMatched || candidate.tokenMatched);
  if (directBest) {
    return buildMatchedPublishedWorkResult(directBest, visibleCandidates, locators, title);
  }

  const best = withScore[0];
  if (best && hasHighConfidenceTitleMatch(best)) {
    return buildMatchedPublishedWorkResult(best, visibleCandidates, locators, title);
  }

  const shareMatchedItem = hasExplicitPublishUrl
    ? await matchPublishedWorkByShareUrl(apiCandidates, target, targetTokens, 16000, matchDebug)
    : null;
  if (shareMatchedItem) {
    const matchedItem = mergeVisiblePublishedMetrics(shareMatchedItem, visibleCandidates, firstNonEmpty(
      pickValue(shareMatchedItem, ["title", "desc", "description", "video_title"]),
      title
    ));
    return {
      ...matchedItem,
      match_method: "share-url",
      publish_share_url: shareMatchedItem.__resolved_share_url || "",
      publish_title_error: locators.publishTitleError || "",
      publish_title_source: locators.publishTitleSource || "",
      matchConfidence: 1
    };
  }

  const visibleShareMatchedItem = HUXUAN_VISIBLE_WORK_FALLBACK_ENABLED && hasExplicitPublishUrl
    ? await matchPublishedWorkByVisibleShareUrl(target, targetTokens, bundle?.filters?.performanceScope, bundle?.appid, 18000)
    : null;
  if (visibleShareMatchedItem) {
    return {
      ...visibleShareMatchedItem,
      match_method: "visible-copy-link",
      publish_title_error: locators.publishTitleError || "",
      publish_title_source: locators.publishTitleSource || "",
      matchConfidence: 1
    };
  }

  if (!best || best.score <= 0) {
    if (hasExplicitWorkLocator) {
      matchDebug.reason = matchDebug.reason || "explicit-locator-not-matched";
      return null;
    }
    const fallback = apiCandidates[0] ?? (isTradeScope ? null : visibleCandidates[0]);
    if (fallback) {
      return {
        ...fallback,
        match_method: "selected-scope-first-video-fallback",
        publish_title_error: locators.publishTitleError || "",
        matchConfidence: 0.1
      };
    }
    return null;
  }
  return buildMatchedPublishedWorkResult(best, visibleCandidates, locators, title);
}

function hasHighConfidenceTitleMatch(candidate) {
  if (!candidate) {
    return false;
  }
  return candidate.titleScore >= 0.85 || (candidate.titleScore >= 0.55 && candidate.timeMatched);
}

function buildMatchedPublishedWorkResult(best, visibleCandidates, locators = {}, locatorTitle = "") {
  const matchedItem = mergeVisiblePublishedMetrics(best.item, visibleCandidates, locatorTitle);
  return {
    ...matchedItem,
    match_method: best.urlMatched || best.tokenMatched
      ? "direct"
      : best.timeMatched
        ? "title-time"
        : "title",
    publish_title_error: locators.publishTitleError || "",
    publish_title_source: locators.publishTitleSource || "",
    matchConfidence: Math.min(1, best.urlMatched || best.tokenMatched ? 1 : best.titleScore + (best.timeMatched ? 0.1 : 0))
  };
}

async function matchPublishedWorkByShareUrl(candidates, target, targetTokens, timeoutMs = 24000, debug = null) {
  if (!target && !targetTokens.length) {
    return null;
  }
  const startedAt = Date.now();
  const keyed = [];
  const seen = new Set();
  for (const item of candidates) {
    const exportIds = pickCandidateExportIds(item);
    for (const exportId of exportIds) {
      if (!exportId || seen.has(exportId)) {
        continue;
      }
      seen.add(exportId);
      keyed.push({ item, exportId });
      if (keyed.length >= 96) {
        break;
      }
    }
    if (keyed.length >= 96) {
      break;
    }
  }
  if (debug) {
    debug.share = {
      candidateCount: candidates.length,
      keyedCount: keyed.length,
      attempted: 0,
      samples: []
    };
  }

  const batchSize = 8;
  for (let index = 0; index < keyed.length; index += batchSize) {
    if (Date.now() - startedAt > timeoutMs) {
      if (debug) {
        debug.reason = debug.reason || "share-url-timeout";
      }
      return null;
    }
    const matched = (await Promise.all(keyed.slice(index, index + batchSize).map(async ({ item, exportId }) => {
      const resolved = await resolveShareUrlForExportId(exportId);
      if (debug?.share) {
        debug.share.attempted += 1;
        if (debug.share.samples.length < 8) {
          debug.share.samples.push({
            exportId,
            url: resolved.url || "",
            error: resolved.error || ""
          });
        }
      }
      if (!shareUrlMatchesTarget(resolved.url, target, targetTokens)) {
        return null;
      }
      return {
        ...item,
        share_url: resolved.url,
        publish_url: resolved.url,
        __resolved_share_url: resolved.url
      };
    }))).find(Boolean);
    if (matched) {
      return matched;
    }
  }
  if (debug) {
    debug.reason = debug.reason || (keyed.length ? "share-url-not-matched" : "no-export-id");
  }
  return null;
}

async function matchPublishedWorkByVisibleShareUrl(target, targetTokens, performanceScope = "全部视频", appid = "", timeoutMs = 30000) {
  if (!target && !targetTokens.length) {
    return null;
  }
  if (!await ensureVisiblePublishedVideoScope(performanceScope)) {
    return null;
  }
  let root = findPublishedVideoSectionRoot();
  if (!root) {
    return null;
  }
  const cache = getVisibleShareUrlCache(appid, performanceScope, root);
  const cachedMatch = findVisibleShareUrlCacheMatch(cache, target, targetTokens);
  if (cachedMatch || cache.complete) {
    return cachedMatch;
  }

  const clipboardSnapshot = await readClipboardSnapshot();
  const startedAt = Date.now();
  try {
    const pageNumbers = findPublishedVideoPageNumbers(root);
    const pageLimit = Math.max(1, Math.min(8, pageNumbers.length ? Math.max(...pageNumbers) : 1));
    for (let pageIndex = 0; pageIndex < pageLimit; pageIndex += 1) {
      if (Date.now() - startedAt > timeoutMs) {
        return null;
      }
      root = findPublishedVideoSectionRoot();
      if (!root) {
        break;
      }
      root.scrollIntoView({ block: "center", inline: "nearest" });
      await sleep(250);
      const cards = getPublishedVideoCards(root);
      for (const card of cards) {
        if (Date.now() - startedAt > timeoutMs) {
          return null;
        }
        const item = readPublishedVideoCard(card);
        if (!item) {
          continue;
        }
        const itemKey = visiblePublishedVideoKey(item);
        if (cache.seenKeys.has(itemKey)) {
          continue;
        }
        const shareUrl = await withPromiseTimeout(
          copyPublishedVideoCardShareUrl(card),
          4000,
          "复制作品链接超时"
        ).catch(() => "");
        await closePublishedVideoPreviewModal();
        if (!shareUrl) {
          continue;
        }
        const cachedItem = {
          ...item,
            share_url: shareUrl,
            publish_url: shareUrl,
            __resolved_share_url: shareUrl
        };
        cache.items.push(cachedItem);
        cache.seenKeys.add(itemKey);
        if (shareUrlMatchesTarget(shareUrl, target, targetTokens)) {
          return cachedItem;
        }
      }
      if (pageIndex >= pageLimit - 1) {
        break;
      }
      const before = getPublishedVideoPageSignature(root);
      if (!clickPublishedVideoNextPage(root)) {
        const activePage = findPublishedVideoActivePage(root) || pageIndex + 1;
        if (!clickPublishedVideoPage(activePage + 1)) {
          break;
        }
      }
      await waitForPublishedVideoPageChange(before, 3500);
    }
    cache.complete = true;
    return null;
  } finally {
    await closePublishedVideoPreviewModal();
    await restorePublishedVideoFirstPage();
    await restoreClipboardSnapshot(clipboardSnapshot);
  }
}

function getVisibleShareUrlCache(appid, performanceScope, root) {
  const key = [
    String(appid || extractAppid(location.href) || location.href).trim(),
    normalizePerformanceScope(performanceScope),
    extractPublishedVideoDateRange(root)
  ].join("|");
  if (!visibleShareUrlCache.has(key)) {
    visibleShareUrlCache.set(key, {
      complete: false,
      items: [],
      seenKeys: new Set()
    });
  }
  return visibleShareUrlCache.get(key);
}

function findVisibleShareUrlCacheMatch(cache, target, targetTokens) {
  if (!cache?.items?.length) {
    return null;
  }
  return cache.items.find((item) => shareUrlMatchesTarget(item.share_url || item.publish_url, target, targetTokens)) ?? null;
}

function extractPublishedVideoDateRange(root) {
  const text = String(root?.innerText ?? "");
  return text.match(/\d{4}-\d{2}-\d{2}\s*至\s*\d{4}-\d{2}-\d{2}/)?.[0] || "";
}

async function copyPublishedVideoCardShareUrl(card) {
  await closePublishedVideoPreviewModal();
  const openTarget = findPublishedVideoCardOpenTarget(card);
  if (!openTarget) {
    return "";
  }
  await dispatchPublishedVideoTrustedClick(openTarget);
  if (!await waitForPublishedVideoPreviewModal(5000)) {
    return "";
  }
  const copyButton = findPreviewCopyLinkButton();
  if (!copyButton) {
    return "";
  }
  const cleared = await writeClipboardTextSafe("");
  const previousText = cleared.ok ? "" : (await readClipboardTextSafe()).text;
  await dispatchPublishedVideoTrustedClick(copyButton);
  const copied = await waitForCopiedShareUrl(previousText, 4000);
  return copied.ok ? copied.text : "";
}

function findPreviewCopyLinkButton() {
  const modal = findPublishedVideoPreviewModal();
  return modal ? findClickableTextElement("复制视频链接", modal) : findClickableTextElement("复制视频链接");
}

function findPublishedVideoCardOpenTarget(card) {
  if (!card?.querySelector) {
    return card || null;
  }
  return card.querySelector(".__card-img-wrapper, .finder-case__cover, .compression-cover, img.compression-cover, img") || card;
}

function findPublishedVideoPreviewModal() {
  const candidates = [
    ...document.querySelectorAll(".finder-preview-dialog, .video-preview-container, [role='dialog'], [data-spross-modal-overlay='dialog']")
  ].filter((element) => {
    const text = String(element.innerText ?? "");
    return text.includes("视频发表于") && text.includes("复制视频链接");
  });
  return candidates.sort((left, right) => String(left.innerText ?? "").length - String(right.innerText ?? "").length)[0] ?? null;
}

async function waitForPublishedVideoPreviewModal(timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (findPublishedVideoPreviewModal()) {
      await sleep(250);
      return true;
    }
    await sleep(200);
  }
  return false;
}

async function closePublishedVideoPreviewModal() {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const modal = findPublishedVideoPreviewModal();
    if (!modal) {
      return true;
    }
    const closeButton = modal.querySelector(".video-preview-header-close-btn, [aria-label*='关闭'], [aria-label*='close']");
    if (closeButton) {
      dispatchPublishedVideoControlClick(closeButton);
    } else {
      dispatchEscapeKey();
    }
    const deadline = Date.now() + 1800;
    while (Date.now() < deadline) {
      await sleep(200);
      if (!findPublishedVideoPreviewModal()) {
        return true;
      }
    }
  }
  return !findPublishedVideoPreviewModal();
}

function dispatchEscapeKey() {
  const options = {
    bubbles: true,
    cancelable: true,
    composed: true,
    key: "Escape",
    code: "Escape",
    keyCode: 27,
    which: 27
  };
  for (const target of [document.activeElement, document, window]) {
    if (!target?.dispatchEvent) {
      continue;
    }
    target.dispatchEvent(new KeyboardEvent("keydown", options));
    target.dispatchEvent(new KeyboardEvent("keyup", options));
  }
}

async function dispatchPublishedVideoTrustedClick(element) {
  if (!element) {
    return false;
  }
  element.scrollIntoView({ block: "center", inline: "center" });
  await sleep(150);
  let rect = element.getBoundingClientRect();
  if (!isElementCenterInViewport(rect)) {
    const targetLeft = Math.max(0, window.scrollX + rect.left - Math.max(20, (window.innerWidth - rect.width) / 2));
    const targetTop = Math.max(0, window.scrollY + rect.top - Math.max(20, (window.innerHeight - rect.height) / 2));
    window.scrollTo({ left: targetLeft, top: targetTop, behavior: "instant" });
    await sleep(150);
    rect = element.getBoundingClientRect();
  }
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;
  if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage && Number.isFinite(x) && Number.isFinite(y)) {
    try {
      const response = await chrome.runtime.sendMessage({
        source: "huxuan-data-collector",
        action: "trusted-click",
        payload: { x, y }
      });
      if (response?.ok !== false && response?.clicked) {
        dispatchPublishedVideoControlClick(element);
        return true;
      }
    } catch (_error) {
      // Fall back to DOM events below; account metrics do not require trusted clicks.
    }
  }
  return dispatchPublishedVideoControlClick(element);
}

function isElementCenterInViewport(rect) {
  if (!rect || rect.width <= 0 || rect.height <= 0) {
    return false;
  }
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;
  return x >= 0 && x <= window.innerWidth && y >= 0 && y <= window.innerHeight;
}

async function readClipboardSnapshot() {
  const snapshot = await readClipboardTextSafe();
  return snapshot.ok ? snapshot : { ok: false, text: "" };
}

async function restoreClipboardSnapshot(snapshot) {
  if (!snapshot?.ok || typeof navigator === "undefined" || !navigator.clipboard?.writeText) {
    return false;
  }
  return writeClipboardTextSafe(snapshot.text || "");
}

async function writeClipboardTextSafe(text) {
  try {
    if (typeof navigator === "undefined" || !navigator.clipboard?.writeText) {
      return { ok: false, error: "clipboardWrite不可用" };
    }
    window.focus?.();
    await withPromiseTimeout(navigator.clipboard.writeText(String(text ?? "")), 1500, "剪贴板写入超时");
    return { ok: true, error: "" };
  } catch (error) {
    return { ok: false, error: error.message || String(error) };
  }
}

async function waitForCopiedShareUrl(previousText = "", timeoutMs = 3000) {
  const startedAt = Date.now();
  let last = { ok: false, text: "", error: "" };
  while (Date.now() - startedAt < timeoutMs) {
    await sleep(250);
    const copied = await readClipboardTextSafe();
    last = copied;
    const text = String(copied.text ?? "").trim();
    if (!copied.ok || !text) {
      continue;
    }
    if (/^https:\/\/weixin\.qq\.com\/sph\//i.test(text) && (!previousText || text !== previousText)) {
      return copied;
    }
  }
  return last.ok ? { ok: false, text: last.text, error: "剪贴板未更新为视频号短链" } : last;
}

async function readClipboardTextSafe() {
  try {
    if (typeof navigator === "undefined" || !navigator.clipboard?.readText) {
      return { ok: false, text: "", error: "clipboardRead不可用" };
    }
    window.focus?.();
    const text = await withPromiseTimeout(navigator.clipboard.readText(), 1500, "剪贴板读取超时");
    return { ok: true, text, error: "" };
  } catch (error) {
    return { ok: false, text: "", error: error.message || String(error) };
  }
}

function withPromiseTimeout(promise, timeoutMs, message) {
  let timerId;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timerId = setTimeout(() => reject(new Error(message)), timeoutMs);
    })
  ]).finally(() => clearTimeout(timerId));
}

function pickCandidateExportIds(item) {
  const ranked = new Map();
  const add = (value, score) => {
    const text = String(value ?? "").trim();
    if (!/^[A-Za-z0-9_-]{6,}$/.test(text)) {
      return;
    }
    ranked.set(text, Math.max(ranked.get(text) ?? 0, score));
  };

  const directKeys = [
    "export_id",
    "exportId",
    "feed_export_id",
    "feedExportId",
    "finder_export_id",
    "finderExportId",
    "encrypted_feed_id",
    "encryptedFeedId"
  ];
  for (const key of directKeys) {
    add(pickValue(item, [key]), 100);
  }

  if (!ranked.size) {
    for (const object of collectObjects(item)) {
      for (const [key, value] of Object.entries(object)) {
        const score = exportIdKeyScore(key);
        if (!score) {
          continue;
        }
        add(value, score);
      }
    }
  }

  return [...ranked.entries()]
    .sort((left, right) => right[1] - left[1])
    .slice(0, 4)
    .map(([id]) => id);
}

function exportIdKeyScore(key) {
  const normalized = String(key ?? "").replace(/[_-]/g, "").toLowerCase();
  if (!normalized || /(appid|author|account|user|uin|nickname|name)$/.test(normalized)) {
    return 0;
  }
  if (normalized === "exportid" || normalized === "feedexportid" || normalized === "finderexportid") {
    return 100;
  }
  if (normalized === "encryptedfeedid") {
    return 90;
  }
  if (normalized.includes("export") && normalized.includes("id")) {
    return 85;
  }
  if (normalized.includes("encrypted") && normalized.includes("id")) {
    return 80;
  }
  if (normalized.includes("feed") && normalized.includes("export") && normalized.includes("id")) {
    return 75;
  }
  return 0;
}

async function resolveShareUrlForExportId(exportId) {
  if (shareUrlCache.has(exportId)) {
    return shareUrlCache.get(exportId);
  }
  const errors = [];
  for (const urlToFetch of API.shareUrls(exportId)) {
    const response = await fetchJsonOptional(urlToFetch, { timeoutMs: 3000 });
    const data = response?.data && typeof response.data === "object" ? response.data : response;
    const url = firstNonEmpty(
      pickValue(data, ["url", "share_url", "shareUrl", "link"]),
      pickValue(response, ["url", "share_url", "shareUrl", "link"])
    );
    if (url) {
      const result = {
        url: String(url ?? "").trim(),
        error: ""
      };
      shareUrlCache.set(exportId, result);
      return result;
    }
    if (response?.error) {
      errors.push(response.error);
    }
  }
  const result = {
    url: "",
    error: errors.filter(Boolean).join("；") || "互选复制链接接口未返回链接"
  };
  shareUrlCache.set(exportId, result);
  return result;
}

function shareUrlMatchesTarget(shareUrl, target, targetTokens) {
  const normalized = normalizeUrl(shareUrl);
  if (!normalized) {
    return false;
  }
  if (target && (normalized === target || normalized.includes(target) || target.includes(normalized))) {
    return true;
  }
  if (!targetTokens.length) {
    return false;
  }
  const shareTokens = extractUrlTokens(normalized);
  return targetTokens.some((token) => {
    return shareTokens.includes(token) || normalized.includes(token);
  });
}

function mergeVisiblePublishedMetrics(item, visibleCandidates, locatorTitle = "") {
  if (!item || item.__source === "visible-page") {
    return item;
  }
  const itemTitle = firstNonEmpty(
    pickValue(item, ["title", "desc", "description", "video_title"]),
    locatorTitle
  );
  if (!itemTitle || !visibleCandidates.length) {
    return item;
  }
  const matchedVisible = visibleCandidates
    .map((visible) => ({
      visible,
      titleScore: titleMatchScore(itemTitle, firstNonEmpty(
        pickValue(visible, ["title", "desc", "description", "video_title"]),
        ""
      )),
      interactionScore: visibleInteractionMatchScore(item, visible)
    }))
    .filter((candidate) => candidate.titleScore >= 0.85)
    .sort((left, right) => {
      if (right.interactionScore !== left.interactionScore) {
        return right.interactionScore - left.interactionScore;
      }
      return right.titleScore - left.titleScore;
    })[0]?.visible;
  if (!matchedVisible) {
    return item;
  }
  return {
    ...item,
    read_pv: matchedVisible.read_pv ?? item.read_pv,
    fav_pv: matchedVisible.fav_pv ?? item.fav_pv,
    share_pv: matchedVisible.share_pv ?? item.share_pv,
    heart_pv: matchedVisible.heart_pv ?? item.heart_pv,
    comment_pv: matchedVisible.comment_pv ?? item.comment_pv,
    visible_metrics_source: "visible-page"
  };
}

function visibleInteractionMatchScore(item, visible) {
  const pairs = [
    [["fav_pv", "thumb_like_count", "thumbLikeCount", "thumb_up_count", "up_like_count", "like_count", "likeCount", "likes", "like_num"], ["fav_pv"]],
    [["share_pv", "share_count", "shareCount", "forward_count", "forwardCount", "shares", "share_num"], ["share_pv"]],
    [["heart_pv", "love_like_count", "loveLikeCount", "favorite_count", "favorite_num", "collect_count", "collectCount"], ["heart_pv"]],
    [["comment_pv", "comment_count", "commentCount", "comments", "comment_num"], ["comment_pv"]]
  ];
  let score = 0;
  for (const [itemKeys, visibleKeys] of pairs) {
    const itemValue = normalizeCountForCompare(pickValue(item, itemKeys));
    const visibleValue = normalizeCountForCompare(pickValue(visible, visibleKeys));
    if (itemValue && visibleValue && itemValue === visibleValue) {
      score += 1;
    }
  }
  return score;
}

function normalizeCountForCompare(value) {
  return String(value ?? "")
    .replace(/[,，\s]/g, "")
    .trim();
}

function collectVideoObjects(response) {
  return collectObjects(response).filter((item) => {
    return pickValue(item, [
      "title",
      "desc",
      "description",
      "video_title",
      "play_count",
      "read_pv",
      "like_count",
      "fav_pv",
      "heart_pv",
      "share_url",
      "video_url",
      "feed_url",
      "finder_url",
      "publish_url",
      "export_id",
      "feed_export_id",
      "finder_export_id",
      "encrypted_feed_id"
    ]);
  });
}

function hasMatchingVideoToken(item, targetTokens) {
  const values = collectObjects(item)
    .flatMap((object) => Object.values(object ?? {}))
    .filter((value) => value !== null && value !== undefined)
    .map((value) => String(value));
  return targetTokens.some((token) => values.some((value) => value.includes(token)));
}

function titleMatchScore(targetTitle, candidateTitle) {
  const target = normalizeTitleText(targetTitle);
  const candidate = normalizeTitleText(candidateTitle);
  if (!target || !candidate) {
    return 0;
  }
  if (candidate.includes(target) || target.includes(candidate)) {
    return 0.9;
  }
  const targetTokens = splitTitleTokens(target);
  const candidateTokens = splitTitleTokens(candidate);
  if (!targetTokens.length || !candidateTokens.length) {
    return 0;
  }
  const matched = targetTokens.filter((token) => candidateTokens.some((candidateToken) => candidateToken.includes(token) || token.includes(candidateToken)));
  const ratio = matched.length / targetTokens.length;
  return ratio >= 0.45 ? ratio * 0.75 : 0;
}

function normalizeTitleText(value) {
  return String(value ?? "")
    .replace(/#[^#\s]+/g, " ")
    .replace(/[，。！？、,.!?;；:："'“”‘’（）()[\]【】<>《》~\-_|｜]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function splitTitleTokens(value) {
  const text = normalizeTitleText(value);
  const asciiTokens = text.match(/[a-z0-9]{2,}/g) ?? [];
  const cjkText = text.replace(/[a-z0-9\s]/g, "");
  const cjkTokens = [];
  for (let index = 0; index < cjkText.length - 1; index += 1) {
    cjkTokens.push(cjkText.slice(index, index + 2));
    if (index < cjkText.length - 3) {
      cjkTokens.push(cjkText.slice(index, index + 4));
    }
  }
  return [...new Set([...asciiTokens, ...cjkTokens].filter((token) => token.length >= 2))];
}

function dedupeVideos(videos) {
  const seen = new Set();
  return videos.filter((video) => {
    const key = pickValue(video, ["export_id", "feed_export_id", "finder_export_id", "encrypted_feed_id", "video_id", "id"]) || JSON.stringify([
      pickValue(video, ["release_time", "publish_time", "create_time"]),
      pickValue(video, ["description", "title", "desc"])
    ]);
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}

async function fetchJsonOptional(url, options = {}) {
  try {
    return await fetchJson(url, options);
  } catch (error) {
    return {
      success: false,
      error: error.message || String(error)
    };
  }
}

async function fetchJson(url, options = {}) {
  const controller = new AbortController();
  const timeoutMs = Number(options.timeoutMs ?? 15000);
  const { timeoutMs: _timeoutMs, ...fetchOptions } = options;
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  const response = await fetch(url, {
    credentials: "include",
    headers: {
      "accept": "application/json, text/plain, */*",
      "content-type": "application/json;charset=UTF-8",
      ...huxuanAccountHeader()
    },
    signal: controller.signal,
    ...fetchOptions
  }).finally(() => clearTimeout(timeoutId));
  if (!response.ok) {
    throw new Error(`腾讯互选请求失败: ${response.status}`);
  }
  const data = await response.json();
  const code = data.code ?? data.ret ?? data.errcode;
  if (code !== undefined && code !== 0 && code !== "0") {
    throw new Error(data.msg || data.message || data.errmsg || `腾讯互选接口返回异常: ${code}`);
  }
  return data;
}

function huxuanAccountHeader() {
  const accountId = extractHuxuanAdvertiserAccountId();
  return accountId ? { account_id: accountId } : {};
}

function extractHuxuanAdvertiserAccountId() {
  const pathMatch = String(location.pathname || "").match(/\/trade\/selection\/(\d+)(?:\/|$)/);
  if (pathMatch) {
    return pathMatch[1];
  }
  const textMatch = String(document.body?.innerText || "").match(/\bID[:：]\s*(\d{5,})\b/);
  return textMatch ? textMatch[1] : "";
}

function extractAppid(value) {
  try {
    const url = new URL(String(value ?? "").trim());
    return url.searchParams.get("id") || url.searchParams.get("appid") || "";
  } catch (_error) {
    const match = String(value ?? "").match(/[?&](?:id|appid)=([^&#]+)/i);
    return match ? decodeURIComponent(match[1]) : "";
  }
}

function collectObjects(value, seen = new Set(), output = []) {
  if (!value || typeof value !== "object" || seen.has(value)) {
    return output;
  }
  seen.add(value);
  if (!Array.isArray(value)) {
    output.push(value);
  }
  for (const child of Array.isArray(value) ? value : Object.values(value)) {
    collectObjects(child, seen, output);
  }
  return output;
}

function pickValue(object, keys) {
  if (!object || typeof object !== "object") {
    return null;
  }
  for (const key of keys) {
    if (object[key] !== undefined && object[key] !== null && object[key] !== "") {
      return object[key];
    }
  }
  return null;
}

function firstNonEmpty(...values) {
  return values.find((value) => value !== undefined && value !== null && String(value).trim() !== "") ?? "";
}

function normalizeUrl(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return "";
  }
  try {
    const url = new URL(text);
    url.hash = "";
    return url.toString().replace(/\/$/, "");
  } catch (_error) {
    return text.replace(/\/$/, "");
  }
}

function extractUrlTokens(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return [];
  }
  const tokens = new Set();
  try {
    const url = new URL(text);
    for (const part of url.pathname.split("/")) {
      const token = part.trim();
      if (/^[A-Za-z0-9_-]{6,}$/.test(token)) {
        tokens.add(token);
      }
    }
    for (const key of ["id", "export_id", "feedid", "feed_id", "objectId"]) {
      const token = url.searchParams.get(key);
      if (token && /^[A-Za-z0-9_-]{6,}$/.test(token)) {
        tokens.add(token);
      }
    }
  } catch (_error) {
    for (const token of text.split(/[/?#&=]+/)) {
      if (/^[A-Za-z0-9_-]{6,}$/.test(token)) {
        tokens.add(token);
      }
    }
  }
  return [...tokens];
}

function splitVisibleLines(text) {
  return String(text ?? "")
    .split(/\n+/)
    .flatMap((line) => line.split(/\s{2,}/))
    .map((line) => line.trim())
    .filter(Boolean);
}

function extractNickname(lines, appid) {
  const idIndex = lines.findIndex((line) => line.includes(appid));
  const advertiserIdIndex = findLastLineIndex(lines, (line, index) => {
    return index < idIndex && /^ID[:：]\s*\d+\s*$/.test(String(line ?? "").trim());
  });
  if (advertiserIdIndex >= 0 && advertiserIdIndex + 1 < idIndex && isLikelyNicknameLine(lines[advertiserIdIndex + 1])) {
    return lines[advertiserIdIndex + 1];
  }

  const mcnIndex = findLastLineIndex(lines, (line, index) => {
    return index < idIndex && /^MCN[:：]?$/.test(String(line ?? "").trim());
  });
  for (let index = mcnIndex - 1; index > Math.max(-1, mcnIndex - 5); index -= 1) {
    if (isLikelyNicknameLine(lines[index])) {
      return lines[index];
    }
  }

  for (let index = idIndex - 1; index >= Math.max(0, idIndex - 8); index -= 1) {
    const line = lines[index];
    if (isLikelyNicknameLine(line)) {
      return line;
    }
  }
  return extractFollowingValue(lines, /^(?:视频号昵称|达人昵称|昵称)$/);
}

function findLastLineIndex(lines, predicate) {
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    if (predicate(lines[index], index)) {
      return index;
    }
  }
  return -1;
}

function isLikelyNicknameLine(line) {
  if (!line) {
    return false;
  }
  return !/用户头像|ID[:：]|MCN[:：]|所在地域|达人类型|适合行业|粉丝量|粉丝增长|达人亮点|定制能力|个人简介|腾讯营销|有限公司|公司|客服|发布任务|达人名单|萌力互动|飞瀑互动/.test(line);
}

function extractMetricAfterLabel(lines, label) {
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    if (line === label || line.replace(/\s+/g, "") === label.replace(/\s+/g, "")) {
      return lines[index + 1] ?? null;
    }
    if (line.includes(label)) {
      const tail = line.slice(line.indexOf(label) + label.length).trim();
      if (tail) {
        return tail.split(/\s+/)[0];
      }
      return lines[index + 1] ?? null;
    }
  }
  return null;
}

function extractInlineText(text, pattern) {
  const match = String(text ?? "").replace(/\n+/g, " ").match(pattern);
  return match ? match[1].trim() : null;
}

function extractTags(lines) {
  const known = ["优秀创作者奖", "好礼推荐官", "近期有合作", "近一周有发布", "行业大咖", "视频号特色"];
  return known.filter((tag) => lines.some((line) => line.includes(tag))).join("、") || null;
}

function extractGenderProfile(text, scopeLabel = "") {
  const compact = String(text ?? "").replace(/\n+/g, " ");
  const scopeIndex = scopeLabel ? compact.indexOf(scopeLabel) : 0;
  const genderIndex = compact.indexOf("性别分布", Math.max(0, scopeIndex));
  if (genderIndex < 0) {
    return null;
  }
  const rawSection = compact.slice(genderIndex);
  const boundaryMatch = rawSection.match(/\s(?:设备分布|年龄分布|城市分布|地域分布|地区分布|兴趣分布)\s/);
  const section = boundaryMatch?.index > 0
    ? rawSection.slice(0, boundaryMatch.index)
    : rawSection.slice(0, 220);
  const pairs = [];
  const seen = new Set();
  const pushPair = (label, value) => {
    const normalizedLabel = String(label ?? "").replace("男性", "男").replace("女性", "女");
    if (!/^(男|女)$/.test(normalizedLabel) || !value || seen.has(normalizedLabel)) {
      return;
    }
    seen.add(normalizedLabel);
    pairs.push(`${normalizedLabel}:${value}`);
  };
  const labelFirst = /(男性|女性|男|女)\s*[:：]?\s*(\d+(?:\.\d+)?%)/g;
  const percentFirst = /(\d+(?:\.\d+)?%)\s*(男性|女性|男|女)/g;
  const firstLabel = section.match(/男性|女性|男|女/);
  const firstPercent = section.match(/\d+(?:\.\d+)?%/);
  const preferPercentFirst = firstPercent && firstLabel && firstPercent.index < firstLabel.index;
  const readPercentFirst = () => {
    let match;
    percentFirst.lastIndex = 0;
    while ((match = percentFirst.exec(section))) {
      pushPair(match[2], match[1]);
    }
  };
  const readLabelFirst = () => {
    let match;
    labelFirst.lastIndex = 0;
    while ((match = labelFirst.exec(section))) {
      pushPair(match[1], match[2]);
    }
  };
  if (preferPercentFirst) {
    readPercentFirst();
    if (seen.size < 2) {
      readLabelFirst();
    }
  } else {
    readLabelFirst();
    if (seen.size < 2) {
      readPercentFirst();
    }
  }
  return pairs.length ? pairs.join("、") : null;
}

function extractVisiblePublishedVideos(lines) {
  const start = lines.findIndex((line) => line === "发表视频");
  const end = lines.findIndex((line, index) => index > start && line === "受众画像");
  if (start < 0 || end <= start) {
    return [];
  }
  const section = lines.slice(start + 1, end).filter((line) => !isVideoListNoise(line));
  const videos = [];
  for (let index = 0; index < section.length; index += 1) {
    const play = readVisibleCount(section, index);
    if (!play) {
      continue;
    }
    const titleIndex = play.nextIndex;
    const title = section[titleIndex];
    if (!title || isVisibleCountStart(section, titleIndex) || isVideoListNoise(title)) {
      continue;
    }
    const thumb = readVisibleCount(section, titleIndex + 1, { allowSmallCount: true });
    const share = thumb ? readVisibleCount(section, thumb.nextIndex, { allowSmallCount: true }) : null;
    const heart = share ? readVisibleCount(section, share.nextIndex, { allowSmallCount: true }) : null;
    const comment = heart ? readVisibleCount(section, heart.nextIndex, { allowSmallCount: true }) : null;
    if (!thumb || !share || !heart || !comment) {
      continue;
    }
    videos.push({
      __source: "visible-page",
      title,
      desc: title,
      read_pv: play.value,
      fav_pv: thumb.value,
      share_pv: share.value,
      heart_pv: heart.value,
      comment_pv: comment.value
    });
    index = comment.nextIndex - 1;
  }
  return videos;
}

async function readVisiblePublishedVideosAcrossPages(performanceScope = "全部视频", maxPages = 8) {
  if (!await waitForBodyText("发表视频", 5000)) {
    return [];
  }
  await ensureVisiblePublishedVideoScope(performanceScope);
  scrollToVisibleText("发表视频");
  await sleep(300);
  let root = findPublishedVideoSectionRoot();
  if (!root) {
    return [];
  }
  root.scrollIntoView({ block: "center", inline: "nearest" });
  await sleep(300);

  const videos = [];
  const seen = new Set();
  const addVideos = (items) => {
    for (const item of items) {
      const key = [
        normalizeTitleText(item.title || item.desc),
        item.read_pv,
        item.fav_pv,
        item.share_pv,
        item.heart_pv,
        item.comment_pv
      ].join("|");
      if (!seen.has(key)) {
        seen.add(key);
        videos.push(item);
      }
    }
  };

  addVideos(extractVisiblePublishedVideosFromDom(root));

  const pageNumbers = findPublishedVideoPageNumbers(root);
  const highestKnownPage = pageNumbers.length ? Math.max(...pageNumbers) : 1;
  const pageLimit = Math.max(1, Math.min(maxPages, highestKnownPage));
  for (let step = 1; step < pageLimit; step += 1) {
    root = findPublishedVideoSectionRoot();
    const before = getPublishedVideoPageSignature(root);
    if (!clickPublishedVideoNextPage(root)) {
      const activePage = findPublishedVideoActivePage(root) || step;
      if (!clickPublishedVideoPage(activePage + 1)) {
        break;
      }
    }
    await waitForPublishedVideoPageChange(before, 3500);
    root = findPublishedVideoSectionRoot();
    addVideos(extractVisiblePublishedVideosFromDom(root));
  }

  await restorePublishedVideoFirstPage();

  return videos;
}

function findPublishedVideoSectionRoot() {
  const classMatch = [...document.querySelectorAll("section, main, article, div")]
    .filter((element) => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && /\bpost-video\b/.test(String(element.className ?? ""));
    });
  if (classMatch[0]) {
    return classMatch.reduce((best, element) => {
      if (!best) {
        return element;
      }
      const bestRect = best.getBoundingClientRect();
      const rect = element.getBoundingClientRect();
      return (rect.width * rect.height) < (bestRect.width * bestRect.height) ? element : best;
    }, null);
  }
  const headings = [...document.querySelectorAll("h1, h2, h3, h4, div, span")]
    .filter((element) => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && String(element.textContent ?? "").trim() === "发表视频";
    });
  for (const heading of headings) {
    let current = heading;
    for (let depth = 0; current && depth < 8; depth += 1) {
      const text = String(current.innerText ?? "");
      if (text.includes("发表视频") && text.includes("拇指") && text.includes("评论")) {
        return current;
      }
      current = current.parentElement;
    }
  }
  return null;
}

async function ensureVisiblePublishedVideoScope(performanceScope = "全部视频") {
  if (!await waitForBodyText("发表视频", 5000)) {
    return false;
  }
  scrollToVisibleText("发表视频");
  await sleep(300);
  const root = findPublishedVideoSectionRoot();
  if (!root) {
    return false;
  }
  const label = /互选|商单|合作/.test(String(performanceScope ?? "")) ? "互选商单案例" : "全部视频";
  const labelElement = findVisibleTextElement(label, root);
  const target = labelElement ? findClickableTextElement(label, root) : null;
  if (target && !isScopeElementSelected(labelElement)) {
    const before = getPublishedVideoPageSignature(root);
    dispatchPublishedVideoControlClick(target);
    await waitForPublishedVideoPageChange(before, 2500);
  }
  await restorePublishedVideoFirstPage();
  return true;
}

function extractVisiblePublishedVideosFromDom(root) {
  if (!root) {
    return [];
  }
  const videos = getPublishedVideoCards(root).map(readPublishedVideoCard).filter(Boolean);
  if (videos.length) {
    return videos;
  }
  const bodyLines = splitVisibleLines(document.body?.innerText ?? "");
  return extractVisiblePublishedVideos(bodyLines);
}

function getPublishedVideoCards(root) {
  if (!root) {
    return [];
  }
  return [...root.querySelectorAll(".__card")].filter((card) => {
    const text = String(card.innerText ?? "");
    return text && card.querySelector(".finder-case__metric-item, .__card-desc, .read-pv, .read-pv-item");
  });
}

function readPublishedVideoCard(card) {
  const play = cleanVisibleMetricText(
    card.querySelector(".read-pv")?.textContent ||
    card.querySelector(".read-pv-item")?.textContent ||
    ""
  );
  const title = String(card.querySelector(".__card-desc")?.textContent ?? "").replace(/\s+/g, " ").trim();
  const metrics = [...card.querySelectorAll(".finder-case__metric-item")]
    .map((item) => cleanVisibleMetricText(item.querySelector(".__data")?.textContent || item.textContent))
    .filter(Boolean);
  if (!play || !title || metrics.length < 4) {
    return null;
  }
  return {
    __source: "visible-page",
    title,
    desc: title,
    read_pv: play,
    fav_pv: metrics[0],
    share_pv: metrics[1],
    heart_pv: metrics[2],
    comment_pv: metrics[3]
  };
}

function visiblePublishedVideoKey(item) {
  return [
    normalizeTitleText(item?.title || item?.desc || ""),
    item?.read_pv ?? "",
    item?.fav_pv ?? "",
    item?.share_pv ?? "",
    item?.heart_pv ?? "",
    item?.comment_pv ?? ""
  ].join("|");
}

function cleanVisibleMetricText(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[，,]/g, "")
    .trim();
}

function findPublishedVideoPageNumbers(root) {
  const buttons = findPublishedVideoPageButtons(root);
  return [...new Set(buttons
    .map(({ page }) => page)
    .filter((page) => Number.isInteger(page) && page > 0))]
    .sort((left, right) => left - right);
}

function findPublishedVideoPaginationRoot(root) {
  if (!root) {
    return null;
  }
  const pagination = root.querySelector('[data-springen-pagination="true"]');
  if (pagination) {
    return pagination;
  }
  const pageItem = root.querySelector("[data-springen-pagination-item-page]");
  if (pageItem) {
    return pageItem.closest('[data-springen-pagination="true"]') || pageItem.parentElement;
  }
  return null;
}

function findPublishedVideoPageButtons(root) {
  const pagination = findPublishedVideoPaginationRoot(root);
  if (!pagination) {
    return [];
  }
  return [...pagination.querySelectorAll("[data-springen-pagination-item-page]")]
    .map((element) => ({
      element,
      page: Number(element.getAttribute("data-springen-pagination-item-page")),
      active: element.getAttribute("data-springen-pagination-item-active") === "true"
    }))
    .filter(({ page }) => Number.isInteger(page) && page > 0);
}

function clickPublishedVideoPage(page) {
  const root = findPublishedVideoSectionRoot();
  const target = findPublishedVideoPageButtons(root).find((button) => button.page === page)?.element;
  if (!target) {
    return false;
  }
  return dispatchPublishedVideoControlClick(target);
}

function clickPublishedVideoNextPage(root = findPublishedVideoSectionRoot()) {
  const pagination = findPublishedVideoPaginationRoot(root);
  if (!pagination) {
    return false;
  }
  const target = [...pagination.querySelectorAll('[data-springen-pagination-item-next="true"]')]
    .find((element) => !isPublishedVideoPageControlDisabled(element));
  return dispatchPublishedVideoControlClick(target);
}

function clickPublishedVideoPrevPage(root = findPublishedVideoSectionRoot()) {
  const pagination = findPublishedVideoPaginationRoot(root);
  if (!pagination) {
    return false;
  }
  const target = [...pagination.querySelectorAll('[data-springen-pagination-item-prev="true"]')]
    .find((element) => !isPublishedVideoPageControlDisabled(element));
  return dispatchPublishedVideoControlClick(target);
}

function isPublishedVideoPageControlDisabled(element) {
  if (!element) {
    return true;
  }
  return element.getAttribute("data-springen-pagination-item-disabled") === "true" ||
    element.getAttribute("aria-disabled") === "true" ||
    element.disabled === true;
}

function findPublishedVideoActivePage(root = findPublishedVideoSectionRoot()) {
  return findPublishedVideoPageButtons(root).find((button) => button.active)?.page || null;
}

async function restorePublishedVideoFirstPage() {
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const root = findPublishedVideoSectionRoot();
    const activePage = findPublishedVideoActivePage(root);
    if (activePage === 1 || !root) {
      return;
    }
    const before = getPublishedVideoPageSignature(root);
    if (clickPublishedVideoPrevPage(root) || clickPublishedVideoPage(1)) {
      await waitForPublishedVideoPageChange(before, 2000);
    } else {
      return;
    }
  }
}

function dispatchPublishedVideoControlClick(element) {
  if (!element) {
    return false;
  }
  element.scrollIntoView({ block: "center", inline: "nearest" });
  if (typeof element.focus === "function") {
    try {
      element.focus({ preventScroll: true });
    } catch (_error) {
      element.focus();
    }
  }
  const rect = element.getBoundingClientRect();
  const clientX = rect.left + rect.width / 2;
  const clientY = rect.top + rect.height / 2;
  const options = {
    bubbles: true,
    cancelable: true,
    composed: true,
    view: window,
    clientX,
    clientY,
    button: 0,
    buttons: 1
  };
  for (const type of ["mouseover", "mousemove", "mousedown", "mouseup", "click"]) {
    element.dispatchEvent(new MouseEvent(type, options));
  }
  return true;
}

async function waitForPublishedVideoPageChange(previousText, timeoutMs = 3500) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    await sleep(250);
    const root = findPublishedVideoSectionRoot();
    const text = getPublishedVideoPageSignature(root);
    if (text && text !== previousText) {
      await sleep(250);
      return true;
    }
  }
  return false;
}

function getPublishedVideoPageSignature(root) {
  if (!root) {
    return "";
  }
  const cards = getPublishedVideoCards(root)
    .slice(0, 4)
    .map(readPublishedVideoCard)
    .filter(Boolean)
    .map(visiblePublishedVideoKey);
  return `${findPublishedVideoActivePage(root) || ""}|${cards.join("||")}`;
}

function readVisibleCount(lines, index, options = {}) {
  const line = lines[index];
  const smallCount = options.allowSmallCount && /^\d{1,2}$/.test(String(line ?? "").trim());
  if (!isVisibleCountStart(lines, index) && !smallCount) {
    return null;
  }
  const next = lines[index + 1];
  if (/^万\+?$/.test(String(next ?? "").trim())) {
    return {
      value: formatVisibleCount(line, next),
      nextIndex: index + 2
    };
  }
  return {
    value: formatVisibleCount(line),
    nextIndex: index + 1
  };
}

function isVisibleCountStart(lines, index) {
  const line = String(lines[index] ?? "").trim();
  const next = String(lines[index + 1] ?? "").trim();
  return /^\d+(?:\.\d+)?万\+?$/.test(line)
    || /^\d+(?:\.\d+)?$/.test(line) && /^万\+?$/.test(next)
    || /^\d{3,}$/.test(line)
    || /^\d+(?:\.\d+)?万$/.test(line);
}

function formatVisibleCount(...parts) {
  return parts
    .filter((part) => part !== undefined && part !== null && String(part).trim() !== "")
    .join("")
    .replace(/\s+/g, "")
    .trim();
}

function isVideoListNoise(line) {
  return /^(?:\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+至\s+\d{4}[-/]\d{1,2}[-/]\d{1,2}|全部视频|互选商单案例|个人视频|互选商单|播放量|拇指赞量|转发量|爱心赞量|评论量)$/.test(String(line ?? "").trim());
}

async function readPageChartProfiles(scopeLabel = "") {
  return pageChartReader("", scopeLabel) ?? {};
}

function pageChartReader(requestId, scopeLabel = "") {
  const firstGenderProfile = (result) => {
    return Object.values(result ?? {}).find((value) => typeof value === "string" && /\d+(?:\.\d+)?\s*[:：]\s*\d+(?:\.\d+)?/.test(value));
  };
  const formatProfilePair = (name, value, total = null) => {
    const label = String(name ?? "").replace("男性", "男").replace("女性", "女").trim();
    if (!/^(男|女)$/.test(label)) {
      return "";
    }
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return "";
    }
    const percent = Number.isFinite(total) && total > 100.5
      ? (number / total) * 100
      : number > 0 && number <= 1
        ? number * 100
        : number;
    return `${label}:${Math.round(percent * 100) / 100}%`;
  };
  const nearbyText = (element) => {
    const parts = [];
    let current = element;
    for (let depth = 0; current && depth < 7; depth += 1) {
      const text = String(current.innerText ?? "").trim();
      if (text) {
        parts.push(text);
      }
      current = current.parentElement;
    }
    return parts.join(" ");
  };
  const profileFromOption = (option) => {
    const entries = [];
    const seriesList = Array.isArray(option?.series) ? option.series : [];
    for (const series of seriesList) {
      const dataList = Array.isArray(series?.data) ? series.data : [];
      for (const item of dataList) {
        if (item && typeof item === "object") {
          const name = item.name ?? item.label;
          const value = item.value ?? item.percent ?? item.ratio;
          if (formatProfilePair(name, value)) {
            entries.push({ name, value });
          }
        }
      }
    }
    const total = entries.reduce((sum, item) => {
      const value = Number(item.value);
      return Number.isFinite(value) ? sum + value : sum;
    }, 0);
    const totalForPercent = entries.length >= 2 ? total : null;
    const pairs = entries.map((item) => formatProfilePair(item.name, item.value, totalForPercent)).filter(Boolean);
    return [...new Set(pairs)].join("、");
  };
  const profileFromCanvas = (canvas) => {
    try {
      const context = canvas.getContext("2d", { willReadFrequently: true });
      if (!context) {
        return "";
      }
      const width = canvas.width;
      const height = canvas.height;
      const image = context.getImageData(0, 0, width, height).data;
      const isRingPixel = (red, green, blue, alpha) => {
        return alpha > 80 && blue > 120 && green > 80 && red < 235 && blue > red + 20;
      };
      const isDarkBlue = (red, green, blue) => {
        return blue > 160 && green > 80 && red < 140 && blue > green + 20;
      };
      let minX = width;
      let maxX = 0;
      let minY = height;
      let maxY = 0;
      let pointCount = 0;
      for (let y = 0; y < height; y += 2) {
        for (let x = 0; x < width; x += 2) {
          const offset = (y * width + x) * 4;
          const red = image[offset];
          const green = image[offset + 1];
          const blue = image[offset + 2];
          const alpha = image[offset + 3];
          if (isRingPixel(red, green, blue, alpha)) {
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
            pointCount += 1;
          }
        }
      }
      if (pointCount < 50) {
        return "";
      }
      const centerX = (minX + maxX) / 2;
      const centerY = (minY + maxY) / 2;
      const outerRadius = Math.max(maxX - minX, maxY - minY) / 2;
      const innerRadius = outerRadius * 0.55;
      let lightAngles = 0;
      let darkAngles = 0;
      for (let degree = 0; degree < 360; degree += 3) {
        const angle = (degree * Math.PI) / 180;
        let lightPixels = 0;
        let darkPixels = 0;
        for (let radius = innerRadius; radius <= outerRadius; radius += 2) {
          const x = Math.round(centerX + Math.cos(angle) * radius);
          const y = Math.round(centerY + Math.sin(angle) * radius);
          if (x < 0 || x >= width || y < 0 || y >= height) {
            continue;
          }
          const offset = (y * width + x) * 4;
          const red = image[offset];
          const green = image[offset + 1];
          const blue = image[offset + 2];
          const alpha = image[offset + 3];
          if (!isRingPixel(red, green, blue, alpha)) {
            continue;
          }
          if (isDarkBlue(red, green, blue)) {
            darkPixels += 1;
          } else {
            lightPixels += 1;
          }
        }
        if (lightPixels || darkPixels) {
          if (darkPixels > lightPixels) {
            darkAngles += 1;
          } else {
            lightAngles += 1;
          }
        }
      }
      const total = lightAngles + darkAngles;
      if (total < 40) {
        return "";
      }
      const male = Math.round((darkAngles / total) * 100);
      const female = 100 - male;
      return `男:${male}%、女:${female}%`;
    } catch (_error) {
      return "";
    }
  };
  const visibleLabelElement = (label, root = document) => {
    return [...root.querySelectorAll("h1, h2, h3, h4, button, a, div, span")]
      .find((element) => {
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && String(element.textContent ?? "").trim() === label;
      }) ?? null;
  };
  const sectionTop = (label) => {
    const target = [...document.querySelectorAll("h1, h2, h3, h4, button, a, div, span")]
      .find((element) => String(element.textContent ?? "").trim() === label);
    return target ? target.getBoundingClientRect().top : null;
  };
  const audienceRoot = findAudienceSectionRoot();
  const genderHeading = audienceRoot ? visibleLabelElement("性别分布", audienceRoot) : visibleLabelElement("性别分布");
  const deviceHeading = audienceRoot ? visibleLabelElement("设备分布", audienceRoot) : visibleLabelElement("设备分布");
  const ageHeading = audienceRoot ? visibleLabelElement("年龄分布", audienceRoot) : visibleLabelElement("年龄分布");
  const genderRect = genderHeading?.getBoundingClientRect?.() ?? null;
  const deviceRect = deviceHeading?.getBoundingClientRect?.() ?? null;
  const ageRect = ageHeading?.getBoundingClientRect?.() ?? null;
  const audienceTop = sectionTop("受众画像");
  const isGenderDistributionCanvas = (element) => {
    if (element.tagName !== "CANVAS") {
      return false;
    }
    const rect = element.getBoundingClientRect();
    if (rect.width < 80 || rect.height < 80) {
      return false;
    }
    if (!genderRect) {
      return false;
    }
    if (rect.bottom < genderRect.bottom - 10) {
      return false;
    }
    if (deviceRect && Math.abs(deviceRect.top - genderRect.top) < 120 && rect.left >= deviceRect.left - 24) {
      return false;
    }
    if (ageRect && ageRect.top > genderRect.top && rect.top >= ageRect.top - 24) {
      return false;
    }
    const maxBottom = Math.min(
      ageRect && ageRect.top > genderRect.top ? ageRect.top - 8 : Infinity,
      genderRect.bottom + 420
    );
    return rect.top <= maxBottom && rect.left >= genderRect.left - 40;
  };
  const isAudienceCanvas = (element) => {
    if (element.tagName !== "CANVAS" || audienceTop == null) {
      return false;
    }
    const rect = element.getBoundingClientRect();
    return rect.width >= 80 && rect.height >= 80 && rect.top >= audienceTop - 20 && rect.top <= audienceTop + 900;
  };
  const result = {};
  const echarts = window.echarts;
  const elements = [...document.querySelectorAll("canvas")]
    .filter((element) => isGenderDistributionCanvas(element) || (isAudienceCanvas(element) && nearbyText(element).includes("性别分布") && !nearbyText(element).includes("设备分布")))
    .sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      return (leftRect.top - rightRect.top) || (leftRect.left - rightRect.left);
    })
    .slice(0, 1);
  for (const element of elements) {
    const context = nearbyText(element);
    if (!isGenderDistributionCanvas(element) && !context.includes("性别分布")) {
      continue;
    }
    const instance = echarts?.getInstanceByDom?.(element);
    const profile = instance?.getOption ? profileFromOption(instance.getOption()) : "";
    const resolvedProfile = profile || profileFromCanvas(element);
    if (!resolvedProfile) {
      continue;
    }
    const hasFansScope = context.includes("粉丝画像");
    const hasAudienceScope = context.includes("观众画像");
    if (scopeLabel === "观众画像" || (hasAudienceScope && !hasFansScope)) {
      result.audience_gender_profile = resolvedProfile;
    } else if (scopeLabel === "粉丝画像" || (hasFansScope && !hasAudienceScope)) {
      result.fans_gender_profile = resolvedProfile;
    } else if (!result.gender_profile) {
      result.gender_profile = resolvedProfile;
    }
  }
  const fallback = result.gender_profile ?? firstGenderProfile(result);
  if (fallback && scopeLabel === "粉丝画像") {
    result.fans_gender_profile = result.fans_gender_profile ?? fallback;
  } else if (fallback && scopeLabel === "观众画像") {
    result.audience_gender_profile = result.audience_gender_profile ?? fallback;
  } else if (fallback) {
    result.gender_profile = fallback;
  }
  if (requestId) {
    window.postMessage({ source: "huxuan-chart-reader", requestId, result }, "*");
  }
  return result;
}

function sameMinute(sourceTime, targetTime) {
  const source = normalizeTimeToMinute(sourceTime);
  const target = normalizeTimeToMinute(targetTime);
  return Boolean(source && target && source === target);
}

function normalizeTimeToMinute(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return "";
  }
  const number = Number(text);
  if (Number.isFinite(number) && number > 1000000000) {
    const timestamp = number > 100000000000 ? number : number * 1000;
    return formatMinute(new Date(timestamp));
  }
  const match = text.match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})\s+(\d{1,2}):(\d{1,2})/);
  if (!match) {
    return "";
  }
  return `${match[1]}-${match[2].padStart(2, "0")}-${match[3].padStart(2, "0")} ${match[4].padStart(2, "0")}:${match[5].padStart(2, "0")}`;
}

function formatMinute(date) {
  const parts = new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).formatToParts(date).reduce((acc, part) => {
    acc[part.type] = part.value;
    return acc;
  }, {});
  return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}`;
}

function extractFollowingValue(lines, labelPattern) {
  for (let index = 0; index < lines.length; index += 1) {
    if (labelPattern.test(lines[index])) {
      return lines[index + 1] ?? null;
    }
  }
  return null;
}

function extractFollowingNumber(lines, labelPattern) {
  const value = extractFollowingValue(lines, labelPattern);
  if (!value) {
    return null;
  }
  const match = String(value).replace(/,/g, "").match(/-?\d+(?:\.\d+)?/);
  return match ? Number(match[0]) : null;
}
