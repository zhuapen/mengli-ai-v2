import "./platforms/pgy-worker.js";
import "./platforms/huxuan-worker.js";
import "./platforms/xingtu-worker.js";

chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

const UNIFIED_SOURCE = "mengli-ai-unified";
const PLATFORM_TASK_KEYS = Object.freeze({
  pgy: "mengliTasksV1",
  huxuan: "mengliHuxuanTasksV2",
  xingtu: "mengliXingtuTasksV1"
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.source !== UNIFIED_SOURCE) {
    return false;
  }

  handleUnifiedMessage(message)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});

async function handleUnifiedMessage(message) {
  switch (message.action) {
    case "pause-other-platforms":
      await pauseOtherPlatformTasks(message.platform);
      return {};
    default:
      throw new Error(`未知统一操作: ${message.action}`);
  }
}

async function pauseOtherPlatformTasks(activePlatform) {
  const now = new Date().toISOString();
  const entries = Object.entries(PLATFORM_TASK_KEYS).filter(([platform]) => platform !== activePlatform);
  const updates = {};
  for (const [platform, key] of entries) {
    const data = await chrome.storage.local.get(key);
    const tasks = data[key] ?? [];
    updates[key] = tasks.map((task) => (
      task.status === "running"
        ? {
            ...task,
            status: "paused",
            error: "已有其他平台任务开始运行，当前任务已暂停。",
            updatedAt: now
          }
        : task
    ));
  }
  if (Object.keys(updates).length) {
    await chrome.storage.local.set(updates);
  }
}
