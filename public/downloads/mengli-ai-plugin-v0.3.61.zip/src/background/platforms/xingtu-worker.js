import { XingtuAdapter } from "../../platforms/xingtu/adapter.js";
import { XingtuPageClient } from "../../platforms/xingtu/client.js";
import {
  getXingtuMetricCandidates,
  mapXingtuAccountFields,
  mapXingtuNoteFields
} from "../../platforms/xingtu/field-mapper.js";
import { XINGTU_DEFAULT_QUEUE_POLICY as DEFAULT_QUEUE_POLICY, PLATFORM, XINGTU_SUPPORTED_FIELDS } from "../../shared/constants.js";
import { appendTaskResult, clearTaskDatabase, getTaskResults, putTaskResults } from "../../shared/platforms/xingtu-task-db.js";
import { normalizeHeader } from "../../shared/table-rules.js";
import { randomInt, sleep } from "../../shared/queue.js";

const TASKS_KEY = "mengliXingtuTasksV1";
const TASK_ALARM = "mengli-xingtu-task-runner";
const ROW_COLLECT_TIMEOUT_MS = 240000;
const xingtuAdapter = new XingtuAdapter(new XingtuPageClient());

let runnerPromise = null;
let cancelToken = 0;

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.alarms.create(TASK_ALARM, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
});

chrome.runtime.onStartup?.addListener(() => {
  chrome.alarms.create(TASK_ALARM, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === TASK_ALARM) {
    resumeRunnableTask();
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.source !== "xingtu-data-collector") {
    return false;
  }

  handleMessage(message, sender)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});

async function handleMessage(message, sender) {
  switch (message.action) {
    case "trusted-click":
      return dispatchTrustedClick(sender?.tab?.id, message.payload);
    case "get-tasks":
      return { tasks: await getTasks() };
    case "create-task":
      return { task: await createTask(message.payload) };
    case "start-task":
      return { task: await startTask(message.taskId) };
    case "mark-task-downloaded":
      return { task: await markTaskDownloaded(message.taskId, message.payload) };
    case "clear-tasks":
      await clearAllTasks();
      return { tasks: [] };
    case "get-task-results":
      return { results: await getTaskResults(message.taskId) };
    default:
      throw new Error(`未知操作: ${message.action}`);
  }
}

async function dispatchTrustedClick(tabId, payload = {}) {
  const x = Number(payload.x);
  const y = Number(payload.y);
  if (!tabId || !Number.isFinite(x) || !Number.isFinite(y)) {
    throw new Error("星图真实点击参数无效");
  }

  const target = { tabId };
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mouseMoved",
      x,
      y,
      button: "none"
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x,
      y,
      button: "left",
      buttons: 1,
      clickCount: 1
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x,
      y,
      button: "left",
      buttons: 0,
      clickCount: 1
    });
    return { clicked: true };
  } finally {
    if (attached) {
      await chrome.debugger.detach(target).catch(() => {});
    }
  }
}

async function createTask(payload) {
  const name = String(payload?.name ?? "").trim();
  const plan = payload?.plan ?? [];
  if (!name) {
    throw new Error("请先填写任务名称");
  }
  if (!plan.length) {
    throw new Error("没有可抓取的任务");
  }

  const now = new Date().toISOString();
  const task = {
    id: payload.id || createId(),
    name,
    sourceFileName: payload.sourceFileName || "",
    sheetName: payload.sheetName || "",
    platform: PLATFORM.XINGTU,
    filters: payload.filters ?? null,
    status: "ready",
    progress: {
      totalRows: plan.length,
      completedRows: 0,
      currentRowIndex: null
    },
    plan,
    error: null,
    downloadFileName: null,
    downloadId: null,
    downloadedAt: null,
    createdAt: now,
    updatedAt: now
  };

  await putTaskResults(task.id, []);
  await upsertTask(task);
  await broadcastTaskUpdate(task, "created");
  return task;
}

async function startTask(taskId) {
  const task = await requireTask(taskId);
  const results = await getTaskResults(task.id);
  const completedRows = Math.min(results.length, task.plan.length);
  cancelToken += 1;
  runnerPromise = null;
  const updated = {
    ...task,
    status: "running",
    error: null,
    progress: {
      totalRows: task.plan.length,
      completedRows,
      currentRowIndex: completedRows < task.plan.length ? task.plan[completedRows].rowIndex : null
    },
    updatedAt: new Date().toISOString()
  };
  await pauseOtherRunningTasks(taskId);
  await upsertTask(updated);
  await broadcastTaskUpdate(updated, "started");
  resumeRunnableTask();
  return updated;
}

async function markTaskDownloaded(taskId, payload) {
  const task = await requireTask(taskId);
  const updated = {
    ...task,
    downloadFileName: payload?.downloadFileName ?? task.downloadFileName,
    downloadId: payload?.downloadId ?? task.downloadId ?? null,
    downloadedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  await upsertTask(updated);
  await broadcastTaskUpdate(updated, "downloaded");
  return updated;
}

async function clearAllTasks() {
  cancelToken += 1;
  runnerPromise = null;
  await chrome.alarms.clear(TASK_ALARM);
  await chrome.storage.local.set({ [TASKS_KEY]: [] });
  await clearTaskDatabase();
  await chrome.alarms.create(TASK_ALARM, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
  await broadcast({
    source: "xingtu-data-collector",
    action: "tasks-cleared"
  });
}

async function resumeRunnableTask() {
  if (runnerPromise) {
    return runnerPromise;
  }

  const tasks = await getTasks();
  const task = tasks.find((item) => item.status === "running");
  if (!task) {
    return null;
  }

  const token = cancelToken;
  runnerPromise = runTaskLoop(task.id, token).finally(() => {
    runnerPromise = null;
  });
  return runnerPromise;
}

async function runTaskLoop(taskId, token) {
  while (token === cancelToken) {
    const task = await requireTask(taskId);
    if (task.status !== "running") {
      return;
    }

    const results = await getTaskResults(task.id);
    const nextIndex = results.length;
    if (nextIndex >= task.plan.length) {
      const completed = {
        ...task,
        status: "completed",
        progress: {
          totalRows: task.plan.length,
          completedRows: task.plan.length,
          currentRowIndex: null
        },
        error: null,
        updatedAt: new Date().toISOString()
      };
      await upsertTask(completed);
      await broadcastTaskUpdate(completed, "completed");
      return;
    }

    const planItem = task.plan[nextIndex];
    await updateTask(task.id, {
      progress: {
        totalRows: task.plan.length,
        completedRows: nextIndex,
        currentRowIndex: planItem.rowIndex
      },
      updatedAt: new Date().toISOString()
    });
    await broadcastProgress(task.id, "task-start", nextIndex, task.plan.length);

    try {
      const result = await withTimeout(
        collectPlanItem(planItem),
        ROW_COLLECT_TIMEOUT_MS,
        `第 ${planItem.rowIndex + 1} 行采集超时，已停止避免任务卡住`
      );
      if (result.account?.status === "failed" || result.note?.status === "failed") {
        throw new Error(result.account?.error || result.note?.error || "星图采集失败");
      }
      await appendTaskResult(task.id, result);
      const completedRows = nextIndex + 1;
      const latest = await updateTask(task.id, {
        progress: {
          totalRows: task.plan.length,
          completedRows,
          currentRowIndex: completedRows < task.plan.length ? task.plan[completedRows].rowIndex : null
        },
        error: null,
        updatedAt: new Date().toISOString()
      });
      await broadcastProgress(task.id, "task-complete", nextIndex, task.plan.length);
      await broadcastTaskUpdate(latest, "progress");
    } catch (error) {
      const failed = await updateTask(task.id, {
        status: "failed",
        error: error.message || String(error),
        updatedAt: new Date().toISOString()
      });
      await broadcastTaskUpdate(failed, "failed");
      return;
    }

    if (nextIndex < task.plan.length - 1) {
      const delay = randomInt(DEFAULT_QUEUE_POLICY.minDelaySeconds, DEFAULT_QUEUE_POLICY.maxDelaySeconds) * 1000;
      await broadcastProgress(task.id, "task-wait", nextIndex, task.plan.length, delay);
      await sleep(delay);
    }
  }
}

async function collectPlanItem(item) {
  const collectedAt = new Date().toISOString();
  const accountFieldSet = new Set(XINGTU_SUPPORTED_FIELDS.account.map(normalizeHeader));
  const noteFieldSet = new Set(XINGTU_SUPPORTED_FIELDS.note.map(normalizeHeader));
  const accountFields = item.fields.filter((field) => accountFieldSet.has(normalizeHeader(field)));
  const noteFields = item.fields.filter((field) => noteFieldSet.has(normalizeHeader(field)));

  try {
    const rowMetrics = accountFields.length || noteFields.length
      ? await xingtuAdapter.collectRowMetrics(item.locators, accountFields, noteFields)
      : { account: null, note: null };
    const account = rowMetrics.account;
    const note = rowMetrics.note;
    const matchedNote = note?.matchedNote ?? null;
    const status = {
      status: "采集成功",
      noteStatus: noteFields.length ? (matchedNote ? "已匹配" : "未匹配") : "",
      matchConfidence: matchedNote?.matchConfidence ?? (account ? 1 : ""),
      collectedAt,
      error: matchedNote || !noteFields.length ? "" : "未找到发布链接对应作品"
    };

    const values = {
      ...(account ? mapXingtuAccountFields(account.bundle, accountFields, status) : {}),
      ...(note ? mapXingtuNoteFields(matchedNote, noteFields, status) : {})
    };
    return {
      rowIndex: item.rowIndex,
      platform: PLATFORM.XINGTU,
      values,
      account: account
        ? {
            status: account.status,
            locators: account.locators,
            fields: account.fields,
            authorId: account.authorId,
            appliedFilters: account.bundle?.appliedFilters ?? null,
            filterWarning: account.bundle?.filterWarning ?? "",
            metricCandidates: getXingtuMetricCandidates(account.bundle, matchedNote)
          }
        : null,
      note: note
        ? {
            status: note.status,
            locators: note.locators,
            fields: note.fields,
            authorId: note.authorId,
            matchedNote
          }
        : null
    };
  } catch (error) {
    const status = {
      status: "采集失败",
      noteStatus: "未匹配",
      matchConfidence: 0,
      collectedAt,
      error: error.message || String(error)
    };
    return {
      rowIndex: item.rowIndex,
      platform: PLATFORM.XINGTU,
      values: {
        ...mapXingtuAccountFields(null, accountFields, status),
        ...mapXingtuNoteFields(null, noteFields, status)
      },
      account: {
        status: "failed",
        locators: item.locators,
        fields: accountFields,
        error: status.error
      },
      note: noteFields.length
        ? {
            status: "failed",
            locators: item.locators,
            fields: noteFields,
            matchedNote: null,
            error: status.error
          }
        : null
    };
  }
}

function withTimeout(promise, timeoutMs, message) {
  let timeoutId;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error(message)), timeoutMs);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timeoutId));
}

async function getTasks() {
  const data = await chrome.storage.local.get(TASKS_KEY);
  return data[TASKS_KEY] ?? [];
}

async function requireTask(taskId) {
  const task = (await getTasks()).find((item) => item.id === taskId);
  if (!task) {
    throw new Error("任务不存在");
  }
  return task;
}

async function upsertTask(task) {
  const tasks = await getTasks();
  const index = tasks.findIndex((item) => item.id === task.id);
  const nextTasks = index >= 0
    ? tasks.map((item) => (item.id === task.id ? task : item))
    : [task, ...tasks];
  await chrome.storage.local.set({ [TASKS_KEY]: nextTasks });
  return task;
}

async function pauseOtherRunningTasks(taskId) {
  const tasks = await getTasks();
  const nextTasks = tasks.map((task) => {
    if (task.id === taskId || task.status !== "running") {
      return task;
    }

    return {
      ...task,
      status: "paused",
      error: "已有其他任务开始运行，当前任务已暂停。",
      updatedAt: new Date().toISOString()
    };
  });
  await chrome.storage.local.set({ [TASKS_KEY]: nextTasks });
}

async function updateTask(taskId, patch) {
  const task = await requireTask(taskId);
  const updated = {
    ...task,
    ...patch,
    progress: patch.progress ?? task.progress
  };
  await upsertTask(updated);
  return updated;
}

async function broadcastTaskUpdate(task, event) {
  await broadcast({
    source: "xingtu-data-collector",
    action: "task-updated",
    event,
    task
  });
}

async function broadcastProgress(taskId, stage, index, total, delayMs = 0) {
  await broadcast({
    source: "xingtu-data-collector",
    action: "task-progress",
    payload: { taskId, stage, index, total, delayMs }
  });
}

async function broadcast(message) {
  try {
    await chrome.runtime.sendMessage(message);
  } catch (_error) {
    // The side panel may be closed; task state is already persisted.
  }
}

function createId() {
  if (crypto?.randomUUID) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
