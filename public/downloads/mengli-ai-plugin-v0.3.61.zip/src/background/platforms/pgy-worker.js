import { PgyAdapter } from "../../platforms/pgy/adapter.js";
import { PgyPageClient } from "../../platforms/pgy/client.js";
import {
  getAccountMetricCandidates,
  mapAccountFields,
  mapNoteFields
} from "../../platforms/pgy/field-mapper.js";
import { DEFAULT_QUEUE_POLICY, PGY_DEFAULT_FILTERS, PGY_FILTER_LABELS, PGY_SUPPORTED_FIELDS } from "../../shared/constants.js";
import { appendTaskResult, clearTaskDatabase, getTaskResults, putTaskResults } from "../../shared/platforms/pgy-task-db.js";
import { normalizeHeader } from "../../shared/table-rules.js";
import { randomInt, sleep } from "../../shared/queue.js";

const TASKS_KEY = "mengliTasksV1";
const TASK_ALARM = "mengli-task-runner";
const pgyAdapter = new PgyAdapter(new PgyPageClient());

let runnerPromise = null;
let cancelToken = 0;

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.alarms.create(TASK_ALARM, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
});

chrome.runtime.onStartup?.addListener(() => {
  chrome.alarms.create(TASK_ALARM, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === TASK_ALARM) {
    resumeRunnableTask();
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.source !== "media-data-collector") {
    return false;
  }

  handleMessage(message)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});

async function handleMessage(message) {
  switch (message.action) {
    case "get-tasks":
      return { tasks: await getTasks() };
    case "create-task":
      return { task: await createTask(message.payload) };
    case "run-task-trial":
      return { task: await runTaskTrial(message.taskId) };
    case "start-task":
      return { task: await startTask(message.taskId) };
    case "stop-task":
      return { task: await stopTask(message.taskId) };
    case "mark-task-downloaded":
      return { task: await markTaskDownloaded(message.taskId, message.payload) };
    case "clear-tasks":
      await clearAllTasks();
      return { tasks: [] };
    case "get-task-results":
      return { results: await getTaskResults(message.taskId) };
    case "run-pgy-plan":
      return { result: await runLegacyPlan(message.payload, message.trialLimit) };
    case "resolve-publish-url":
      return { link: await resolvePublishUrl(message.payload?.publishUrl) };
    default:
      throw new Error(`未知操作: ${message.action}`);
  }
}

async function resolvePublishUrl(publishUrl) {
  const originalUrl = String(publishUrl ?? "").trim();
  if (!originalUrl) {
    return { originalUrl, resolvedUrl: "", ok: false };
  }

  if (!isXhsShortLink(originalUrl)) {
    return { originalUrl, resolvedUrl: originalUrl, ok: true };
  }

  try {
    const response = await fetch(originalUrl, {
      method: "GET",
      credentials: "omit",
      redirect: "follow"
    });
    const finalUrl = response.url || originalUrl;
    return {
      originalUrl,
      resolvedUrl: finalUrl,
      ok: finalUrl !== originalUrl && isXhsNoteUrl(finalUrl)
    };
  } catch (error) {
    return {
      originalUrl,
      resolvedUrl: originalUrl,
      ok: false,
      error: error.message || String(error)
    };
  }
}

function isXhsShortLink(value) {
  try {
    const url = new URL(String(value ?? "").trim());
    return /(^|\.)xhslink\.com$/i.test(url.hostname);
  } catch (_error) {
    return false;
  }
}

function isXhsNoteUrl(value) {
  return Boolean(extractNoteId(value));
}

function extractNoteId(publishUrl) {
  try {
    const url = new URL(String(publishUrl ?? "").trim());
    const segments = url.pathname.split("/").filter(Boolean);
    const exploreIndex = segments.indexOf("explore");
    if (exploreIndex >= 0 && segments[exploreIndex + 1]) {
      return segments[exploreIndex + 1];
    }
    return segments.find((segment) => /^[a-f0-9]{24}$/i.test(segment)) ?? "";
  } catch (_error) {
    return "";
  }
}

async function createTask(payload) {
  const name = String(payload?.name ?? "").trim();
  const plan = payload?.plan ?? [];
  if (!name) {
    throw new Error("请先填写任务名称");
  }
  if (!plan.length) {
    throw new Error("没有可抓取的任务");
  }

  const now = new Date().toISOString();
  const task = {
    id: payload.id || createId(),
    name,
    sourceFileName: payload.sourceFileName || "",
    sheetName: payload.sheetName || "",
    collectionOptions: normalizePgyFilters(payload.collectionOptions),
    status: "ready",
    progress: {
      totalRows: plan.length,
      completedRows: 0,
      currentRowIndex: null
    },
    plan,
    trialResult: null,
    error: null,
    downloadFileName: null,
    downloadId: null,
    downloadedAt: null,
    createdAt: now,
    updatedAt: now
  };

  await putTaskResults(task.id, []);
  await upsertTask(task);
  await broadcastTaskUpdate(task, "created");
  return task;
}

async function runTaskTrial(taskId) {
  const task = await requireTask(taskId);
  const result = await collectPlanItem(task.plan[0]);
  const updated = {
    ...task,
    trialResult: result,
    updatedAt: new Date().toISOString()
  };
  await upsertTask(updated);
  await broadcastTaskUpdate(updated, "trial-complete");
  return updated;
}

async function startTask(taskId) {
  const task = await requireTask(taskId);
  const results = await getTaskResults(task.id);
  const completedRows = Math.min(results.length, task.plan.length);
  const updated = {
    ...task,
    status: "running",
    error: null,
    progress: {
      totalRows: task.plan.length,
      completedRows,
      currentRowIndex: completedRows < task.plan.length ? task.plan[completedRows].rowIndex : null
    },
    updatedAt: new Date().toISOString()
  };
  await pauseOtherRunningTasks(taskId);
  await upsertTask(updated);
  await broadcastTaskUpdate(updated, "started");
  resumeRunnableTask();
  return updated;
}

async function stopTask(taskId) {
  const task = await requireTask(taskId);
  cancelToken += 1;
  const updated = {
    ...task,
    status: "paused",
    error: "用户已停止任务，可点击继续恢复。",
    progress: {
      ...task.progress,
      currentRowIndex: null
    },
    updatedAt: new Date().toISOString()
  };
  await upsertTask(updated);
  await broadcastTaskUpdate(updated, "stopped");
  return updated;
}

async function markTaskDownloaded(taskId, payload) {
  const task = await requireTask(taskId);
  const updated = {
    ...task,
    downloadFileName: payload?.downloadFileName ?? task.downloadFileName,
    downloadId: payload?.downloadId ?? task.downloadId ?? null,
    downloadedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  await upsertTask(updated);
  await broadcastTaskUpdate(updated, "downloaded");
  return updated;
}

async function clearAllTasks() {
  cancelToken += 1;
  runnerPromise = null;
  await chrome.alarms.clear(TASK_ALARM);
  await chrome.storage.local.set({ [TASKS_KEY]: [] });
  await clearTaskDatabase();
  await chrome.alarms.create(TASK_ALARM, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
  await broadcast({
    source: "media-data-collector",
    action: "tasks-cleared"
  });
}

async function resumeRunnableTask() {
  if (runnerPromise) {
    return runnerPromise;
  }

  const tasks = await getTasks();
  const task = tasks.find((item) => item.status === "running");
  if (!task) {
    return null;
  }

  const token = cancelToken;
  runnerPromise = runTaskLoop(task.id, token).finally(() => {
    runnerPromise = null;
  });
  return runnerPromise;
}

async function runTaskLoop(taskId, token) {
  while (token === cancelToken) {
    const task = await requireTask(taskId);
    if (task.status !== "running") {
      return;
    }

    const results = await getTaskResults(task.id);
    const nextIndex = results.length;
    if (nextIndex >= task.plan.length) {
      const completed = {
        ...task,
        status: "completed",
        progress: {
          totalRows: task.plan.length,
          completedRows: task.plan.length,
          currentRowIndex: null
        },
        error: null,
        updatedAt: new Date().toISOString()
      };
      await upsertTask(completed);
      await broadcastTaskUpdate(completed, "completed");
      return;
    }

    const planItem = task.plan[nextIndex];
    await updateTask(task.id, {
      progress: {
        totalRows: task.plan.length,
        completedRows: nextIndex,
        currentRowIndex: planItem.rowIndex
      },
      updatedAt: new Date().toISOString()
    });
    await broadcastProgress(task.id, "task-start", nextIndex, task.plan.length);

    try {
      const result = await collectPlanItem(planItem);
      await appendTaskResult(task.id, result);
      const completedRows = nextIndex + 1;
      const latest = await updateTask(task.id, {
        progress: {
          totalRows: task.plan.length,
          completedRows,
          currentRowIndex: completedRows < task.plan.length ? task.plan[completedRows].rowIndex : null
        },
        error: null,
        updatedAt: new Date().toISOString()
      });
      await broadcastProgress(task.id, "task-complete", nextIndex, task.plan.length);
      await broadcastTaskUpdate(latest, "progress");
    } catch (error) {
      const message = error.message || String(error);
      const paused = message.includes("未找到已打开的蒲公英页面");
      const failed = await updateTask(task.id, {
        status: paused ? "paused" : "failed",
        error: message,
        updatedAt: new Date().toISOString()
      });
      await broadcastTaskUpdate(failed, paused ? "paused" : "failed");
      return;
    }

    if (nextIndex < task.plan.length - 1) {
      const delay = randomInt(DEFAULT_QUEUE_POLICY.minDelaySeconds, DEFAULT_QUEUE_POLICY.maxDelaySeconds) * 1000;
      await broadcastProgress(task.id, "task-wait", nextIndex, task.plan.length, delay);
      await sleep(delay);
    }
  }
}

async function collectPlanItem(item) {
  const collectionOptions = normalizePgyFilters(item.collectionOptions);
  const accountFieldSet = new Set(PGY_SUPPORTED_FIELDS.account.map(normalizeHeader));
  const noteFieldSet = new Set(PGY_SUPPORTED_FIELDS.note.map(normalizeHeader));
  const accountFields = item.fields.filter((field) => accountFieldSet.has(normalizeHeader(field)));
  const noteFields = item.fields.filter((field) => noteFieldSet.has(normalizeHeader(field)));
  const rowMetrics = accountFields.length || noteFields.length
    ? await pgyAdapter.collectRowMetrics(item.locators, accountFields, noteFields, collectionOptions)
    : { account: null, note: null };
  const account = rowMetrics.account;
  const note = rowMetrics.note;
  let matchedNote = note?.matchedNote ?? null;
  let popupResult = null;
  if (note && shouldReadPopupMetrics(matchedNote, noteFields)) {
    try {
      popupResult = await pgyAdapter.collectNotePopupMetrics(item.locators, matchedNote);
      matchedNote = mergeNoteMetrics(matchedNote, popupResult?.metrics, { overwrite: true });
    } catch (error) {
      popupResult = {
        status: "failed",
        error: error.message || String(error)
      };
    }
  }
  const metricCandidates = account
    ? getAccountMetricCandidates(account.bundle, item.locators.cooperationType, collectionOptions)
    : null;
  const apiAccountValues = account ? mapAccountFields(account.bundle, item.locators.cooperationType, accountFields, collectionOptions) : {};
  const visibleAccountValues = popupResult?.accountMetrics
    ? pickRequestedVisibleAccountMetrics(popupResult.accountMetrics, accountFields)
    : {};
  const visiblePerformanceValues = account && shouldReadVisibleSelectedPerformance(accountFields)
    ? await collectVisibleSelectedPerformanceValues(item.locators, collectionOptions, accountFields, apiAccountValues)
    : {};
  const accountValues = mergeCollectedValues(
    mergeCollectedValues(apiAccountValues, visibleAccountValues),
    visiblePerformanceValues
  );
  const noteValues = note ? mapNoteFields(matchedNote, noteFields) : {};

  return {
    rowIndex: item.rowIndex,
    values: {
      ...accountValues,
      ...buildFilterValueMap(collectionOptions, accountFields),
      ...noteValues
    },
    account: account
      ? {
          status: account.status,
          locators: account.locators,
          fields: account.fields,
          userId: account.userId,
          pageCostMetrics: account.bundle?.fdPageCostMetrics ?? null,
          pageSnapshot: account.bundle?.fdPageSnapshot ?? null,
          metricCandidates,
          debugCostFields: {
            fdPageCostMetrics: metricCandidates?.["按成本字段探测"]?.fdPageCostMetrics ?? null,
            fdCostEffective: metricCandidates?.["按成本字段探测"]?.fdCostEffective ?? null
          }
        }
      : null,
    note: note
      ? {
          status: note.status,
          locators: note.locators,
          fields: note.fields,
          userId: note.userId,
          matchedNote,
          popupResult
        }
      : null
  };
}

function normalizePgyFilters(options = {}) {
  return {
    business: ["daily", "cooperation"].includes(options?.business) ? options.business : PGY_DEFAULT_FILTERS.business,
    noteType: ["all", "picture", "video"].includes(options?.noteType) ? options.noteType : PGY_DEFAULT_FILTERS.noteType,
    dateRange: ["30", "90", 30, 90].includes(options?.dateRange) ? String(options.dateRange) : PGY_DEFAULT_FILTERS.dateRange,
    traffic: ["all", "natural"].includes(options?.traffic) ? options.traffic : PGY_DEFAULT_FILTERS.traffic
  };
}

function buildFilterValueMap(options, fields = []) {
  if (!fields.some((field) => normalizeHeader(field) === normalizeHeader("数据表现口径"))) {
    return {};
  }

  return {
    "数据表现口径": [
      PGY_FILTER_LABELS.business[options.business],
      PGY_FILTER_LABELS.noteType[options.noteType],
      PGY_FILTER_LABELS.dateRange[options.dateRange],
      PGY_FILTER_LABELS.traffic[options.traffic]
    ].filter(Boolean).join(" / ")
  };
}

function shouldReadVisibleSelectedPerformance(fields = []) {
  const watched = [
    "曝光中位数",
    "阅读中位数",
    "互动中位数",
    "中位互动量",
    "外溢进店中位数",
    "外溢中位数",
    "预估cpm",
    "数据表现-预估CPM",
    "预估阅读单价",
    "数据表现-预估阅读单价",
    "预估互动单价",
    "数据表现-预估互动单价",
    "外溢进店单价",
    "数据表现-外溢进店单价",
    "中位点赞量",
    "中位收藏量",
    "中位评论量",
    "中位分享量",
    "中位关注量",
    "互动率",
    "视频完播率",
    "图文3秒阅读率",
    "千赞笔记比例",
    "百赞笔记比例"
  ];
  const requested = new Set(fields.map(normalizeHeader));
  return watched.some((field) => requested.has(normalizeHeader(field)));
}

function pickRequestedVisibleAccountMetrics(metrics, fields = []) {
  const entries = Object.entries(metrics ?? {}).filter(([, value]) => !isEmptyCollectedValue(value) && String(value).trim() !== "-");
  if (!fields.length) {
    return Object.fromEntries(entries);
  }

  const requested = new Set(fields.map(normalizeHeader));
  return Object.fromEntries(entries.filter(([field]) => requested.has(normalizeHeader(field))));
}

async function collectVisibleSelectedPerformanceValues(locators, collectionOptions, fields = [], apiValues = {}) {
  const requestedVisibleFields = fields.filter(isVisiblePerformanceField);
  if (requestedVisibleFields.length && requestedVisibleFields.every((field) => !isEmptyCollectedValue(apiValues[field]))) {
    return {};
  }
  try {
    const result = await pgyAdapter.collectVisibleSelectedPerformance(locators, collectionOptions);
    const metrics = result?.metrics ?? {};
    if (!result?.debug?.trustPageMetrics && corePerformanceValuesConflict(apiValues, metrics)) {
      return {};
    }
    const requested = new Set(fields.map(normalizeHeader));
    return Object.fromEntries(Object.entries(metrics).filter(([field, value]) => requested.has(normalizeHeader(field)) && !isEmptyCollectedValue(value)));
  } catch (_error) {
    return {};
  }
}

function isVisiblePerformanceField(field) {
  const watched = [
    "曝光中位数",
    "阅读中位数",
    "互动中位数",
    "中位互动量",
    "外溢进店中位数",
    "外溢中位数",
    "预估cpm",
    "数据表现-预估CPM",
    "预估阅读单价",
    "数据表现-预估阅读单价",
    "预估互动单价",
    "数据表现-预估互动单价",
    "外溢进店单价",
    "数据表现-外溢进店单价",
    "中位点赞量",
    "中位收藏量",
    "中位评论量",
    "中位分享量",
    "中位关注量",
    "互动率",
    "视频完播率",
    "图文3秒阅读率",
    "千赞笔记比例",
    "百赞笔记比例"
  ];
  const requested = normalizeHeader(field);
  return watched.some((item) => normalizeHeader(item) === requested);
}

function corePerformanceValuesConflict(apiValues = {}, pageValues = {}) {
  const fields = ["曝光中位数", "阅读中位数", "互动中位数"];
  let compared = 0;
  for (const field of fields) {
    const apiValue = normalizeComparableMetric(apiValues[field]);
    const pageValue = normalizeComparableMetric(pageValues[field]);
    if (apiValue === null || pageValue === null) {
      continue;
    }
    compared += 1;
    if (apiValue !== pageValue) {
      return true;
    }
  }
  return compared >= 2 ? false : true;
}

function normalizeComparableMetric(value) {
  if (isEmptyCollectedValue(value) || String(value).trim() === "-") {
    return null;
  }
  const parsed = Number(String(value).replace(/,/g, "").replace(/%$/, ""));
  return Number.isFinite(parsed) ? parsed : null;
}

function isEmptyCollectedValue(value) {
  return value === undefined || value === null || String(value).trim() === "";
}

function mergeCollectedValues(primary = {}, fallback = {}) {
  const merged = { ...primary };
  for (const [field, value] of Object.entries(fallback ?? {})) {
    if (isEmptyCollectedValue(value)) continue;
    merged[field] = value;
  }
  return merged;
}

function shouldReadPopupMetrics(note, fields = []) {
  const normalizedFields = fields.map(normalizeHeader);
  const wantedMetrics = [
    { fields: ["曝光量", "曝光"], keys: ["impNum", "exposureNum", "impressionNum"] },
    { fields: ["阅读量", "阅读"], keys: ["readNum", "readUserNum"] },
    { fields: ["点赞", "点赞量"], keys: ["likeNum", "likedCount", "likes"] },
    { fields: ["收藏", "收藏量"], keys: ["collectNum", "collectedCount", "collects"] },
    { fields: ["评论", "评论量"], keys: ["commentNum", "commentCount", "comments"] },
    { fields: ["分享", "分享量", "转发", "转发量"], keys: ["shareNum", "shareCount", "shares"] },
    { fields: ["关注", "关注量"], keys: ["followNum", "followCount", "followCnt"] },
    { fields: ["总互动", "互动量"], keys: ["interactionNum"] }
  ].filter((metric) => metric.fields.some((field) => normalizedFields.includes(normalizeHeader(field))));

  if (!wantedMetrics.length) {
    return false;
  }

  if (!note) {
    return true;
  }

  return wantedMetrics.some((metric) => !hasUsableMetric(note, metric.keys));
}

function hasUsableMetric(source, keys) {
  return keys.some((key) => {
    const value = source?.[key];
    return value !== undefined && value !== null && value !== "" && !isSuspiciousNoteMetric(value);
  });
}

function isSuspiciousNoteMetric(value) {
  const numeric = typeof value === "number"
    ? value
    : Number(String(value).replace(/,/g, ""));
  return Number.isFinite(numeric) && numeric >= 1000000;
}

async function fetchPublicNoteMetrics(publishUrl) {
  if (!publishUrl) {
    return null;
  }

  try {
    const response = await fetch(publishUrl, {
      credentials: "include",
      headers: {
        accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      }
    });
    if (!response.ok) {
      return null;
    }

    return parsePublicNoteMetrics(await response.text());
  } catch (_error) {
    return null;
  }
}

function parsePublicNoteMetrics(html) {
  const like = pickNumberFromText(html, ["likedCount", "likeCount", "likes"]);
  const collect = pickNumberFromText(html, ["collectedCount", "collectCount", "collects"]);
  const comment = pickNumberFromText(html, ["commentCount", "comments"]);
  const share = pickNumberFromText(html, ["shareCount", "shares"]);

  if ([like, collect, comment, share].every((value) => value == null)) {
    return null;
  }

  return {
    likeNum: like,
    collectNum: collect,
    commentNum: comment,
    shareNum: share
  };
}

function pickNumberFromText(text, keys) {
  for (const key of keys) {
    const match = text.match(new RegExp(`"${key}"\\s*:\\s*"?([0-9,.万wW]+)"?`, "i"));
    if (match) {
      return parseCount(match[1]);
    }
  }

  return null;
}

function parseCount(value) {
  const normalized = String(value ?? "").replace(/,/g, "").trim();
  if (!normalized) {
    return null;
  }

  if (/万|w/i.test(normalized)) {
    return Math.round(Number.parseFloat(normalized) * 10000);
  }

  const parsed = Number.parseInt(normalized, 10);
  return Number.isNaN(parsed) ? null : parsed;
}

function mergeNoteMetrics(pgyNote, extraMetrics, options = {}) {
  if (!pgyNote && !extraMetrics) {
    return null;
  }

  const merged = { ...(pgyNote ?? {}) };
  for (const [key, value] of Object.entries(extraMetrics ?? {})) {
    if (value === undefined || value === null || value === "") {
      continue;
    }
    const current = merged[key];
    if (options.overwrite || current === undefined || current === null || current === "") {
      merged[key] = value;
    }
  }

  return merged;
}

async function runLegacyPlan(plan, trialLimit = 1) {
  const results = [];
  for (const item of plan.slice(0, trialLimit)) {
    results.push(await collectPlanItem(item));
  }
  return results;
}

async function getTasks() {
  const data = await chrome.storage.local.get(TASKS_KEY);
  return data[TASKS_KEY] ?? [];
}

async function requireTask(taskId) {
  const task = (await getTasks()).find((item) => item.id === taskId);
  if (!task) {
    throw new Error("任务不存在");
  }
  return task;
}

async function upsertTask(task) {
  const tasks = await getTasks();
  const index = tasks.findIndex((item) => item.id === task.id);
  const nextTasks = index >= 0
    ? tasks.map((item) => (item.id === task.id ? task : item))
    : [task, ...tasks];
  await chrome.storage.local.set({ [TASKS_KEY]: nextTasks });
  return task;
}

async function pauseOtherRunningTasks(taskId) {
  const tasks = await getTasks();
  const nextTasks = tasks.map((task) => {
    if (task.id === taskId || task.status !== "running") {
      return task;
    }

    return {
      ...task,
      status: "paused",
      error: "已有其他任务开始运行，当前任务已暂停。",
      updatedAt: new Date().toISOString()
    };
  });
  await chrome.storage.local.set({ [TASKS_KEY]: nextTasks });
}

async function updateTask(taskId, patch) {
  const task = await requireTask(taskId);
  const updated = {
    ...task,
    ...patch,
    progress: patch.progress ?? task.progress
  };
  await upsertTask(updated);
  return updated;
}

async function broadcastTaskUpdate(task, event) {
  await broadcast({
    source: "media-data-collector",
    action: "task-updated",
    event,
    task
  });
}

async function broadcastProgress(taskId, stage, index, total, delayMs = 0) {
  await broadcast({
    source: "media-data-collector",
    action: "pgy-progress",
    payload: { taskId, stage, index, total, delayMs }
  });
}

async function broadcast(message) {
  try {
    await chrome.runtime.sendMessage(message);
  } catch (_error) {
    // The side panel may be closed; task state is already persisted.
  }
}

function createId() {
  if (crypto?.randomUUID) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
