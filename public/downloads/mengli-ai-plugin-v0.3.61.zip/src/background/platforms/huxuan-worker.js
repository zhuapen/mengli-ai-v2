import { HuxuanAdapter } from "../../platforms/huxuan/adapter.js";
import { HuxuanPageClient } from "../../platforms/huxuan/client.js";
import {
  getHuxuanMetricCandidates,
  mapHuxuanAccountFields,
  mapHuxuanNoteFields
} from "../../platforms/huxuan/field-mapper.js";
import { HUXUAN_DEFAULT_QUEUE_POLICY as DEFAULT_QUEUE_POLICY, HUXUAN_SUPPORTED_FIELDS, PLATFORM } from "../../shared/constants.js";
import { appendTaskResult, clearTaskDatabase, getTaskResults, putTaskResults } from "../../shared/platforms/huxuan-task-db.js";
import { normalizeHeader } from "../../shared/table-rules.js";
import { randomInt, sleep } from "../../shared/queue.js";

const TASKS_KEY = "mengliHuxuanTasksV2";
const TASK_ALARM = "mengli-huxuan-task-runner";
const HUXUAN_ROW_COLLECTION_TIMEOUT_MS = 180000;
const PUBLISH_METADATA_TIMEOUT_MS = 9000;
const HUXUAN_NOTE_COLLECTION_ENABLED = true;
const HUXUAN_PUBLISH_TITLE_ENRICHMENT_ENABLED = false;
const huxuanAdapter = new HuxuanAdapter(new HuxuanPageClient());
const publishMetadataCache = new Map();

let runnerPromise = null;
let cancelToken = 0;

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.alarms.create(TASK_ALARM, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
});

chrome.runtime.onStartup?.addListener(() => {
  chrome.alarms.create(TASK_ALARM, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === TASK_ALARM) {
    resumeRunnableTask();
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.source !== "huxuan-data-collector") {
    return false;
  }

  handleMessage(message, sender)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});

async function handleMessage(message, sender) {
  switch (message.action) {
    case "trusted-click":
      return dispatchTrustedClick(sender?.tab?.id, message.payload);
    case "get-tasks":
      return { tasks: await getTasks() };
    case "create-task":
      return { task: await createTask(message.payload) };
    case "start-task":
      return { task: await startTask(message.taskId) };
    case "mark-task-downloaded":
      return { task: await markTaskDownloaded(message.taskId, message.payload) };
    case "clear-tasks":
      await clearAllTasks();
      return { tasks: [] };
    case "get-task-results":
      return { results: await getTaskResults(message.taskId) };
    default:
      throw new Error(`未知操作: ${message.action}`);
  }
}

async function dispatchTrustedClick(tabId, payload = {}) {
  const x = Number(payload.x);
  const y = Number(payload.y);
  if (!tabId || !Number.isFinite(x) || !Number.isFinite(y)) {
    throw new Error("腾讯互选真实点击参数无效");
  }

  const target = { tabId };
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mouseMoved",
      x,
      y,
      button: "none"
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x,
      y,
      button: "left",
      buttons: 1,
      clickCount: 1
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x,
      y,
      button: "left",
      buttons: 0,
      clickCount: 1
    });
    return { clicked: true };
  } finally {
    if (attached) {
      await chrome.debugger.detach(target).catch(() => {});
    }
  }
}

async function createTask(payload) {
  const name = String(payload?.name ?? "").trim();
  const plan = payload?.plan ?? [];
  if (!name) {
    throw new Error("请先填写任务名称");
  }
  if (!plan.length) {
    throw new Error("没有可抓取的任务");
  }

  const now = new Date().toISOString();
  const task = {
    id: payload.id || createId(),
    name,
    sourceFileName: payload.sourceFileName || "",
    sheetName: payload.sheetName || "",
    platform: PLATFORM.HUXUAN,
    filters: payload.filters ?? null,
    status: "ready",
    progress: {
      totalRows: plan.length,
      completedRows: 0,
      currentRowIndex: null
    },
    plan,
    error: null,
    downloadFileName: null,
    downloadId: null,
    downloadedAt: null,
    createdAt: now,
    updatedAt: now
  };

  await putTaskResults(task.id, []);
  await upsertTask(task);
  await broadcastTaskUpdate(task, "created");
  return task;
}

async function startTask(taskId) {
  cancelToken += 1;
  runnerPromise = null;
  const task = await requireTask(taskId);
  if (task.status === "failed") {
    await putTaskResults(task.id, []);
  }
  const results = task.status === "failed" ? [] : await getTaskResults(task.id);
  const completedRows = Math.min(results.length, task.plan.length);
  const updated = {
    ...task,
    status: "running",
    error: null,
    progress: {
      totalRows: task.plan.length,
      completedRows,
      currentRowIndex: completedRows < task.plan.length ? task.plan[completedRows].rowIndex : null
    },
    updatedAt: new Date().toISOString()
  };
  await pauseOtherRunningTasks(taskId);
  await upsertTask(updated);
  await broadcastTaskUpdate(updated, "started");
  resumeRunnableTask();
  return updated;
}

async function markTaskDownloaded(taskId, payload) {
  const task = await requireTask(taskId);
  const updated = {
    ...task,
    downloadFileName: payload?.downloadFileName ?? task.downloadFileName,
    downloadId: payload?.downloadId ?? task.downloadId ?? null,
    downloadedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  await upsertTask(updated);
  await broadcastTaskUpdate(updated, "downloaded");
  return updated;
}

async function clearAllTasks() {
  cancelToken += 1;
  runnerPromise = null;
  await chrome.alarms.clear(TASK_ALARM);
  await chrome.storage.local.set({ [TASKS_KEY]: [] });
  await clearTaskDatabase();
  await chrome.alarms.create(TASK_ALARM, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
  await broadcast({
    source: "huxuan-data-collector",
    action: "tasks-cleared"
  });
}

async function resumeRunnableTask() {
  if (runnerPromise) {
    return runnerPromise;
  }

  const tasks = await getTasks();
  const task = tasks.find((item) => item.status === "running");
  if (!task) {
    return null;
  }

  const token = cancelToken;
  runnerPromise = runTaskLoop(task.id, token).finally(() => {
    runnerPromise = null;
  });
  return runnerPromise;
}

async function runTaskLoop(taskId, token) {
  while (token === cancelToken) {
    const task = await requireTask(taskId);
    if (task.status !== "running") {
      return;
    }

    const results = await getTaskResults(task.id);
    const nextIndex = results.length;
    if (nextIndex >= task.plan.length) {
      const completed = {
        ...task,
        status: "completed",
        progress: {
          totalRows: task.plan.length,
          completedRows: task.plan.length,
          currentRowIndex: null
        },
        error: null,
        updatedAt: new Date().toISOString()
      };
      await upsertTask(completed);
      await broadcastTaskUpdate(completed, "completed");
      return;
    }

    const planItem = task.plan[nextIndex];
    await updateTask(task.id, {
      progress: {
        totalRows: task.plan.length,
        completedRows: nextIndex,
        currentRowIndex: planItem.rowIndex
      },
      updatedAt: new Date().toISOString()
    });
    await broadcastProgress(task.id, "task-start", nextIndex, task.plan.length);

    const result = await collectPlanItem(planItem);
    await appendTaskResult(task.id, result);
    if (result.error) {
      const failed = await updateTask(task.id, {
        status: "failed",
        error: `Excel 第 ${planItem.rowIndex + 2} 行（第 ${planItem.rowIndex + 1} 条数据）采集失败：${result.error}`,
        updatedAt: new Date().toISOString()
      });
      await broadcastTaskUpdate(failed, "failed");
      return;
    }
    const completedRows = nextIndex + 1;
    const latest = await updateTask(task.id, {
      progress: {
        totalRows: task.plan.length,
        completedRows,
        currentRowIndex: completedRows < task.plan.length ? task.plan[completedRows].rowIndex : null
      },
      error: null,
      updatedAt: new Date().toISOString()
    });
    await broadcastProgress(task.id, "task-complete", nextIndex, task.plan.length);
    await broadcastTaskUpdate(latest, "progress");

    if (nextIndex < task.plan.length - 1) {
      const delay = randomInt(DEFAULT_QUEUE_POLICY.minDelaySeconds, DEFAULT_QUEUE_POLICY.maxDelaySeconds) * 1000;
      await broadcastProgress(task.id, "task-wait", nextIndex, task.plan.length, delay);
      await sleep(delay);
    }
  }
}

async function collectPlanItem(item) {
  const collectedAt = new Date().toISOString();
  const accountFieldSet = new Set(HUXUAN_SUPPORTED_FIELDS.account.map(normalizeHeader));
  const noteFieldSet = new Set(HUXUAN_SUPPORTED_FIELDS.note.map(normalizeHeader));
  const requestedNoteFields = item.fields.filter((field) => noteFieldSet.has(normalizeHeader(field)) || isLikelyNoteField(field));
  const sourcePublishUrl = normalizeHuxuanPublishUrl(item.locators?.publishUrl);
  const hasSourcePublishUrl = sourcePublishUrl !== "";
  const noteFields = HUXUAN_NOTE_COLLECTION_ENABLED && hasSourcePublishUrl ? requestedNoteFields : [];
  const accountFields = item.fields.filter((field) => !requestedNoteFields.includes(field));
  let locators = { ...item.locators, publishUrl: sourcePublishUrl };

  if (!accountFields.length && !noteFields.length) {
    return {
      rowIndex: item.rowIndex,
      platform: PLATFORM.HUXUAN,
      warning: "视频号作品数据已暂停采集",
      values: {}
    };
  }

  try {
    if (noteFields.length && HUXUAN_PUBLISH_TITLE_ENRICHMENT_ENABLED) {
      locators = await withTimeout(
        enrichLocatorsWithPublishPage(locators),
        PUBLISH_METADATA_TIMEOUT_MS,
        "发布链接标题解析超时"
      ).catch((error) => ({
        ...locators,
        publishTitleError: error.message || String(error)
      }));
    }
    const rowMetrics = accountFields.length || noteFields.length
      ? await withTimeout(
          huxuanAdapter.collectRowMetrics(locators, accountFields, noteFields),
          HUXUAN_ROW_COLLECTION_TIMEOUT_MS,
          "腾讯互选行采集超时"
        )
      : { account: null, note: null };
    const account = rowMetrics.account;
    const note = rowMetrics.note;
    const matchedNote = note?.matchedNote ?? null;
    const noteMatchError = noteFields.length && !matchedNote ? "未找到选中传播表现范围内的作品数据" : "";
    const status = {
      status: noteMatchError ? "作品未匹配" : "采集成功",
      noteStatus: noteFields.length ? (matchedNote ? "已匹配" : "未匹配") : "",
      matchConfidence: matchedNote?.matchConfidence ?? (account ? 1 : ""),
      collectedAt,
      error: noteMatchError,
      sourcePublishUrl,
      shouldWritePublishUrl: Boolean(sourcePublishUrl)
    };

    const values = {
      ...(account ? mapHuxuanAccountFields(account.bundle, accountFields, status) : {}),
      ...(note ? mapHuxuanNoteFields(matchedNote, noteFields, status) : {})
    };
    if (noteFields.length) {
      values["作品匹配状态"] = matchedNote ? "已匹配" : "未匹配";
      values["作品匹配方式"] = matchedNote?.match_method || "";
      if (!matchedNote) {
        values["作品诊断"] = buildHuxuanWorkDiagnostic(note?.bundle?.work_match_debug, noteMatchError);
      }
    }
    if (noteMatchError) {
      const partialResult = {
        rowIndex: item.rowIndex,
        platform: PLATFORM.HUXUAN,
        warning: noteMatchError,
        values,
        account: account
          ? {
              status: account.status,
              locators: account.locators,
              fields: account.fields,
              appid: account.appid,
              metricCandidates: getHuxuanMetricCandidates(account.bundle, matchedNote)
            }
          : null,
        note: note
          ? {
              status: note.status,
              locators: note.locators,
              fields: note.fields,
              appid: note.appid,
            matchedNote
          }
          : null
      };
      if (Object.keys(values).length) {
        return partialResult;
      }
      return {
        ...partialResult,
        error: noteMatchError
      };
    }
    if (!Object.keys(values).length) {
      const reason = status.error || account?.bundle?.detail?.error || account?.bundle?.videoList?.error || "本行没有采集到可写入字段";
      throw new Error(reason);
    }

    return {
      rowIndex: item.rowIndex,
      platform: PLATFORM.HUXUAN,
      values,
      account: account
        ? {
            status: account.status,
            locators: account.locators,
            fields: account.fields,
            appid: account.appid,
            metricCandidates: getHuxuanMetricCandidates(account.bundle, matchedNote)
          }
        : null,
      note: note
        ? {
            status: note.status,
            locators: note.locators,
            fields: note.fields,
            appid: note.appid,
            matchedNote
          }
        : null
    };
  } catch (error) {
    const status = {
      status: "采集失败",
      noteStatus: "未匹配",
      matchConfidence: 0,
      collectedAt,
      error: error.message || String(error)
    };
    return {
      rowIndex: item.rowIndex,
      platform: PLATFORM.HUXUAN,
      error: status.error,
      values: {
        ...mapHuxuanAccountFields(null, accountFields, status),
        ...mapHuxuanNoteFields(null, noteFields, status)
      },
      account: {
        status: "failed",
        locators,
        fields: accountFields,
        error: status.error
      },
      note: noteFields.length
        ? {
            status: "failed",
            locators,
            fields: noteFields,
            matchedNote: null,
            error: status.error
          }
        : null
    };
  }
}

function buildHuxuanWorkDiagnostic(debug, fallback = "") {
  if (!debug) {
    return fallback || "作品匹配失败，未返回诊断信息";
  }
  const parts = [
    `原因:${debug.reason || fallback || "未匹配"}`,
    `API候选:${debug.apiCandidateCount ?? 0}`,
    `页面候选:${debug.visibleCandidateCount ?? 0}`,
    `目标:${debug.target || ""}`
  ];
  if (Array.isArray(debug.targetTokens) && debug.targetTokens.length) {
    parts.push(`目标token:${debug.targetTokens.join(",")}`);
  }
  if (debug.share) {
    parts.push(`export_id:${debug.share.keyedCount ?? 0}`);
    parts.push(`已查分享链接:${debug.share.attempted ?? 0}`);
    const samples = (debug.share.samples || [])
      .map((item) => {
        const url = item.url ? item.url.replace(/^https?:\/\//, "") : "";
        return [item.exportId, url || item.error].filter(Boolean).join("=");
      })
      .filter(Boolean)
      .slice(0, 4)
      .join(" | ");
    if (samples) {
      parts.push(`样本:${samples}`);
    }
  }
  return parts.filter(Boolean).join("；").slice(0, 1000);
}

function isLikelyNoteField(field) {
  const normalized = normalizeHeader(field);
  return [
    "作品链接",
    "发布链接",
    "视频链接",
    "发布时间",
    "实际发布时间",
    "播放量",
    "大拇指点赞量",
    "点赞量",
    "转发量",
    "分享量",
    "爱心赞量",
    "收藏量",
    "评论量",
    "总互动",
    "互动量",
    "作品匹配方式",
    "匹配置信度",
    "短链标题来源",
    "短链解析错误"
  ].map(normalizeHeader).includes(normalized);
}

function normalizeHuxuanPublishUrl(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return "";
  }
  return /^https:\/\/weixin\.qq\.com\/sph\//i.test(text) ? text : "";
}

async function enrichLocatorsWithPublishPage(locators = {}) {
  if (locators.title || !locators.publishUrl || !/^https:\/\/weixin\.qq\.com\/sph\//i.test(String(locators.publishUrl))) {
    return locators;
  }
  const cacheKey = normalizeHuxuanPublishUrl(locators.publishUrl);
  if (publishMetadataCache.has(cacheKey)) {
    const cached = publishMetadataCache.get(cacheKey);
    return cached.title
      ? {
          ...locators,
          title: cached.title,
          publishTitle: cached.title,
          publishTitleSource: cached.source || "cache"
        }
      : {
          ...locators,
          publishTitleError: cached.error || "视频号短链未解析到标题"
        };
  }
  const metadata = await resolveWeixinSphMetadata(locators.publishUrl);
  publishMetadataCache.set(cacheKey, metadata);
  if (!metadata.title) {
    return {
      ...locators,
      publishTitleError: metadata.error || "视频号短链未解析到标题"
    };
  }
  return {
    ...locators,
    title: metadata.title,
    publishTitle: metadata.title,
    publishTitleSource: metadata.source || "unknown"
  };
}

async function resolveWeixinSphMetadata(url) {
  if (/^https:\/\/weixin\.qq\.com\/sph\//i.test(String(url ?? ""))) {
    return await withTimeout(resolveWeixinSphMetadataFromTab(url), 8000, "视频号短链临时页解析超时");
  }

  let title = "";
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const response = await fetch(url, {
      credentials: "include",
      redirect: "follow",
      signal: controller.signal,
      headers: {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      }
    }).finally(() => clearTimeout(timer));
    if (!response.ok) {
      return await resolveWeixinSphMetadataFromTab(url);
    }
    const html = await response.text();
    title = cleanPublishTitle(
      extractHtmlMeta(html, "og:title")
      || extractHtmlMeta(html, "twitter:title")
      || extractHtmlMeta(html, "description")
      || extractHtmlTitle(html)
    );
  } catch (_error) {
    return await resolveWeixinSphMetadataFromTab(url);
  }
  if (isGenericWeixinTitle(title)) {
    return await resolveWeixinSphMetadataFromTab(url);
  }
  return { title, source: "html" };
}

function extractHtmlMeta(html, property) {
  const escaped = property.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const text = String(html ?? "");
  const direct = text.match(new RegExp(`<meta[^>]+(?:property|name)=["']${escaped}["'][^>]+content=["']([^"']+)["'][^>]*>`, "i"));
  if (direct) {
    return decodeHtml(direct[1]);
  }
  const reversed = text.match(new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${escaped}["'][^>]*>`, "i"));
  return reversed ? decodeHtml(reversed[1]) : "";
}

function extractHtmlTitle(html) {
  const match = String(html ?? "").match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return match ? decodeHtml(match[1]) : "";
}

function decodeHtml(value) {
  return String(value ?? "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'")
    .replace(/&#(\d+);/g, (_all, code) => String.fromCharCode(Number(code)))
    .trim();
}

function cleanPublishTitle(value) {
  return String(value ?? "")
    .replace(/\s*[-_｜|]\s*(?:微信视频号|视频号|微信)\s*$/i, "")
    .replace(/\s+/g, " ")
    .trim();
}

async function resolveWeixinSphMetadataFromTab(url) {
  let tabId = null;
  try {
    const tab = await chrome.tabs.create({ url, active: false });
    tabId = tab.id;
    await waitForTabLoadSettled(tabId, 3500);
    return await pollWeixinSphPageMetadata(tabId, 3000);
  } catch (error) {
    return { error: error.message || String(error) };
  } finally {
    if (tabId) {
      await chrome.tabs.remove(tabId).catch(() => {});
    }
  }
}

async function pollWeixinSphPageMetadata(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastTitle = "";
  let lastError = "";
  while (Date.now() < deadline) {
    try {
      const [result] = await withTimeout(chrome.scripting.executeScript({
        target: { tabId },
        func: readWeixinSphPageMetadata
      }), 5000, "视频号短链页面脚本读取超时");
      const pageMetadata = result?.result ?? {};
      const title = cleanPublishTitle(pageMetadata.title || "");
      lastTitle = title || lastTitle;
      if (!isGenericWeixinTitle(title)) {
        return { title, source: pageMetadata.source || "tab" };
      }
    } catch (error) {
      lastError = error.message || String(error);
    }
    await delay(700);
  }
  if (lastTitle) {
    return { error: `临时标签标题无效：${lastTitle}` };
  }
  return { error: lastError || "临时标签未解析到有效标题" };
}

function waitForTabLoadSettled(tabId, timeoutMs) {
  return new Promise((resolve) => {
    const timer = setTimeout(done, timeoutMs);
    function done() {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      setTimeout(resolve, 800);
    }
    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        done();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") {
        done();
      }
    }).catch(done);
  });
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function withTimeout(promise, timeoutMs, message) {
  let timerId;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timerId = setTimeout(() => reject(new Error(message)), timeoutMs);
    })
  ]).finally(() => clearTimeout(timerId));
}

function readWeixinSphPageMetadata() {
  const meta = (name) => document.querySelector(`meta[property="${name}"], meta[name="${name}"]`)?.getAttribute("content") || "";
  const textTitle = [...document.querySelectorAll([
      "h1",
      "h2",
      "[class*='title']",
      "[class*='desc']",
      "[class*='content']",
      "[class*='caption']",
      "[class*='feed']"
    ].join(", "))]
    .map((element) => String(element.textContent || "").trim())
    .find((text) => text.length > 5 && !/^(微信|视频号|WeChat)$/i.test(text.slice(0, 12)));
  const title = meta("og:title")
    || meta("twitter:title")
    || meta("description")
    || textTitle
    || document.title
    || "";
  return {
    title,
    source: title === textTitle ? "tab-text" : "tab-meta"
  };
}

function isGenericWeixinTitle(value) {
  const text = String(value ?? "").trim();
  return !text || /^(微信|微信视频号|视频号|WeChat)$/i.test(text) || text.length < 4;
}

async function getTasks() {
  const data = await chrome.storage.local.get(TASKS_KEY);
  return data[TASKS_KEY] ?? [];
}

async function requireTask(taskId) {
  const task = (await getTasks()).find((item) => item.id === taskId);
  if (!task) {
    throw new Error("任务不存在");
  }
  return task;
}

async function upsertTask(task) {
  const tasks = await getTasks();
  const index = tasks.findIndex((item) => item.id === task.id);
  const nextTasks = index >= 0
    ? tasks.map((item) => (item.id === task.id ? task : item))
    : [task, ...tasks];
  await chrome.storage.local.set({ [TASKS_KEY]: nextTasks });
  return task;
}

async function pauseOtherRunningTasks(taskId) {
  const tasks = await getTasks();
  const nextTasks = tasks.map((task) => {
    if (task.id === taskId || task.status !== "running") {
      return task;
    }

    return {
      ...task,
      status: "paused",
      error: "已有其他任务开始运行，当前任务已暂停。",
      updatedAt: new Date().toISOString()
    };
  });
  await chrome.storage.local.set({ [TASKS_KEY]: nextTasks });
}

async function updateTask(taskId, patch) {
  const task = await requireTask(taskId);
  const updated = {
    ...task,
    ...patch,
    progress: patch.progress ?? task.progress
  };
  await upsertTask(updated);
  return updated;
}

async function broadcastTaskUpdate(task, event) {
  await broadcast({
    source: "huxuan-data-collector",
    action: "task-updated",
    event,
    task
  });
}

async function broadcastProgress(taskId, stage, index, total, delayMs = 0) {
  await broadcast({
    source: "huxuan-data-collector",
    action: "task-progress",
    payload: { taskId, stage, index, total, delayMs }
  });
}

async function broadcast(message) {
  try {
    await chrome.runtime.sendMessage(message);
  } catch (_error) {
    // The side panel may be closed; task state is already persisted.
  }
}

function createId() {
  if (crypto?.randomUUID) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
