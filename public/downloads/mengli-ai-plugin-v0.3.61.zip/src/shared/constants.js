export const PLATFORM = Object.freeze({
  PGY: "pgy",
  HUXUAN: "huxuan",
  XINGTU: "xingtu"
});

export const HEADER_COLOR_RULES = Object.freeze({
  FORCE_COLLECT_RGB: ["FFFF0000", "00FF0000"]
});

export const DEFAULT_QUEUE_POLICY = Object.freeze({
  minDelaySeconds: 0.8,
  maxDelaySeconds: 1.8,
  retryCount: 2,
  retryMinDelaySeconds: 0.8,
  retryMaxDelaySeconds: 2
});

export const HUXUAN_DEFAULT_QUEUE_POLICY = Object.freeze({
  minDelaySeconds: 0.8,
  maxDelaySeconds: 1.8,
  retryCount: 2,
  retryMinDelaySeconds: 1,
  retryMaxDelaySeconds: 3
});

export const XINGTU_DEFAULT_QUEUE_POLICY = Object.freeze({
  minDelaySeconds: 0.1,
  maxDelaySeconds: 0.3,
  retryCount: 2,
  retryMinDelaySeconds: 0.5,
  retryMaxDelaySeconds: 1.2
});

export const DEFAULT_TRIAL_LIMIT = 1;

export const PGY_DEFAULT_FILTERS = Object.freeze({
  business: "daily",
  noteType: "all",
  dateRange: "30",
  traffic: "all"
});

export const PGY_FILTER_LABELS = Object.freeze({
  business: {
    daily: "日常笔记",
    cooperation: "合作笔记"
  },
  noteType: {
    all: "图文+视频",
    picture: "图文",
    video: "视频"
  },
  dateRange: {
    30: "近30日",
    90: "近90日"
  },
  traffic: {
    all: "全流量",
    natural: "仅自然流量"
  }
});

export const PGY_SUPPORTED_FIELDS = Object.freeze({
  account: [
    "内容类目",
    "账号行业",
    "粉丝量/w",
    "粉丝量",
    "达人id",
    "达人ID",
    "小红书号",
    "达人昵称",
    "昵称",
    "蒲公英主页",
    "蒲公英链接",
    "蒲公英主页链接",
    "小红书主页",
    "小红书链接",
    "主页链接",
    "平台裸价",
    "平台报价（含10%服务费）",
    "图文报价",
    "视频报价",
    "曝光中位数",
    "阅读中位数",
    "互动中位数",
    "中位互动量",
    "外溢进店中位数",
    "外溢中位数",
    "cpm",
    "cpe",
    "预估cpm",
    "预估阅读单价",
    "预估互动单价",
    "外溢进店单价",
    "预估cpm（图文）",
    "预估cpm（视频）",
    "预估阅读单价（图文）",
    "预估阅读单价（视频）",
    "预估互动单价（图文）",
    "预估互动单价（视频）",
    "预估外溢进店单价（图文）",
    "预估外溢进店单价（视频）",
    "数据表现口径",
    "数据表现-预估CPM",
    "数据表现-预估阅读单价",
    "数据表现-预估互动单价",
    "数据表现-外溢进店单价",
    "中位点赞量",
    "中位收藏量",
    "中位评论量",
    "中位分享量",
    "中位关注量",
    "互动率",
    "视频完播率",
    "图文3秒阅读率",
    "千赞笔记比例",
    "百赞笔记比例"
  ],
  note: [
    "曝光量",
    "转长链接",
    "长链接",
    "发布长链接",
    "阅读量",
    "点赞",
    "点赞量",
    "收藏",
    "收藏量",
    "评论",
    "评论量",
    "转发",
    "转发量",
    "分享",
    "分享量",
    "关注",
    "关注量",
    "总互动"
  ]
});

export const HUXUAN_SUPPORTED_FIELDS = Object.freeze({
  account: [
    "平台",
    "达人昵称",
    "视频号昵称",
    "达人ID",
    "互选ID",
    "视频号ID",
    "互选appid",
    "主页链接",
    "互选链接",
    "内容类目",
    "账号标签",
    "联系方式（微信）",
    "微信联系方式",
    "微信号",
    "账号简介",
    "认证信息",
    "粉丝量",
    "1-60s价格",
    "60s以上价格",
    "平均播放量",
    "播放中位数",
    "预期CPM",
    "完播率",
    "互动率",
    "预期CPE",
    "平均拇指赞量",
    "平均转发量",
    "平均爱心赞量",
    "平均评论量",
    "粉丝性别画像",
    "观众性别画像",
    "粉丝画像",
    "观众画像",
    "画像采集错误"
  ],
  note: [
    "作品链接",
    "发布时间",
    "播放量",
    "大拇指点赞量",
    "转发量",
    "爱心赞量",
    "评论量",
    "总互动",
    "作品匹配方式",
    "匹配置信度",
    "短链标题来源",
    "短链解析错误"
  ]
});

export const XINGTU_SUPPORTED_FIELDS = Object.freeze({
  account: [
    "达人昵称",
    "达人id",
    "达人账号ID",
    "星图达人ID",
    "达人星图ID",
    "抖音号",
    "主页链接",
    "达人主页链接",
    "星图链接",
    "达人星图链接",
    "内容类目",
    "账号行业",
    "MCN名称",
    "粉丝量/w",
    "粉丝量",
    "粉丝数",
    "报价",
    "平台裸价",
    "平台报价（含10%服务费）",
    "1-20S视频价格",
    "21-60S视频价格",
    "60S以上视频价格",
    "图文报价",
    "视频报价",
    "预期CPM",
    "预估cpm",
    "cpm",
    "预期CPE",
    "预期播放量",
    "预期互动量",
    "性价比",
    "性价比指数",
    "效果预估",
    "预估播放量",
    "预估互动量",
    "预估点赞量",
    "预估评论量",
    "预估收藏量",
    "种草价值",
    "种草指数",
    "预估种草播放量",
    "GPM",
    "千次播放成交金额",
    "组件点击率",
    "购物车点击率",
    "转化率",
    "互动率",
    "完播率",
    "播放量中位数",
    "播放中位数",
    "发布作品",
    "平均时长",
    "点赞中位数",
    "评论中位数",
    "分享中位数",
    "收藏中位数",
    "平均播放量",
    "平均点赞",
    "平均点赞量",
    "平均评论",
    "平均评论量",
    "平均转发",
    "平均分享量",
    "平均收藏量",
    "爆文率",
    "商单视频平均看后搜次数",
    "商单视频看后搜率",
    "商单视频小蓝词点击率",
    "个人视频平均看后搜次数",
    "个人视频看后搜率",
    "个人视频小蓝词点击率",
    "A3增长数",
    "进店成本",
    "粉丝画像",
    "粉丝性别",
    "粉丝年龄",
    "粉丝城市",
    "星图采集状态",
    "采集状态",
    "匹配置信度",
    "最近采集时间",
    "错误原因"
  ],
  note: [
    "作品标题",
    "笔记标题",
    "视频标题",
    "作品链接",
    "发布链接",
    "抖音作品链接",
    "实际发布时间",
    "发布时间",
    "播放量",
    "曝光量",
    "阅读量",
    "点赞",
    "点赞量",
    "收藏",
    "收藏量",
    "评论",
    "评论量",
    "分享",
    "分享量",
    "转发",
    "转发量",
    "总互动",
    "互动量",
    "作品完播率",
    "平均播放时长",
    "作品类型",
    "作品匹配状态",
    "采集状态",
    "匹配置信度",
    "最近采集时间",
    "错误原因"
  ]
});

export const LOCATOR_FIELDS = Object.freeze({
  account: ["达人昵称", "昵称", "达人id", "达人ID", "id", "小红书号", "主页链接", "小红书主页", "小红书链接", "蒲公英主页", "蒲公英链接", "蒲公英主页链接"],
  note: ["发布链接", "实际发布时间"]
});

export const HUXUAN_LOCATOR_FIELDS = Object.freeze({
  account: ["达人昵称", "视频号昵称", "达人ID", "互选ID", "视频号ID", "互选appid", "主页链接", "互选链接"],
  note: ["发布链接", "作品链接", "实际发布时间", "发布时间"]
});

export const XINGTU_LOCATOR_FIELDS = Object.freeze({
  account: ["达人昵称", "达人id", "达人账号ID", "抖音号", "星图达人ID", "达人星图ID", "主页链接", "达人主页链接", "星图链接", "达人星图链接"],
  note: ["发布链接", "抖音作品链接", "作品链接", "实际发布时间"]
});
