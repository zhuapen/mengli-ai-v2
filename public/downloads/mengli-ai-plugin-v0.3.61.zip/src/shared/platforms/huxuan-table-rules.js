import {
  HUXUAN_SUPPORTED_FIELDS,
  HUXUAN_LOCATOR_FIELDS as LOCATOR_FIELDS,
  PLATFORM
} from "../constants.js";

const HUXUAN_NOTE_COLLECTION_ENABLED = true;

export function normalizeHeader(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[()]/g, (token) => (token === "(" ? "（" : "）"))
    .toLowerCase()
    .trim();
}

export function buildHeaderIndex(headers) {
  return headers.reduce((acc, header, index) => {
    const entry = {
      index,
      ...header,
      normalizedName: normalizeHeader(header.name)
    };
    for (const alias of headerAliases(header.name)) {
      acc[alias] = entry;
    }
    return acc;
  }, {});
}

export function extractRowLocators(row, headerIndex) {
  const pick = (field) => {
    const header = headerIndex[normalizeHeader(field)];
    return header ? row[header.index] : undefined;
  };
  const publishUrl = firstValidPublishUrl(
    pick("发布链接"),
    pick("作品链接"),
    pick("视频链接")
  );

  return {
    nickname: pick("达人昵称") || pick("视频号昵称") || pick("昵称"),
    finderId: pick("达人ID") || pick("达人id") || pick("互选ID") || pick("互选id") || pick("互选号") || pick("视频号ID") || pick("视频号id") || pick("视频号") || pick("互选appid") || pick("appid") || pick("appId"),
    appid: pick("达人ID") || pick("达人id") || pick("互选ID") || pick("互选id") || pick("互选号") || pick("视频号ID") || pick("视频号id") || pick("视频号") || pick("互选appid") || pick("appid") || pick("appId"),
    profileUrl: pick("主页链接") || pick("视频号主页") || pick("视频号链接"),
    huxuanProfileUrl: pick("互选链接") || pick("互选主页") || pick("互选达人链接"),
    publishUrl,
    publishedAt: pick("实际发布时间") || pick("发布时间"),
    title: pick("作品标题") || pick("视频标题"),
    performanceScope: pick("传播表现筛选") || pick("传播表现口径"),
    audienceScope: pick("受众画像筛选") || pick("受众画像口径")
  };
}

function firstValidPublishUrl(...values) {
  return values.map(normalizePublishUrl).find(Boolean) || "";
}

function normalizePublishUrl(value) {
  const text = String(value ?? "").trim();
  if (!text) {
    return "";
  }
  return /^https:\/\/weixin\.qq\.com\/sph\//i.test(text) ? text : "";
}

export function buildCollectPlan(headers, rows, extraFields = []) {
  const headerIndex = buildHeaderIndex(headers);
  const accountFields = new Set(HUXUAN_SUPPORTED_FIELDS.account.map(normalizeHeader));
  const noteFields = new Set(HUXUAN_SUPPORTED_FIELDS.note.map(normalizeHeader));
  const normalizedExtraFields = extraFields
    .filter((field) => accountFields.has(normalizeHeader(field)) || (HUXUAN_NOTE_COLLECTION_ENABLED && noteFields.has(normalizeHeader(field))));

  return rows.map((row, rowIndex) => {
    const locators = extractRowLocators(row, headerIndex);
    const hasPublishUrl = !isBlank(locators.publishUrl);
    const hasNoteLocator = HUXUAN_NOTE_COLLECTION_ENABLED && (hasPublishUrl || !isBlank(locators.publishedAt) || !isBlank(locators.title));
    const hasAccountLocatorValue = hasAccountLocator(locators);
    if (!hasAccountLocatorValue && !hasNoteLocator) {
      return null;
    }
    const canCollectNoteFields = HUXUAN_NOTE_COLLECTION_ENABLED && hasNoteLocator;
    const fields = new Set(headers
      .filter((header) => {
        const normalizedName = normalizedHeaderName(header);
        const knownAccountField = isSupportedField(normalizedName, accountFields);
        const knownNoteField = isSupportedField(normalizedName, noteFields) || isLikelyNoteField(normalizedName);
        const shouldCollect = isBlank(row[header.index])
          || knownAccountField
          || (knownNoteField && canCollectNoteFields && shouldRefreshNoteField(normalizedName));
        const isNoteField = noteFields.has(normalizedName) || isLikelyNoteField(normalizedName);
        const isAccountLocator = isLocatorField(normalizedName, "account");
        const isAccountField = !isNoteField && (!isLocatorField(normalizedName) || (isAccountLocator && hasAccountLocatorValue));
        return shouldCollect && (isAccountField || (HUXUAN_NOTE_COLLECTION_ENABLED && isNoteField && canCollectNoteFields));
      })
      .map((header) => header.name));

    if (hasAccountLocator(locators)) {
      for (const field of normalizedExtraFields) {
        if (accountFields.has(normalizeHeader(field)) || (HUXUAN_NOTE_COLLECTION_ENABLED && noteFields.has(normalizeHeader(field)) && canCollectNoteFields)) {
          fields.add(field);
        }
      }
    }

    return {
      rowIndex,
      platform: PLATFORM.HUXUAN,
      locators,
      fields: [...fields]
    };
  }).filter((item) => item && item.fields.length > 0);
}

export function isBlank(value) {
  return value === null || value === undefined || String(value).trim() === "";
}

export function requiredLocatorGroups() {
  return LOCATOR_FIELDS;
}

function normalizedHeaderName(header) {
  return header.normalizedName ?? normalizeHeader(header.name);
}

function headerAliases(value) {
  const normalized = normalizeHeader(value);
  const aliases = new Set([normalized]);
  for (const part of String(value ?? "").split(/[（(）)、/\\|]+/)) {
    const alias = normalizeHeader(part);
    if (alias) {
      aliases.add(alias);
    }
  }
  const beforeParen = normalizeHeader(String(value ?? "").replace(/[（(].*$/, ""));
  if (beforeParen) {
    aliases.add(beforeParen);
  }
  return [...aliases];
}

function hasAccountLocator(locators) {
  return [
    locators.nickname,
    locators.finderId,
    locators.appid,
    locators.huxuanProfileUrl,
    locators.profileUrl
  ].some((value) => !isBlank(value));
}

function isLocatorField(normalizedName, group = "") {
  const fields = group && LOCATOR_FIELDS[group]
    ? LOCATOR_FIELDS[group]
    : LOCATOR_FIELDS.account.concat(LOCATOR_FIELDS.note);
  return fields
    .map(normalizeHeader)
    .includes(normalizedName);
}

function isLikelyNoteField(normalizedName) {
  return [
    "作品链接",
    "发布链接",
    "视频链接",
    "发布时间",
    "实际发布时间",
    "播放量",
    "大拇指点赞量",
    "点赞量",
    "转发量",
    "分享量",
    "爱心赞量",
    "收藏量",
    "评论量",
    "总互动",
    "互动量",
    "作品匹配方式",
    "匹配置信度",
    "短链标题来源",
    "短链解析错误"
  ].map(normalizeHeader).includes(normalizedName);
}

function shouldRefreshNoteField(normalizedName) {
  return ![
    "作品链接",
    "发布链接",
    "视频链接"
  ].map(normalizeHeader).includes(normalizedName);
}

function isSupportedField(normalizedName, supportedFields) {
  if (supportedFields.has(normalizedName)) {
    return true;
  }
  for (const field of supportedFields) {
    if (normalizedName.includes(field)) {
      return true;
    }
  }
  return false;
}
