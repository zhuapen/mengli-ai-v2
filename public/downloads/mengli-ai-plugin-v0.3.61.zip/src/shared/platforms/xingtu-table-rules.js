import {
  HEADER_COLOR_RULES,
  XINGTU_LOCATOR_FIELDS as LOCATOR_FIELDS,
  PLATFORM,
  XINGTU_SUPPORTED_FIELDS
} from "../constants.js";

export function normalizeHeader(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[()]/g, (token) => (token === "(" ? "（" : "）"))
    .toLowerCase()
    .trim();
}

export function isForcedHeader(fillRgb) {
  if (!fillRgb) {
    return false;
  }

  return HEADER_COLOR_RULES.FORCE_COLLECT_RGB.includes(String(fillRgb).toUpperCase());
}

export function buildHeaderIndex(headers) {
  return headers.reduce((acc, header, index) => {
    acc[normalizeHeader(header.name)] = {
      index,
      ...header,
      normalizedName: normalizeHeader(header.name)
    };
    return acc;
  }, {});
}

export function extractRowLocators(row, headerIndex) {
  const pick = (field) => {
    const header = headerIndex[normalizeHeader(field)];
    return header ? row[header.index] : undefined;
  };

  return {
    nickname: pick("达人昵称"),
    creatorId: pick("达人id") || pick("达人账号ID"),
    douyinId: pick("抖音号"),
    xingtuAuthorId: pick("星图达人ID") || pick("达人星图ID") || pick("o_author_id"),
    profileUrl: pick("主页链接") || pick("达人主页链接") || pick("抖音主页链接"),
    xingtuProfileUrl: pick("星图链接") || pick("达人星图链接") || pick("星图主页链接") || pick("星图达人链接"),
    publishUrl: pick("发布链接") || pick("抖音作品链接") || pick("作品链接"),
    publishedAt: pick("实际发布时间") || pick("发布时间"),
    title: pick("作品标题") || pick("笔记标题") || pick("视频标题"),
    contentDataRange: pick("内容数据范围") || pick("商业能力数据范围") || pick("数据范围"),
    contentVideoType: pick("内容视频类型") || pick("内容数据视频类型"),
    onlyAssigned: pick("只看指派"),
    contentExcludeMarketing: pick("内容排除营销流量") || pick("排除营销流量"),
    estimateVideoType: pick("效果预估视频类型") || pick("预估视频类型") || pick("视频类型"),
    estimateExcludeMarketing: pick("预估排除营销流量") || pick("效果预估排除营销流量"),
    plantingDataRange: pick("种草价值数据范围") || pick("种草数据范围")
  };
}

export function buildCollectPlan(headers, rows, extraFields = []) {
  const headerIndex = buildHeaderIndex(headers);
  const accountFields = new Set(XINGTU_SUPPORTED_FIELDS.account.map(normalizeHeader));
  const noteFields = new Set(XINGTU_SUPPORTED_FIELDS.note.map(normalizeHeader));
  const normalizedExtraFields = extraFields
    .filter((field) => accountFields.has(normalizeHeader(field)) || noteFields.has(normalizeHeader(field)));

  return rows.map((row, rowIndex) => {
    const locators = extractRowLocators(row, headerIndex);
    const hasPublishUrl = !isBlank(locators.publishUrl);
    const fields = new Set(headers
      .filter((header) => accountFields.has(normalizedHeaderName(header)) || noteFields.has(normalizedHeaderName(header)))
      .filter((header) => {
        const normalizedName = normalizedHeaderName(header);
        const shouldCollect = isForcedHeader(header.fillRgb) || isBlank(row[header.index]);
        const isAccountField = accountFields.has(normalizedName);
        const isNoteField = noteFields.has(normalizedName);

        return shouldCollect && (isAccountField || (isNoteField && hasPublishUrl));
      })
      .map((header) => header.name));

    if (hasAccountLocator(locators)) {
      for (const field of normalizedExtraFields) {
        if (accountFields.has(normalizeHeader(field)) || (noteFields.has(normalizeHeader(field)) && hasPublishUrl)) {
          fields.add(field);
        }
      }
    }

    return {
      rowIndex,
      platform: PLATFORM.XINGTU,
      locators,
      fields: [...fields]
    };
  }).filter((item) => item.fields.length > 0);
}

export function isBlank(value) {
  return value === null || value === undefined || String(value).trim() === "";
}

export function requiredLocatorGroups() {
  return LOCATOR_FIELDS;
}

function normalizedHeaderName(header) {
  return header.normalizedName ?? normalizeHeader(header.name);
}

function hasAccountLocator(locators) {
  return [
    locators.nickname,
    locators.creatorId,
    locators.douyinId,
    locators.xingtuAuthorId,
    locators.xingtuProfileUrl,
    locators.profileUrl
  ].some((value) => !isBlank(value));
}
