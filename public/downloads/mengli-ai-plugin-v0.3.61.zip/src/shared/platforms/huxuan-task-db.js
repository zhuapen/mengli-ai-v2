const DB_NAME = "mengli-ai-huxuan-task-db-v2";
const DB_VERSION = 1;
const SOURCE_STORE = "sources";
const RESULT_STORE = "results";

let dbPromise = null;

export async function putTaskSource(taskId, source) {
  const db = await openTaskDb();
  await putRecord(db, SOURCE_STORE, { taskId, ...source });
}

export async function getTaskSource(taskId) {
  const db = await openTaskDb();
  return getRecord(db, SOURCE_STORE, taskId);
}

export async function putTaskResults(taskId, results) {
  const db = await openTaskDb();
  await putRecord(db, RESULT_STORE, { taskId, results });
}

export async function getTaskResults(taskId) {
  const db = await openTaskDb();
  const record = await getRecord(db, RESULT_STORE, taskId);
  return record?.results ?? [];
}

export async function appendTaskResult(taskId, result) {
  const results = await getTaskResults(taskId);
  results.push(result);
  await putTaskResults(taskId, results);
  return results;
}

export async function clearTaskDatabase() {
  const db = await openTaskDb();
  await Promise.all([
    clearStore(db, SOURCE_STORE),
    clearStore(db, RESULT_STORE)
  ]);
}

function openTaskDb() {
  if (dbPromise) {
    return dbPromise;
  }

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(SOURCE_STORE)) {
        db.createObjectStore(SOURCE_STORE, { keyPath: "taskId" });
      }
      if (!db.objectStoreNames.contains(RESULT_STORE)) {
        db.createObjectStore(RESULT_STORE, { keyPath: "taskId" });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });

  return dbPromise;
}

function putRecord(db, storeName, record) {
  return runStoreRequest(db, storeName, "readwrite", (store) => store.put(record));
}

function getRecord(db, storeName, key) {
  return runStoreRequest(db, storeName, "readonly", (store) => store.get(key));
}

function clearStore(db, storeName) {
  return runStoreRequest(db, storeName, "readwrite", (store) => store.clear());
}

function runStoreRequest(db, storeName, mode, makeRequest) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, mode);
    const request = makeRequest(transaction.objectStore(storeName));

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    transaction.onerror = () => reject(transaction.error);
  });
}
