import {
  HEADER_COLOR_RULES,
  LOCATOR_FIELDS,
  PGY_SUPPORTED_FIELDS
} from "../constants.js";

export function normalizeHeader(value) {
  return String(value ?? "")
    .replace(/\s+/g, "")
    .replace(/[()]/g, (token) => (token === "(" ? "（" : "）"))
    .toLowerCase()
    .trim();
}

export function isForcedHeader(fillRgb) {
  if (!fillRgb) {
    return false;
  }

  return HEADER_COLOR_RULES.FORCE_COLLECT_RGB.includes(String(fillRgb).toUpperCase());
}

export function buildHeaderIndex(headers) {
  return headers.reduce((acc, header, index) => {
    acc[normalizeHeader(header.name)] = {
      index,
      ...header,
      normalizedName: normalizeHeader(header.name)
    };
    return acc;
  }, {});
}

export function collectableFieldsForPgy() {
  return new Set([...PGY_SUPPORTED_FIELDS.account, ...PGY_SUPPORTED_FIELDS.note].map(normalizeHeader));
}

export function extractRowLocators(row, headerIndex) {
  const pick = (field) => {
    const header = headerIndex[normalizeHeader(field)];
    return header ? row[header.index] : undefined;
  };
  const pgyProfileUrl = pick("蒲公英链接") ||
    pick("蒲公英主页") ||
    pick("蒲公英主页链接") ||
    pick("蒲公英达人主页") ||
    pick("蒲公英达人链接");

  return {
    nickname: pick("达人昵称") || pick("昵称"),
    creatorId: pick("达人id") || pick("达人ID") || pick("id") || pick("小红书号"),
    profileUrl: pick("主页链接") || pick("小红书主页") || pick("小红书链接"),
    pgyProfileUrl,
    cooperationType: pick("合作形式"),
    publishUrl: pick("发布链接"),
    publishedAt: pick("实际发布时间")
  };
}

export function buildCollectPlan(headers, rows, collectionOptions = {}) {
  const headerIndex = buildHeaderIndex(headers);
  const accountFields = new Set(PGY_SUPPORTED_FIELDS.account.map(normalizeHeader));
  const noteFields = new Set(PGY_SUPPORTED_FIELDS.note.map(normalizeHeader));

  return rows.map((row, rowIndex) => {
    const locators = extractRowLocators(row, headerIndex);
    const hasPublishUrl = !isBlank(locators.publishUrl);
    const fields = headers
      .filter((header) => accountFields.has(normalizedHeaderName(header)) || noteFields.has(normalizedHeaderName(header)))
      .filter((header) => {
        const normalizedName = normalizedHeaderName(header);
        const shouldCollect = isForcedHeader(header.fillRgb) || isBlank(row[header.index]);
        if (noteFields.has(normalizedName)) {
          return hasPublishUrl && shouldCollect;
        }

        return accountFields.has(normalizedName) && shouldCollect;
      })
      .map((header) => header.name);

    return {
      rowIndex,
      locators,
      collectionOptions,
      fields
    };
  }).filter((item) => item.fields.length > 0);
}

export function isBlank(value) {
  const normalized = String(value ?? "").trim();
  return value === null || value === undefined || normalized === "" || normalized === "-";
}

export function requiredLocatorGroups() {
  return LOCATOR_FIELDS;
}

function normalizedHeaderName(header) {
  return header.normalizedName ?? normalizeHeader(header.name);
}
