import { DEFAULT_QUEUE_POLICY } from "./constants.js";

export function randomInt(min, max) {
  const range = max - min;
  return min + Math.round(Math.random() * range);
}

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function runSerial(
  tasks,
  shouldContinue = async () => true,
  policy = DEFAULT_QUEUE_POLICY,
  onProgress = async () => {}
) {
  const results = [];

  for (let index = 0; index < tasks.length; index += 1) {
    const task = tasks[index];
    if (!(await shouldContinue(task))) {
      break;
    }

    await onProgress({ stage: "task-start", index, total: tasks.length });
    results.push(await task());
    await onProgress({ stage: "task-complete", index, total: tasks.length });
    if (index === tasks.length - 1) {
      continue;
    }

    const delay = randomInt(policy.minDelaySeconds, policy.maxDelaySeconds) * 1000;
    await onProgress({ stage: "task-wait", index, total: tasks.length, delayMs: delay });
    await sleep(delay);
  }

  return results;
}

export async function retryWithBackoff(fn, policy = DEFAULT_QUEUE_POLICY) {
  let remaining = policy.retryCount;
  let lastError;

  while (remaining >= 0) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      if (remaining === 0) {
        throw lastError;
      }

      const delay = randomInt(policy.retryMinDelaySeconds, policy.retryMaxDelaySeconds) * 1000;
      await sleep(delay);
      remaining -= 1;
    }
  }

  throw lastError;
}
