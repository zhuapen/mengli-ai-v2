import * as pgyDb from "../shared/platforms/pgy-task-db.js";
import * as huxuanDb from "../shared/platforms/huxuan-task-db.js";
import * as xingtuDb from "../shared/platforms/xingtu-task-db.js";
import { buildCollectPlan as buildPgyPlan, normalizeHeader } from "../shared/platforms/pgy-table-rules.js";
import { buildCollectPlan as buildHuxuanPlan } from "../shared/platforms/huxuan-table-rules.js";
import { buildCollectPlan as buildXingtuPlan } from "../shared/platforms/xingtu-table-rules.js";
import { PGY_DEFAULT_FILTERS, PGY_FILTER_LABELS } from "../shared/constants.js";

const SOURCE_EXTENSION_VERSION = chrome.runtime.getManifest?.().version ?? "dev";

function scheduleRuntimeReloadIfStale() {
  const runtimeVersion = chrome.runtime.getManifest?.().version;
  if (!runtimeVersion || runtimeVersion === SOURCE_EXTENSION_VERSION) {
    return false;
  }
  const reloadKey = `mengli-ai-reloaded-${SOURCE_EXTENSION_VERSION}`;
  if (sessionStorage.getItem(reloadKey) === "1") {
    return false;
  }
  sessionStorage.setItem(reloadKey, "1");
  chrome.runtime.reload();
  return true;
}

const PLATFORM_CONFIGS = Object.freeze({
  pgy: {
    label: "蒲公英",
    description: "蒲公英数据抓取、后台任务管理与结果导出。",
    source: "media-data-collector",
    progressAction: "pgy-progress",
    downloadPrefix: "蒲公英补全结果",
    taskDb: pgyDb,
    canStop: true,
    buildPlan(table) {
      const filters = readPgyFilters();
      return { filters, plan: buildPgyPlan(table.headers, table.rows, filters), payloadKey: "collectionOptions" };
    },
    summaryFilters(filters) {
      return describePgyFilters(filters);
    }
  },
  huxuan: {
    label: "腾讯互选",
    description: "腾讯互选视频号账号与作品数据抓取、后台任务管理与结果导出。",
    source: "huxuan-data-collector",
    progressAction: "task-progress",
    downloadPrefix: "腾讯互选视频号补全结果",
    taskDb: huxuanDb,
    buildPlan(table) {
      const filters = readHuxuanFilters();
      return { filters, plan: applyHuxuanFilters(buildHuxuanPlan(table.headers, table.rows), filters), payloadKey: "filters" };
    }
  },
  xingtu: {
    label: "巨量星图",
    description: "巨量星图账号与作品数据抓取、后台任务管理与结果导出。",
    source: "xingtu-data-collector",
    progressAction: "task-progress",
    downloadPrefix: "巨量星图补全结果",
    taskDb: xingtuDb,
    buildPlan(table) {
      const filters = readXingtuFilters();
      return { filters, plan: applyXingtuFilters(buildXingtuPlan(table.headers, table.rows), filters), payloadKey: "filters" };
    },
    summaryFilters(filters) {
      return describeXingtuFilters(filters);
    }
  }
});

const HUXUAN_EXTRA_EXPORT_FIELDS = [
  "作品匹配状态",
  "作品匹配方式",
  "作品诊断"
];

const fileInput = document.querySelector("#file-input");
const clearTasksButton = document.querySelector("#clear-tasks");
const taskList = document.querySelector("#task-list");
const taskCount = document.querySelector("#task-count");
const statusBox = document.querySelector("#status");
const outputTitle = document.querySelector("#output-title");
const output = document.querySelector("#output");
const platformDescription = document.querySelector("#platform-description");
const platformTabs = [...document.querySelectorAll("[data-platform]")];
const filterPanels = [...document.querySelectorAll("[data-filter-panel]")];

const pgyInputs = {
  business: document.querySelector("#pgy-business-filter"),
  noteType: document.querySelector("#pgy-note-type-filter"),
  dateRange: document.querySelector("#pgy-date-filter"),
  traffic: document.querySelector("#pgy-traffic-filter")
};
const huxuanInputs = { performanceScope: document.querySelector("#huxuan-performance-scope") };
const xingtuInputs = {
  contentDataRange: document.querySelector("#content-data-range"),
  contentVideoType: document.querySelector("#content-video-type"),
  onlyAssigned: document.querySelector("#only-assigned"),
  contentExcludeMarketing: document.querySelector("#content-exclude-marketing"),
  estimateVideoType: document.querySelector("#estimate-video-type"),
  estimateExcludeMarketing: document.querySelector("#estimate-exclude-marketing"),
  plantingDataRange: document.querySelector("#planting-data-range")
};

let activePlatform = "pgy";
let parsedTable = null;
let selectedTaskId = null;
let tasks = [];

if (!scheduleRuntimeReloadIfStale()) {
  init();
}

chrome.runtime.onMessage.addListener((message) => {
  const platform = platformFromSource(message?.source);
  if (!platform || platform !== activePlatform) return;
  const config = PLATFORM_CONFIGS[activePlatform];

  if (message.action === "task-updated") {
    upsertLocalTask(message.task);
    renderTasks();
    renderSelectedTask();
  }

  if (message.action === config.progressAction) {
    const { taskId, stage, index, total, delayMs } = message.payload;
    if (selectedTaskId && taskId !== selectedTaskId) return;
    if (stage === "task-start") setStatus(`后台抓取中：第 ${index + 1}/${total} 行`);
    if (stage === "task-complete") setStatus(`第 ${index + 1}/${total} 行已保存，侧边栏关闭也会继续。`);
    if (stage === "task-wait") setStatus(`第 ${index + 1}/${total} 行完成，约 ${Math.round(delayMs / 1000)} 秒后继续。`);
  }

  if (message.action === "tasks-cleared") {
    parsedTable = null;
    selectedTaskId = null;
    tasks = [];
    renderTasks();
    updateControls();
    render("当前平台任务已全部清除。", "状态");
    setStatus("选择表格后自动开始任务...");
  }
});

async function init() {
  fileInput.addEventListener("change", handleFileChange);
  clearTasksButton.addEventListener("click", clearCurrentPlatformTasks);
  for (const tab of platformTabs) {
    tab.addEventListener("click", () => switchPlatform(tab.dataset.platform));
  }
  await refreshTasks();
  renderPlatformChrome();
  updateControls();
  await maybeRunAutomationFromQuery();
}

async function switchPlatform(platform) {
  if (!PLATFORM_CONFIGS[platform] || platform === activePlatform) return;
  activePlatform = platform;
  parsedTable = null;
  selectedTaskId = null;
  fileInput.value = "";
  renderPlatformChrome();
  await refreshTasks();
  setStatus(`已切换到${PLATFORM_CONFIGS[platform].label}。选择表格后自动开始任务...`);
}

async function maybeRunAutomationFromQuery() {
  const params = new URLSearchParams(location.search);
  if (params.get("autoRun") !== "1") {
    return;
  }
  const platform = params.get("platform") || "xingtu";
  const filePath = params.get("file");
  if (!PLATFORM_CONFIGS[platform] || !filePath) {
    renderError("自动验证参数缺少 platform 或 file。");
    return;
  }

  try {
    setBusy(true);
    activePlatform = platform;
    parsedTable = null;
    selectedTaskId = null;
    applyAutomationFilters(platform, params);
    renderPlatformChrome();
    await refreshTasks();
    if (params.get("autoClear") === "1") {
      const clearResponse = await sendPlatformMessage("clear-tasks");
      if (!clearResponse.ok) throw new Error(clearResponse.error);
      tasks = [];
      selectedTaskId = null;
      renderTasks();
    }

    const file = await readLocalAutomationFile(filePath);
    setStatus(`自动验证读取：${file.name}`);
    parsedTable = await parseWorkbookFile(file);
    const task = await createAndStartTaskFromParsedTable(file.name, parsedTable);
    if (!task) return;

    if (params.get("autoDownload") === "1") {
      const completed = await waitForTaskCompletion(task.id, Number(params.get("timeoutMs") || 360000));
      if (completed.status !== "completed") {
        throw new Error(completed.error || `自动验证任务未完成：${completed.status}`);
      }
      await downloadTask(completed.id);
    }
  } catch (error) {
    renderError(error);
  } finally {
    setBusy(false);
    updateControls();
  }
}

function applyAutomationFilters(platform, params) {
  if (platform !== "xingtu") {
    return;
  }
  setSelectValue(xingtuInputs.contentDataRange, params.get("contentDataRange"));
  setSelectValue(xingtuInputs.contentVideoType, params.get("contentVideoType"));
  setCheckboxValue(xingtuInputs.onlyAssigned, params.get("onlyAssigned"));
  setCheckboxValue(xingtuInputs.contentExcludeMarketing, params.get("contentExcludeMarketing"));
  setSelectValue(xingtuInputs.estimateVideoType, params.get("estimateVideoType"));
  setCheckboxValue(xingtuInputs.estimateExcludeMarketing, params.get("estimateExcludeMarketing"));
  setSelectValue(xingtuInputs.plantingDataRange, params.get("plantingDataRange"));
}

function setSelectValue(input, value) {
  if (!input || !value) {
    return;
  }
  const option = [...input.options].find((item) => item.value === value || item.textContent.trim() === value);
  if (option) {
    input.value = option.value;
  }
}

function setCheckboxValue(input, value) {
  if (!input || value === null || value === undefined || value === "") {
    return;
  }
  input.checked = /^(1|true|yes|是|选中)$/i.test(String(value).trim());
}

async function readLocalAutomationFile(filePath) {
  const url = filePath.startsWith("file:") ? filePath : pathToFileUrl(filePath);
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`自动验证读取本地文件失败：${response.status}`);
  }
  const blob = await response.blob();
  return new File([blob], filePath.split(/[\\/]/).pop() || "自动验证.xlsx", { type: blob.type || "application/octet-stream" });
}

function pathToFileUrl(filePath) {
  return `file://${String(filePath).split("/").map((part) => encodeURIComponent(part)).join("/")}`;
}

async function waitForTaskCompletion(taskId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    await sleep(2000);
    await refreshTasks();
    const task = tasks.find((item) => item.id === taskId);
    if (task && ["completed", "failed", "paused"].includes(task.status)) {
      return task;
    }
  }
  throw new Error("自动验证等待任务完成超时");
}

function renderPlatformChrome() {
  const config = PLATFORM_CONFIGS[activePlatform];
  platformDescription.textContent = config.description;
  for (const tab of platformTabs) tab.classList.toggle("is-active", tab.dataset.platform === activePlatform);
  for (const panel of filterPanels) panel.classList.toggle("is-hidden", panel.dataset.filterPanel !== activePlatform);
}

async function handleFileChange() {
  parsedTable = null;
  const file = fileInput.files?.[0];
  if (!file) {
    updateControls();
    return;
  }

  try {
    setBusy(true);
    setStatus(`正在读取：${file.name}`);
    parsedTable = await parseWorkbookFile(file);
    await createAndStartTaskFromParsedTable(file.name, parsedTable);
  } catch (error) {
    parsedTable = null;
    renderError(error);
  } finally {
    fileInput.value = "";
    setBusy(false);
    updateControls();
  }
}

async function createAndStartTaskFromParsedTable(fileName, table) {
  const config = PLATFORM_CONFIGS[activePlatform];
  const built = config.buildPlan(table);
  if (!built.plan.length) {
    setStatus(activePlatform === "huxuan" ? "没有找到需要补全的空白字段。" : "没有找到需要抓取的空白或红色字段。");
    renderSummary({ fileName, sheetName: table.sheetName, platform: config.label, filters: config.summaryFilters?.(built.filters) ?? built.filters, taskCount: 0, message: "未创建任务" }, "文件读取完成");
    return null;
  }

  const taskId = createId();
  const name = uniqueTaskName(fileName);
  await config.taskDb.putTaskSource(taskId, { fileName, sheetName: table.sheetName, type: table.type, buffer: table.buffer });

  const payload = { id: taskId, name, sourceFileName: fileName, sheetName: table.sheetName, plan: built.plan };
  payload[built.payloadKey] = built.filters;

  const createResponse = await sendPlatformMessage("create-task", payload);
  if (!createResponse.ok) throw new Error(createResponse.error);

  selectedTaskId = createResponse.task.id;
  upsertLocalTask(createResponse.task);
  renderTasks();
  renderSelectedTask();

  await pauseOtherPlatforms();
  const startResponse = await sendPlatformMessage("start-task", null, createResponse.task.id);
  if (!startResponse.ok) throw new Error(startResponse.error);

  upsertLocalTask(startResponse.task);
  renderTasks();
  renderSelectedTask();
  setStatus(`任务“${startResponse.task.name}”已开始后台抓取，可关闭侧边栏。`);
  return startResponse.task;
}

async function startTaskFromCard(taskId) {
  const task = tasks.find((item) => item.id === taskId);
  if (!task) return;
  await pauseOtherPlatforms();
  const response = await sendPlatformMessage("start-task", null, taskId);
  if (!response.ok) {
    renderError(response.error);
    return;
  }
  upsertLocalTask(response.task);
  renderTasks();
  renderSelectedTask();
  setStatus(`任务“${response.task.name}”已进入后台抓取。可以关闭侧边栏。`);
}

async function stopTaskFromCard(taskId) {
  const response = await sendPlatformMessage("stop-task", null, taskId);
  if (!response.ok) {
    renderError(response.error);
    return;
  }
  upsertLocalTask(response.task);
  renderTasks();
  renderSelectedTask();
  setStatus(`任务“${response.task.name}”已停止，可点击继续恢复。`);
}

async function downloadTask(taskId) {
  const task = tasks.find((item) => item.id === taskId);
  if (!task || task.status !== "completed") return;
  try {
    const config = PLATFORM_CONFIGS[activePlatform];
    const [source, results] = await Promise.all([config.taskDb.getTaskSource(task.id), config.taskDb.getTaskResults(task.id)]);
    if (!source) throw new Error("未找到源文件，请重新创建任务。");
    if (!results.length) throw new Error("任务没有可导出的结果。");
    if (activePlatform === "huxuan") {
      const emptyResults = results.filter((result) => !Object.keys(result.values ?? {}).length);
      if (emptyResults.length) throw new Error(`有 ${emptyResults.length} 行没有采集到数据，请看任务详情里的错误后重新跑。`);
    }

    const table = parseStoredSource(source);
    const workbook = buildExportWorkbook(table, results);
    const array = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const blob = new Blob([array], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    const url = URL.createObjectURL(blob);
    const downloadFileName = `${config.downloadPrefix}-${sanitizeFileName(task.name)}.xlsx`;
    const downloadId = await chrome.downloads.download({ url, filename: downloadFileName, saveAs: false });
    setTimeout(() => URL.revokeObjectURL(url), 30000);

    const response = await sendPlatformMessage("mark-task-downloaded", { downloadFileName, downloadId }, task.id);
    if (response.ok) {
      upsertLocalTask(response.task);
      renderTasks();
      renderSelectedTask();
    }
    setStatus(`已下载：${downloadFileName}`);
  } catch (error) {
    renderError(error);
  }
}

async function openDownloadedTask(taskId) {
  const task = tasks.find((item) => item.id === taskId);
  if (!task?.downloadId) {
    renderError("无法打开，请重新导出。");
    return;
  }
  try {
    const items = await chrome.downloads.search({ id: task.downloadId });
    const item = items[0];
    if (!item || item.exists === false) throw new Error("无法打开，请重新导出。");
    chrome.downloads.open(task.downloadId);
    setStatus(`正在打开：${task.downloadFileName || "结果表"}`);
  } catch (_error) {
    renderError("无法打开，请重新导出。");
  }
}

async function clearCurrentPlatformTasks() {
  const response = await sendPlatformMessage("clear-tasks");
  if (!response.ok) {
    renderError(response.error);
    return;
  }
  parsedTable = null;
  selectedTaskId = null;
  tasks = [];
  renderTasks();
  updateControls();
  render("当前平台任务已全部清除。", "状态");
  setStatus("选择表格后自动开始任务...");
}

async function refreshTasks() {
  const response = await sendPlatformMessage("get-tasks");
  if (!response.ok) {
    renderError(response.error);
    return;
  }
  tasks = response.tasks ?? [];
  if (!selectedTaskId && tasks.length) selectedTaskId = tasks[0].id;
  if (selectedTaskId && !tasks.some((task) => task.id === selectedTaskId)) selectedTaskId = tasks[0]?.id ?? null;
  renderTasks();
  renderSelectedTask();
}

function renderTasks() {
  taskCount.textContent = `${tasks.length} 个任务`;
  taskList.innerHTML = "";
  if (!tasks.length) {
    const empty = document.createElement("div");
    empty.className = "task-card";
    empty.innerHTML = "<h3>暂无任务</h3><div class=\"task-meta\">选择表格后会自动创建并开始当前平台后台任务。</div>";
    taskList.append(empty);
    return;
  }
  for (const task of tasks) {
    const card = document.createElement("article");
    card.className = `task-card${task.id === selectedTaskId ? " is-selected" : ""}`;
    card.dataset.status = task.status;
    card.innerHTML = `
      <div class="task-card-head"><h3>${escapeHtml(task.name)}</h3><div class="task-actions">${renderTaskActions(task)}</div></div>
      <div class="task-meta">
        <span>${statusLabel(task.status)} · ${task.progress.completedRows}/${task.progress.totalRows}</span>
        <span>${escapeHtml(task.sourceFileName || "未记录源文件")}</span>
        <span>${task.downloadFileName ? `下载：${escapeHtml(task.downloadFileName)}` : "尚未下载"}</span>
        ${task.error ? `<span class="task-error">${escapeHtml(task.error)}</span>` : ""}
      </div>
      <div class="progress-bar"><span style="width:${progressPercent(task)}%"></span></div>`;
    card.addEventListener("click", () => {
      selectedTaskId = task.id;
      renderTasks();
      renderSelectedTask();
      updateControls();
    });
    for (const button of card.querySelectorAll("[data-action]")) {
      button.addEventListener("click", (event) => {
        event.stopPropagation();
        const action = button.dataset.action;
        if (action === "resume") startTaskFromCard(task.id);
        if (action === "stop") stopTaskFromCard(task.id);
        if (action === "download") downloadTask(task.id);
        if (action === "open") openDownloadedTask(task.id);
      });
    }
    taskList.append(card);
  }
}

function renderTaskActions(task) {
  const actions = [];
  if (["ready", "paused", "failed"].includes(task.status)) actions.push("<button class=\"mini-button\" type=\"button\" data-action=\"resume\">继续</button>");
  if (task.status === "running" && PLATFORM_CONFIGS[activePlatform].canStop) actions.push("<button class=\"mini-button\" type=\"button\" data-action=\"stop\">停止</button>");
  if (task.status === "completed") actions.push("<button class=\"mini-button primary-mini\" type=\"button\" data-action=\"download\">导出</button>");
  if (task.status === "completed" && task.downloadId) actions.push("<button class=\"mini-button\" type=\"button\" data-action=\"open\">打开</button>");
  return actions.join("");
}

function renderSelectedTask() {
  const task = selectedTask();
  if (!task) {
    updateControls();
    return;
  }
  const config = PLATFORM_CONFIGS[activePlatform];
  setStatus(`当前任务：${task.name} · ${statusLabel(task.status)} · ${task.progress.completedRows}/${task.progress.totalRows}`);
  renderSummary({ name: task.name, platform: config.label, status: task.status, progress: task.progress, sourceFileName: task.sourceFileName, sheetName: task.sheetName, filters: task.filters ?? task.collectionOptions ?? null, downloadFileName: task.downloadFileName, downloadId: task.downloadId, downloadedAt: task.downloadedAt, error: task.error }, "任务详情");
  updateControls();
}

function updateControls() {
  fileInput.disabled = false;
}

function setBusy(isBusy) {
  fileInput.disabled = isBusy;
  for (const input of [...Object.values(pgyInputs), ...Object.values(huxuanInputs), ...Object.values(xingtuInputs)]) input.disabled = isBusy;
}

function readPgyFilters() {
  return {
    business: pgyInputs.business.value || PGY_DEFAULT_FILTERS.business,
    noteType: pgyInputs.noteType.value || PGY_DEFAULT_FILTERS.noteType,
    dateRange: pgyInputs.dateRange.value || PGY_DEFAULT_FILTERS.dateRange,
    traffic: pgyInputs.traffic.value || PGY_DEFAULT_FILTERS.traffic
  };
}

function describePgyFilters(options = {}) {
  return [PGY_FILTER_LABELS.business[options.business], PGY_FILTER_LABELS.noteType[options.noteType], PGY_FILTER_LABELS.dateRange[options.dateRange], PGY_FILTER_LABELS.traffic[options.traffic]].filter(Boolean).join(" / ");
}

function readHuxuanFilters() {
  return { performanceScope: huxuanInputs.performanceScope.value };
}

function applyHuxuanFilters(plan, filters) {
  return plan.map((item) => ({ ...item, locators: { ...item.locators, performanceScope: item.locators.performanceScope || filters.performanceScope } }));
}

function readXingtuFilters() {
  return {
    contentDataRange: xingtuInputs.contentDataRange.value,
    contentVideoType: xingtuInputs.contentVideoType.value,
    onlyAssigned: xingtuInputs.onlyAssigned.checked ? "是" : "否",
    contentExcludeMarketing: xingtuInputs.contentExcludeMarketing.checked ? "是" : "否",
    estimateVideoType: xingtuInputs.estimateVideoType.value,
    estimateExcludeMarketing: xingtuInputs.estimateExcludeMarketing.checked ? "是" : "否",
    plantingDataRange: xingtuInputs.plantingDataRange.value
  };
}

function applyXingtuFilters(plan, filters) {
  return plan.map((item) => ({
    ...item,
    locators: {
      ...item.locators,
      contentDataRange: item.locators.contentDataRange || filters.contentDataRange,
      contentVideoType: item.locators.contentVideoType || filters.contentVideoType,
      onlyAssigned: item.locators.onlyAssigned || filters.onlyAssigned,
      contentExcludeMarketing: item.locators.contentExcludeMarketing || filters.contentExcludeMarketing,
      estimateVideoType: item.locators.estimateVideoType || filters.estimateVideoType,
      estimateExcludeMarketing: item.locators.estimateExcludeMarketing || filters.estimateExcludeMarketing,
      plantingDataRange: item.locators.plantingDataRange || filters.plantingDataRange
    }
  }));
}

function describeXingtuFilters(filters = {}) {
  return [
    `内容数据 ${filters.contentDataRange || ""} / ${filters.contentVideoType || ""}`,
    filters.onlyAssigned === "是" ? "只看指派" : "不只看指派",
    filters.contentExcludeMarketing === "是" ? "内容排除营销流量" : "内容不排除营销流量",
    `效果预估 ${filters.estimateVideoType || ""}`,
    filters.estimateExcludeMarketing === "是" ? "效果排除营销流量" : "效果不排除营销流量",
    `种草价值 ${filters.plantingDataRange || ""}`
  ].filter(Boolean).join(" / ");
}

async function parseWorkbookFile(file) {
  const buffer = await file.arrayBuffer();
  const type = file.name.toLowerCase().endsWith(".csv") ? "csv" : "workbook";
  const table = type === "csv" ? parseCsv(new TextDecoder().decode(buffer)) : parseWorkbook(buffer);
  return { ...table, type, buffer };
}

function parseStoredSource(source) {
  if (source.type === "csv" || source.fileName?.toLowerCase().endsWith(".csv")) return parseCsv(new TextDecoder().decode(source.buffer));
  return parseWorkbook(source.buffer);
}

function parseWorkbook(buffer) {
  const workbook = XLSX.read(buffer, { type: "array", cellStyles: true, cellDates: true });
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];
  const range = XLSX.utils.decode_range(worksheet["!ref"]);
  const rows = [];
  const headers = [];
  for (let col = range.s.c; col <= range.e.c; col += 1) {
    const address = XLSX.utils.encode_cell({ r: range.s.r, c: col });
    const cell = worksheet[address] || {};
    headers.push({ index: col - range.s.c, name: cell.v ?? "", normalizedName: normalizeHeader(cell.v ?? ""), fillRgb: cell.s?.fgColor?.rgb ?? cell.s?.fill?.fgColor?.rgb ?? null });
  }
  for (let row = range.s.r + 1; row <= range.e.r; row += 1) {
    const values = [];
    for (let col = range.s.c; col <= range.e.c; col += 1) values.push(worksheet[XLSX.utils.encode_cell({ r: row, c: col })]?.v ?? "");
    rows.push(values);
  }
  return { workbook, sheetName, headers, rows };
}

function parseCsv(text) {
  const lines = text.trim().split(/\r?\n/);
  const rawHeaders = splitCsvLine(lines[0] ?? "");
  const headers = rawHeaders.map((name, index) => ({ index, name, normalizedName: normalizeHeader(name), fillRgb: null }));
  const rows = lines.slice(1).map(splitCsvLine);
  return { sheetName: "CSV", headers, rows };
}

function buildExportWorkbook(table, results) {
  if (table.workbook) return buildExportWorkbookFromOriginal(table, results);
  const values = [table.headers.map((header) => header.name), ...table.rows.map((row) => [...row])];
  const headerIndex = new Map(table.headers.map((header) => [header.name, header.index]));
  const normalizedHeaderIndex = new Map(table.headers.map((header) => [normalizeHeader(header.name), header.index]));
  appendExtraExportFields(values, results, headerIndex, normalizedHeaderIndex);
  for (const result of results) {
    const row = values[result.rowIndex + 1];
    for (const [field, value] of Object.entries(result.values ?? {})) {
      const colIndex = headerIndex.get(field) ?? normalizedHeaderIndex.get(normalizeHeader(field));
      if (colIndex === undefined || value === null || value === undefined) continue;
      row[colIndex] = value;
    }
  }
  const worksheet = XLSX.utils.aoa_to_sheet(values);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, table.sheetName || "结果");
  return workbook;
}

function buildExportWorkbookFromOriginal(table, results) {
  const workbook = table.workbook;
  const worksheet = workbook.Sheets[table.sheetName];
  const range = XLSX.utils.decode_range(worksheet["!ref"]);
  const headerIndex = new Map(table.headers.map((header) => [header.name, header.index]));
  const normalizedHeaderIndex = new Map(table.headers.map((header) => [normalizeHeader(header.name), header.index]));
  appendExtraExportFieldsToWorksheet(worksheet, range, results, headerIndex, normalizedHeaderIndex);
  for (const result of results) {
    for (const [field, value] of Object.entries(result.values ?? {})) {
      const colIndex = headerIndex.get(field) ?? normalizedHeaderIndex.get(normalizeHeader(field));
      if (colIndex === undefined || value === null || value === undefined) continue;
      const address = XLSX.utils.encode_cell({ r: range.s.r + result.rowIndex + 1, c: range.s.c + colIndex });
      const originalCell = worksheet[address] ?? {};
      worksheet[address] = { ...originalCell, s: clearCollectMarkerStyle(originalCell.s), t: typeof value === "number" ? "n" : "s", v: value };
    }
  }
  return workbook;
}

function appendExtraExportFields(values, results, headerIndex, normalizedHeaderIndex) {
  const fields = getExtraExportFields(results, normalizedHeaderIndex);
  if (!fields.length) return;
  for (const field of fields) {
    const colIndex = values[0].length;
    values[0].push(field);
    headerIndex.set(field, colIndex);
    normalizedHeaderIndex.set(normalizeHeader(field), colIndex);
  }
  for (let rowIndex = 1; rowIndex < values.length; rowIndex += 1) {
    while (values[rowIndex].length < values[0].length) values[rowIndex].push("");
  }
}

function appendExtraExportFieldsToWorksheet(worksheet, range, results, headerIndex, normalizedHeaderIndex) {
  const fields = getExtraExportFields(results, normalizedHeaderIndex);
  if (!fields.length) return;
  let nextCol = range.e.c + 1;
  for (const field of fields) {
    const address = XLSX.utils.encode_cell({ r: range.s.r, c: nextCol });
    worksheet[address] = { t: "s", v: field };
    const relativeIndex = nextCol - range.s.c;
    headerIndex.set(field, relativeIndex);
    normalizedHeaderIndex.set(normalizeHeader(field), relativeIndex);
    nextCol += 1;
  }
  range.e.c = Math.max(range.e.c, nextCol - 1);
  worksheet["!ref"] = XLSX.utils.encode_range(range);
}

function getExtraExportFields(results, normalizedHeaderIndex) {
  if (activePlatform !== "huxuan") return [];
  return HUXUAN_EXTRA_EXPORT_FIELDS.filter((field) => {
    if (normalizedHeaderIndex.has(normalizeHeader(field))) return false;
    return results.some((result) => Object.prototype.hasOwnProperty.call(result.values ?? {}, field));
  });
}

function clearCollectMarkerStyle(style) {
  if (!style) return style;
  const nextStyle = { ...style };
  const fillRgb = style.fgColor?.rgb ?? style.fill?.fgColor?.rgb ?? null;
  const fontRgb = style.font?.color?.rgb ?? null;
  if (isRedColor(fillRgb) || isRedColor(fontRgb)) {
    delete nextStyle.fgColor;
    if (nextStyle.fill) nextStyle.fill = { ...nextStyle.fill, fgColor: { rgb: "FFFFFFFF" }, bgColor: { rgb: "FFFFFFFF" } };
    if (nextStyle.font?.color && isRedColor(fontRgb)) nextStyle.font = { ...nextStyle.font, color: { rgb: "FF1F2937" } };
  }
  return nextStyle;
}

function platformFromSource(source) {
  return Object.entries(PLATFORM_CONFIGS).find(([, config]) => config.source === source)?.[0] ?? null;
}

function selectedTask() { return tasks.find((task) => task.id === selectedTaskId) ?? null; }
function upsertLocalTask(task) { const index = tasks.findIndex((item) => item.id === task.id); tasks = index >= 0 ? tasks.map((item) => (item.id === task.id ? task : item)) : [task, ...tasks]; selectedTaskId = task.id; }
function uniqueTaskName(fileName) { const base = sanitizeFileName(fileName.replace(/\.[^.]+$/, "")) || "未命名任务"; if (!tasks.some((task) => task.name === base)) return base; const now = new Date(); const stamp = `${pad2(now.getMonth() + 1)}${pad2(now.getDate())}-${pad2(now.getHours())}${pad2(now.getMinutes())}`; const stamped = `${base}-${stamp}`; return tasks.some((task) => task.name === stamped) ? `${stamped}-${String(Date.now()).slice(-4)}` : stamped; }
function splitCsvLine(line) { return line.split(",").map((value) => value.trim()); }
function progressPercent(task) { return task.progress.totalRows ? Math.round((task.progress.completedRows / task.progress.totalRows) * 100) : 0; }
function statusLabel(status) { return ({ ready: "待开始", running: "后台运行中", paused: "已暂停", completed: "已完成", failed: "失败" })[status] ?? status; }
function setStatus(text) { statusBox.textContent = text; }
function render(value, title = "状态") { outputTitle.textContent = title; output.textContent = value; }
function renderSummary(value, title = "状态") { render(JSON.stringify(value, null, 2), title); }
function renderError(error) { const message = error?.message || String(error); setStatus(message); renderSummary({ ok: false, error: message }, "错误"); }
function sendPlatformMessage(action, payload = null, taskId = null) { const config = PLATFORM_CONFIGS[activePlatform]; return chrome.runtime.sendMessage({ source: config.source, action, payload, taskId }); }
function pauseOtherPlatforms() { return chrome.runtime.sendMessage({ source: "mengli-ai-unified", action: "pause-other-platforms", platform: activePlatform }).catch(() => ({})); }
function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
function createId() { return crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`; }
function sanitizeFileName(value) { return String(value || "未命名任务").replace(/[\\/:*?"<>|]/g, "_").trim().slice(0, 80); }
function pad2(value) { return String(value).padStart(2, "0"); }
function escapeHtml(value) { return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function isRedColor(value) { return /^(FFFF0000|00FF0000|FF0000)$/i.test(String(value ?? "")); }
