# 萌力AI插件

蒲公英、腾讯互选视频号、巨量星图三合一 Chrome MV3 插件。

## 使用

1. 在 Chrome 扩展管理页加载未打包扩展目录：`/Users/tulei/Desktop/萌力AI插件`
2. 打开侧边栏后选择平台：蒲公英 / 腾讯互选 / 巨量星图
3. 当前平台会显示对应筛选条件、任务列表和导出入口

## 隔离规则

- 三个平台共用一个插件外壳，但任务列表按平台切换显示。
- 清除任务只清当前平台。
- 源文件和采集结果分别写入各平台独立 IndexedDB。
- 原项目目录不覆盖：
  - `/Users/tulei/Desktop/蒲公英`
  - `/Users/tulei/Desktop/腾讯互选`
  - `/Users/tulei/Desktop/星图/xingtu-standalone`
